# 这里是修复版的customtkinter_example.py，移除了导致拖放功能失效的代码
# 保留了所有其他功能，但简化了拖放处理逻辑

import os
import sys
import json
import logging
import subprocess
import shutil
import customtkinter as ctk
from tkinter import filedialog, messagebox, ttk
import winreg
import webbrowser
import tempfile
import datetime
import threading
import queue
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 设置自定义主题
ctk.set_appearance_mode("System")  # 模式: "System" (跟随系统), "Dark", "Light"
ctk.set_default_color_theme("blue")  # 主题: "blue", "green", "dark-blue"

# 尝试导入Windows特定模块
try:
    import win32con
    import win32gui
    import win32api
    import win32com.client
    has_win32 = True
except ImportError:
    logger.warning("未找到win32模块，某些Windows特定功能可能不可用")
    has_win32 = False

class ModernUI:
    def __init__(self, root):
        """初始化应用程序"""
        try:
            self.root = root
            self.root.title("现代化文件管理工具")
            self.root.geometry("1200x700")
            self.root.minsize(800, 600)
            
            # 设置图标（如果有）
            # self.root.iconbitmap("path_to_icon.ico")
            
            # 配置样式
            self.style = ttk.Style()
            self.style.configure("Treeview", rowheight=30)
            self.style.configure("Treeview.Heading", font=('Arial', 12, 'bold'))
            
            # 数据存储
            self.app_list = []
            self.file_list = []
            self.favorite_list = []
            self.history_list = []
            self.settings = self._load_settings()
            
            # 临时存储当前分区
            self.current_section = "applications"
            
            # 创建UI
            self._create_ui()
            
            # 加载数据
            self._load_data()
            
            # 初始化拖放功能 - 简化版本
            self._initialize_drag_and_drop()
            
        except Exception as e:
            logger.error(f"初始化应用程序时出错: {e}")
            messagebox.showerror("错误", f"初始化应用程序时出错: {str(e)}")
    
    def _initialize_drag_and_drop(self):
        """初始化拖放功能的简化版本"""
        try:
            # 简化的拖放初始化
            # 只保留拖放释放事件，移除未定义的方法调用
            self.content_frame.bind("<ButtonRelease-1>", self._on_drag_release)
            
            # 对于Windows系统，尝试启用文件拖放
            if sys.platform == 'win32' and has_win32:
                try:
                    # 导入必要的模块
                    import ctypes
                    # 获取窗口句柄
                    hwnd = self.root.winfo_id()
                    # 尝试注册窗口以接受文件拖放
                    ctypes.windll.shell32.DragAcceptFiles(hwnd, True)
                    logger.info("Windows文件拖放支持已启用")
                except Exception as e:
                    logger.warning(f"启用Windows文件拖放支持时出错: {e}")
            
            logger.info("基础拖放功能已初始化")
        except Exception as e:
            logger.error(f"初始化拖放功能时出错: {e}")
    
    def _create_ui(self):
        """创建用户界面"""
        # 创建主布局
        self.main_frame = ctk.CTkFrame(self.root)
        self.main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # 创建顶部导航栏
        self.top_nav = ctk.CTkFrame(self.main_frame, height=60)
        self.top_nav.pack(fill="x", padx=5, pady=5)
        
        # 创建左侧侧边栏
        self.sidebar = ctk.CTkFrame(self.main_frame, width=200)
        self.sidebar.pack(side="left", fill="y", padx=5, pady=5)
        
        # 创建内容区域
        self.content_frame = ctk.CTkScrollableFrame(self.main_frame)
        self.content_frame.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        
        # 设置内容拖放功能
        self._setup_content_drag_and_drop()
        
        # 创建状态栏
        self.status_bar = ctk.CTkLabel(self.main_frame, text="就绪", height=30, anchor="w")
        self.status_bar.pack(fill="x", padx=5, pady=5)
        
        # 创建分区按钮
        self._create_section_buttons()
        
        # 创建顶部导航按钮
        self._create_nav_buttons()
    
    def _setup_content_drag_and_drop(self):
        """设置内容区域的拖放功能"""
        # 基础事件绑定 - 使用Tkinter兼容的事件名称
        self.content_frame.bind("<Enter>", self._on_drag_enter)
        self.content_frame.bind("<Leave>", self._on_drag_leave)
        self.content_frame.bind("<ButtonRelease-1>", self._on_drop)
        
        # 注册拖放类型
        if sys.platform == 'win32':
            try:
                # 对于Windows系统，使用简单的文件拖放支持
                logger.info("已为Windows系统设置基础拖放支持")
            except Exception as e:
                logger.warning(f"设置Windows拖放支持时出错: {e}")
    
    def _on_drag_enter(self, event):
        """处理拖放进入事件"""
        logger.info("拖放进入事件触发")
        event.widget.focus_set()
        return "copy"
    
    def _on_drag_leave(self, event):
        """处理拖放离开事件"""
        logger.info("拖放离开事件触发")
    
    def _on_drop(self, event):
        """处理拖放事件 - 适配ButtonRelease-1事件"""
        try:
            # 检查是否有拖动的项目
            if hasattr(self, 'dragged_item'):
                logger.info(f"释放拖动的项目: {self.dragged_item.get('name', '未知')}")
                
                # 检查是否需要显示添加对话框（如果是从外部拖入的文件）
                # 这里简化处理，实际的文件拖放需要特殊处理
                
                delattr(self, 'dragged_item')
                return True
        except Exception as e:
            logger.error(f"处理拖放时出错: {e}")
        return False
    
    def _create_section_buttons(self):
        """创建侧边栏中的分区按钮"""
        # 存储分区框架的字典
        self.section_frames = {}
        
        sections = [
            {"name": "applications", "text": "应用程序", "icon": "📱"},
            {"name": "files", "text": "文件", "icon": "📄"},
            {"name": "favorites", "text": "收藏夹", "icon": "⭐"},
            {"name": "history", "text": "历史记录", "icon": "🕒"}
        ]
        
        for section in sections:
            # 创建分区框架
            frame = ctk.CTkFrame(self.sidebar, height=50)
            frame.pack(fill="x", padx=5, pady=3)
            
            # 创建分区按钮
            button = ctk.CTkButton(
                frame, 
                text=f"{section['icon']} {section['text']}",
                command=lambda s=section['name']: self._filter_by_section(s)
            )
            button.pack(fill="x", padx=5, pady=5)
            
            # 存储分区框架
            self.section_frames[section['name']] = frame
    
    def _filter_by_section(self, section):
        """按分区过滤内容"""
        self.current_section = section
        logger.info(f"切换到分区: {section}")
        
        # 清空内容区域
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        # 根据分区加载内容
        if section == "applications":
            self._display_applications()
        elif section == "files":
            self._display_files()
        elif section == "favorites":
            self._display_favorites()
        elif section == "history":
            self._display_history()
    
    def _display_applications(self):
        """显示应用程序列表"""
        for app in self.app_list:
            self._create_item_frame(app, "application")
    
    def _create_item_frame(self, item, item_type):
        """创建项目框架"""
        frame = ctk.CTkFrame(self.content_frame, height=80)
        frame.pack(fill="x", padx=5, pady=5)
        frame.grid_propagate(False)
        
        # 创建图标
        icon_label = ctk.CTkLabel(frame, text="📱" if item_type == "application" else "📄", font=CTkFont(size=32))
        icon_label.grid(row=0, column=0, rowspan=2, padx=10, pady=10)
        
        # 创建名称标签
        name_label = ctk.CTkLabel(frame, text=item['name'], font=CTkFont(size=16, weight="bold"))
        name_label.grid(row=0, column=1, sticky="w", padx=5, pady=(10, 0))
        
        # 创建路径标签
        path_label = ctk.CTkLabel(frame, text=item['path'], font=CTkFont(size=12), text_color="#808080")
        path_label.grid(row=1, column=1, sticky="w", padx=5, pady=(0, 10))
        
        # 创建操作按钮
        button_frame = ctk.CTkFrame(frame)
        button_frame.grid(row=0, column=2, rowspan=2, padx=10, pady=10)
        
        open_button = ctk.CTkButton(button_frame, text="打开", width=80, command=lambda p=item['path']: self._open_item(p))
        open_button.pack(side="left", padx=2, pady=2)
        
        edit_button = ctk.CTkButton(button_frame, text="编辑", width=80, command=lambda i=item: self._edit_item(i))
        edit_button.pack(side="left", padx=2, pady=2)
        
        delete_button = ctk.CTkButton(button_frame, text="删除", width=80, fg_color="#FF5252", hover_color="#FF0000", command=lambda i=item: self._delete_item(i))
        delete_button.pack(side="left", padx=2, pady=2)
        
        # 绑定拖放事件
        frame.bind("<Button-1>", lambda e, item=item: self._on_item_press(e, item))
        frame.bind("<B1-Motion>", lambda e, item=item: self._on_item_drag(e, item))
        
        # 存储框架引用
        item['frame'] = frame
    
    def _on_item_press(self, event, item):
        """处理项目按下事件，开始拖动"""
        logger.info(f"开始拖动项目: {item['name']}")
        self.dragged_item = item
        self.start_x = event.x
        self.start_y = event.y
    
    def _on_item_drag(self, event, item):
        """处理项目拖动事件"""
        # 实现简单的拖动视觉效果
        pass
    
    def _on_drag_release(self, event):
        """处理拖动释放事件"""
        if hasattr(self, 'dragged_item'):
            logger.info(f"释放拖动项目: {self.dragged_item['name']}")
            # 检查是否拖到了某个分区
            for section, frame in self.section_frames.items():
                if self._is_over_widget(event, frame):
                    logger.info(f"拖到分区: {section}")
                    self._move_item_to_section(self.dragged_item, section)
                    break
            delattr(self, 'dragged_item')
    
    def _is_over_widget(self, event, widget):
        """检查鼠标是否在指定控件上方"""
        x, y = widget.winfo_rootx(), widget.winfo_rooty()
        width, height = widget.winfo_width(), widget.winfo_height()
        return x <= event.x_root <= x + width and y <= event.y_root <= y + height
    
    def _move_item_to_section(self, item, section):
        """将项目移动到指定分区"""
        logger.info(f"将项目 {item['name']} 移动到分区 {section}")
        
        # 从当前列表移除
        if item in self.app_list:
            self.app_list.remove(item)
        if item in self.file_list:
            self.file_list.remove(item)
        if item in self.favorite_list:
            self.favorite_list.remove(item)
        if item in self.history_list:
            self.history_list.remove(item)
        
        # 添加到目标列表
        if section == "applications" and item['type'] == 'application':
            self.app_list.append(item)
        elif section == "files":
            self.file_list.append(item)
        elif section == "favorites":
            self.favorite_list.append(item)
        elif section == "history":
            self.history_list.append(item)
        
        # 保存数据
        self._save_data()
        
        # 更新显示
        self._filter_by_section(self.current_section)
    
    def _create_nav_buttons(self):
        """创建顶部导航按钮"""
        # 添加按钮
        add_button = ctk.CTkButton(self.top_nav, text="添加", command=self._show_add_dialog)
        add_button.pack(side="left", padx=5, pady=10)
        
        # 刷新按钮
        refresh_button = ctk.CTkButton(self.top_nav, text="刷新", command=self._refresh_content)
        refresh_button.pack(side="left", padx=5, pady=10)
        
        # 设置按钮
        settings_button = ctk.CTkButton(self.top_nav, text="设置", command=self._show_settings)
        settings_button.pack(side="right", padx=5, pady=10)
        
        # 搜索框
        self.search_var = ctk.StringVar()
        search_entry = ctk.CTkEntry(self.top_nav, textvariable=self.search_var, placeholder_text="搜索...", width=200)
        search_entry.pack(side="right", padx=5, pady=10)
        search_entry.bind("<Return>", self._search_items)
    
    def _show_add_dialog(self, item=None):
        """显示添加项目对话框"""
        # 创建对话框
        dialog = ctk.CTkToplevel(self.root)
        dialog.title("添加" if item is None else "编辑")
        dialog.geometry("500x300")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # 创建表单
        ctk.CTkLabel(dialog, text="名称:").pack(padx=20, pady=(20, 5), anchor="w")
        name_var = ctk.StringVar(value=item['name'] if item else "")
        name_entry = ctk.CTkEntry(dialog, textvariable=name_var)
        name_entry.pack(fill="x", padx=20, pady=5)
        
        ctk.CTkLabel(dialog, text="路径:").pack(padx=20, pady=(20, 5), anchor="w")
        path_var = ctk.StringVar(value=item['path'] if item else "")
        path_entry = ctk.CTkEntry(dialog, textvariable=path_var)
        path_entry.pack(fill="x", padx=20, pady=5)
        
        browse_button = ctk.CTkButton(dialog, text="浏览", command=lambda: self._browse_file(path_var))
        browse_button.pack(padx=20, pady=5, anchor="w")
        
        # 创建按钮
        button_frame = ctk.CTkFrame(dialog)
        button_frame.pack(fill="x", padx=20, pady=20)
        
        cancel_button = ctk.CTkButton(button_frame, text="取消", command=dialog.destroy)
        cancel_button.pack(side="right", padx=5, pady=5)
        
        save_button = ctk.CTkButton(button_frame, text="保存", command=lambda: self._save_item(dialog, name_var, path_var, item))
        save_button.pack(side="right", padx=5, pady=5)
    
    def _browse_file(self, path_var):
        """浏览文件"""
        file_path = filedialog.askopenfilename()
        if file_path:
            path_var.set(file_path)
    
    def _save_item(self, dialog, name_var, path_var, item=None):
        """保存项目"""
        name = name_var.get()
        path = path_var.get()
        
        if not name or not path:
            messagebox.showerror("错误", "名称和路径不能为空")
            return
        
        if not os.path.exists(path):
            messagebox.showerror("错误", "文件不存在")
            return
        
        # 创建或更新项目
        if item:
            # 更新现有项目
            item['name'] = name
            item['path'] = path
            item['updated'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logger.info(f"更新项目: {name}")
        else:
            # 创建新项目
            new_item = {
                'name': name,
                'path': path,
                'type': 'application' if path.lower().endswith('.exe') else 'file',
                'added': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # 添加到相应列表
            if new_item['type'] == 'application':
                self.app_list.append(new_item)
            else:
                self.file_list.append(new_item)
            
            logger.info(f"添加新项目: {name}")
        
        # 保存数据
        self._save_data()
        
        # 更新显示
        self._filter_by_section(self.current_section)
        
        # 关闭对话框
        dialog.destroy()
    
    def _open_item(self, path):
        """打开项目"""
        try:
            if os.path.exists(path):
                if sys.platform == 'win32':
                    os.startfile(path)
                else:
                    subprocess.Popen(['open', path])
                
                # 添加到历史记录
                item = next((i for i in self.app_list + self.file_list if i['path'] == path), None)
                if item:
                    self._add_to_history(item)
                
                logger.info(f"打开项目: {path}")
            else:
                messagebox.showerror("错误", "文件不存在")
        except Exception as e:
            logger.error(f"打开项目时出错: {e}")
            messagebox.showerror("错误", f"打开项目时出错: {str(e)}")
    
    def _edit_item(self, item):
        """编辑项目"""
        self._show_add_dialog(item)
    
    def _delete_item(self, item):
        """删除项目"""
        if messagebox.askyesno("确认", f"确定要删除 '{item['name']}' 吗？"):
            # 从所有列表中移除
            if item in self.app_list:
                self.app_list.remove(item)
            if item in self.file_list:
                self.file_list.remove(item)
            if item in self.favorite_list:
                self.favorite_list.remove(item)
            if item in self.history_list:
                self.history_list.remove(item)
            
            # 保存数据
            self._save_data()
            
            # 更新显示
            self._filter_by_section(self.current_section)
            
            logger.info(f"删除项目: {item['name']}")
    
    def _add_to_history(self, item):
        """添加到历史记录"""
        # 移除现有条目（如果有）
        self.history_list = [h for h in self.history_list if h['path'] != item['path']]
        
        # 创建历史记录条目
        history_item = item.copy()
        history_item['accessed'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 添加到历史记录开头
        self.history_list.insert(0, history_item)
        
        # 限制历史记录数量
        if len(self.history_list) > 50:
            self.history_list = self.history_list[:50]
    
    def _search_items(self, event=None):
        """搜索项目"""
        search_term = self.search_var.get().lower()
        logger.info(f"搜索: {search_term}")
        
        # 清空内容区域
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        # 根据当前分区搜索
        items_to_search = []
        if self.current_section == "applications":
            items_to_search = self.app_list
        elif self.current_section == "files":
            items_to_search = self.file_list
        elif self.current_section == "favorites":
            items_to_search = self.favorite_list
        elif self.current_section == "history":
            items_to_search = self.history_list
        
        # 显示搜索结果
        found = False
        for item in items_to_search:
            if search_term in item['name'].lower() or search_term in item['path'].lower():
                self._create_item_frame(item, item['type'])
                found = True
        
        # 如果没有找到，显示消息
        if not found:
            ctk.CTkLabel(self.content_frame, text="没有找到匹配的项目").pack(padx=20, pady=20)
    
    def _refresh_content(self):
        """刷新内容"""
        logger.info("刷新内容")
        self._filter_by_section(self.current_section)
    
    def _show_settings(self):
        """显示设置对话框"""
        # 创建对话框
        dialog = ctk.CTkToplevel(self.root)
        dialog.title("设置")
        dialog.geometry("500x400")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # 外观模式设置
        ctk.CTkLabel(dialog, text="外观模式:").pack(padx=20, pady=(20, 5), anchor="w")
        appearance_var = ctk.StringVar(value=self.settings.get("appearance_mode", "System"))
        
        def change_appearance_mode(mode):
            ctk.set_appearance_mode(mode)
            self.settings["appearance_mode"] = mode
            self._save_settings()
        
        mode_frame = ctk.CTkFrame(dialog)
        mode_frame.pack(fill="x", padx=20, pady=5)
        
        for mode in ["System", "Dark", "Light"]:
            radio = ctk.CTkRadioButton(mode_frame, text=mode, variable=appearance_var, value=mode, command=lambda m=mode: change_appearance_mode(m))
            radio.pack(side="left", padx=10, pady=5)
        
        # 保存按钮
        save_button = ctk.CTkButton(dialog, text="保存设置", command=dialog.destroy)
        save_button.pack(padx=20, pady=20)
    
    def _load_data(self):
        """加载数据"""
        try:
            # 加载应用程序列表
            if os.path.exists("apps.json"):
                with open("apps.json", "r", encoding="utf-8") as f:
                    self.app_list = json.load(f)
            
            # 加载文件列表
            if os.path.exists("files.json"):
                with open("files.json", "r", encoding="utf-8") as f:
                    self.file_list = json.load(f)
            
            # 加载收藏夹
            if os.path.exists("favorites.json"):
                with open("favorites.json", "r", encoding="utf-8") as f:
                    self.favorite_list = json.load(f)
            
            # 加载历史记录
            if os.path.exists("history.json"):
                with open("history.json", "r", encoding="utf-8") as f:
                    self.history_list = json.load(f)
            
            logger.info("数据加载完成")
        except Exception as e:
            logger.error(f"加载数据时出错: {e}")
            messagebox.showerror("错误", f"加载数据时出错: {str(e)}")
    
    def _save_data(self):
        """保存数据"""
        try:
            # 保存应用程序列表
            with open("apps.json", "w", encoding="utf-8") as f:
                json.dump(self.app_list, f, ensure_ascii=False, indent=4)
            
            # 保存文件列表
            with open("files.json", "w", encoding="utf-8") as f:
                json.dump(self.file_list, f, ensure_ascii=False, indent=4)
            
            # 保存收藏夹
            with open("favorites.json", "w", encoding="utf-8") as f:
                json.dump(self.favorite_list, f, ensure_ascii=False, indent=4)
            
            # 保存历史记录
            with open("history.json", "w", encoding="utf-8") as f:
                json.dump(self.history_list, f, ensure_ascii=False, indent=4)
            
            logger.info("数据保存完成")
        except Exception as e:
            logger.error(f"保存数据时出错: {e}")
            messagebox.showerror("错误", f"保存数据时出错: {str(e)}")
    
    def _load_settings(self):
        """加载设置"""
        try:
            if os.path.exists("settings.json"):
                with open("settings.json", "r", encoding="utf-8") as f:
                    return json.load(f)
            return {"appearance_mode": "System"}
        except Exception as e:
            logger.error(f"加载设置时出错: {e}")
            return {"appearance_mode": "System"}
    
    def _save_settings(self):
        """保存设置"""
        try:
            with open("settings.json", "w", encoding="utf-8") as f:
                json.dump(self.settings, f, ensure_ascii=False, indent=4)
            logger.info("设置保存完成")
        except Exception as e:
            logger.error(f"保存设置时出错: {e}")

# 使用CTkFont
try:
    from customtkinter import CTkFont
except ImportError:
    # 回退到tkinter的Font
    from tkinter import font as tkfont
    class CTkFont:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
        
        def actual(self):
            return self.kwargs

if __name__ == "__main__":
    root = ctk.CTk()
    app = ModernUI(root)
    root.mainloop()