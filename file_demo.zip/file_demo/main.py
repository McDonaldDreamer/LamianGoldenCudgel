import os
import sys
import logging
from shortcuts import ShortcutsHandler

logger = logging.getLogger('ShortcutsApp')

def main():
    """
    主函数
    """
    print("桌面小易应用启动")
    logger.info("桌面小易应用启动")
    
    # 配置日志
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    
    # 清除现有的处理器
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # 创建文件处理器
    file_handler = logging.FileHandler("shortcuts_app.log", encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)
    root_logger.addHandler(file_handler)
    
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.DEBUG)
    console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)
    
    # 测试日志
    root_logger.debug("日志系统初始化完成")
    
    try:
        # 创建快捷方式处理器
        shortcuts_handler = ShortcutsHandler()
        
        # 加载快捷方式
        shortcuts_handler.load_shortcuts()
        
        # 导入并启动UI模块
        from customtkinter_example import ModernUI
        app = ModernUI(shortcuts_handler)
        app.run()
        
    except Exception as e:
        logger.error(f"应用程序错误: {e}")
        print(f"应用程序错误: {e}")
    finally:
        print("桌面小易应用关闭")
        logger.info("桌面小易应用关闭")

if __name__ == "__main__":
    main()