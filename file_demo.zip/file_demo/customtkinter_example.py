import customtkinter as ctk
import os
import sys
import subprocess
from tkinter import filedialog, messagebox, Menu, PhotoImage
import logging
import time
import re
import hashlib
import os
import time
from tkinter import filedialog
from shortcuts import ShortcutsHandler
import webbrowser
import win32gui
import win32ui
import win32con
import win32api
import ctypes
from ctypes import wintypes
# 尝试导入dnd模块，用于拖放功能
try:
    import tkinter.dnd
    DND_AVAILABLE = True
except ImportError:
    DND_AVAILABLE = False

# 使用根日志记录器，配置在main.py中已完成
logger = logging.getLogger('ModernUI')

class ModernUI:
    def __init__(self, shortcuts_handler=None):
        try:
            # 设置外观模式和主题
            ctk.set_appearance_mode("dark")
            ctk.set_default_color_theme("blue")
            
            # 创建主窗口
            self.root = ctk.CTk()
            self.root.title("小易")
            self.root.geometry("1024x768")
            self.root.minsize(800, 600)
            
            # 初始化数据管理
            if shortcuts_handler is not None:
                self.shortcuts_handler = shortcuts_handler
                logger.info("使用外部传入的ShortcutsHandler")
            else:
                logger.info("初始化ShortcutsHandler")
                self.shortcuts_handler = ShortcutsHandler()
            
            # 视图和状态变量
            self.logger = logger  # 初始化logger，引用全局logger对象
            self.view_mode = 'icon'
            self.current_section = "all"
            self.search_keyword = ""
            self.recently_used = {}
            self.sections = []  # 初始化分区列表
            
            # 私人空间相关变量
            self.password_file = os.path.join(os.path.expanduser('~'), '.private_space_password')
            self.private_space_data = {}
            self.status_var = ctk.StringVar(value="就绪")
            
            # 创建UI
            logger.info("创建UI")
            self._create_ui()
            
            # 确保视图按钮状态与默认视图模式一致
            if self.view_mode == 'icon':
                self.list_view_button.configure(fg_color="transparent")
                self.icon_view_button.configure(fg_color="#2b5797")
            else:
                self.list_view_button.configure(fg_color="#2b5797")
                self.icon_view_button.configure(fg_color="transparent")
            
            # 加载数据并更新显示
            logger.info("更新快捷方式显示")
            self._update_shortcuts_display()
            # 移除不必要的定时器和事件绑定，避免任何可能的重复更新
            # _display_icon_view方法现在使用固定的每行图标数量，不再依赖窗口尺寸计算
        except Exception as e:
            logger.error(f"ModernUI初始化失败: {e}")
            import traceback
            logger.error(f"错误堆栈: {traceback.format_exc()}")
            raise
    
    def _create_ui(self):
        # 使用grid布局实现更灵活的窗口结构
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(0, weight=1)
        
        # 创建主布局 - 使用圆角和阴影提升视觉效果
        self.main_frame = ctk.CTkFrame(self.root, corner_radius=10)
        self.main_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(2, weight=1)  # 内容区域权重最高
        
        # 基础事件绑定
        # 移除了复杂的嵌套函数和定时器，简化为基础事件绑定
        
        
        # 顶部导航栏
        self.header_frame = ctk.CTkFrame(self.main_frame, corner_radius=8)
        self.header_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        self.header_frame.grid_columnconfigure(0, weight=0)  # 标题列不扩展
        self.header_frame.grid_columnconfigure(1, weight=1)  # 操作区域扩展
        self.header_frame.grid_rowconfigure(0, weight=0)  # 第一行不扩展
        self.header_frame.grid_rowconfigure(1, weight=0)  # 第二行不扩展
        
        # 标题标签
        self.title_label = ctk.CTkLabel(
            self.header_frame, 
            text="小易", 
            font=ctk.CTkFont(size=24, weight="bold")
        )
        self.title_label.grid(row=0, column=0, padx=20, pady=10, sticky="w")
        
        # 右侧操作按钮区域
        self.operations_frame = ctk.CTkFrame(self.header_frame, fg_color="transparent")
        self.operations_frame.grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        # 设置操作区域的列权重
        self.operations_frame.grid_columnconfigure((0,1,2,3,4), weight=0)
        
        # 视图切换按钮
        self.view_buttons_frame = ctk.CTkFrame(self.operations_frame, fg_color="transparent")
        self.view_buttons_frame.grid(row=0, column=0, padx=5, pady=5)
        
        self.list_view_button = ctk.CTkButton(
            self.view_buttons_frame, 
            text="列表视图", 
            corner_radius=6,
            width=100,
            command=lambda: self._switch_view_mode('list')
        )
        self.icon_view_button = ctk.CTkButton(
            self.view_buttons_frame, 
            text="图标视图", 
            corner_radius=6,
            width=100,
            command=lambda: self._switch_view_mode('icon')
        )
        self.icon_view_button.grid(row=0, column=0, padx=2, pady=2)
        
        self.list_view_button.grid(row=0, column=1, padx=2, pady=2)
        
        # 添加按钮 - 下拉列表样式
        self.add_dropdown_frame = ctk.CTkFrame(self.operations_frame, fg_color="transparent")
        self.add_dropdown_frame.grid(row=0, column=1, padx=5, pady=5)
        
        # 下拉按钮主按钮 - 与其他按钮颜色一致
        self.add_dropdown_button = ctk.CTkButton(
            self.add_dropdown_frame,
            text="添加 ▼", 
            corner_radius=6,
            width=80,
            # 使用默认颜色，与其他按钮保持一致
            command=self.toggle_add_dropdown
        )
        self.add_dropdown_button.grid(row=0, column=0, padx=0, pady=0)
        
        # 下拉菜单框架（默认隐藏）
        self.dropdown_menu_frame = ctk.CTkFrame(
            self.add_dropdown_frame,
            fg_color="#6A0DAD",  # 深紫色背景
            corner_radius=6
        )
        
        # 下拉菜单选项
        self.dropdown_options = {
            "快捷方式": self._add_shortcut_file,
            "文件": self._add_file,
            "文件夹": self._add_folder,
            "网址": self._add_website
        }
        
        self.dropdown_buttons = {}
        for i, (text, command) in enumerate(self.dropdown_options.items()):
            button = ctk.CTkButton(
                self.dropdown_menu_frame,
                text=f"添加{text}",
                width=80,
                fg_color="transparent",
                text_color="white",
                hover_color="#9370DB",  # 浅紫色悬停颜色
                command=lambda cmd=command: self._dropdown_option_selected(cmd)
            )
            button.grid(row=i, column=0, padx=0, pady=0, sticky="ew")
            self.dropdown_buttons[text] = button
        
        # 下拉菜单状态
        self.dropdown_visible = False
        
        # 创建临时文件夹按钮
        self.create_temp_folder_button = ctk.CTkButton(
            self.operations_frame,
            text="创建临时文件夹",
            corner_radius=6,
            width=120,
            command=self._create_temporary_folder
        )
        self.create_temp_folder_button.grid(row=0, column=2, padx=5, pady=5)
        
        # 主题模式切换按钮
        self.theme_buttons_frame = ctk.CTkFrame(self.operations_frame, fg_color="transparent")
        self.theme_buttons_frame.grid(row=0, column=3, padx=5, pady=5)
        
        self.dark_mode_button = ctk.CTkButton(
            self.theme_buttons_frame,
            text="深色模式",
            corner_radius=6,
            width=80,
            fg_color="#2b5797" if ctk.get_appearance_mode() == "dark" else "#343638",
            command=lambda: self._switch_theme("dark")
        )
        self.dark_mode_button.grid(row=0, column=0, padx=2, pady=2)
        
        self.light_mode_button = ctk.CTkButton(
            self.theme_buttons_frame,
            text="浅色模式",
            corner_radius=6,
            width=80,
            fg_color="#343638" if ctk.get_appearance_mode() == "light" else "#343638",
            command=lambda: self._switch_theme("light")
        )
        self.light_mode_button.grid(row=0, column=1, padx=2, pady=2)
        
        # 私人空间按钮
        self.private_space_frame = ctk.CTkFrame(self.operations_frame, fg_color="transparent")
        self.private_space_frame.grid(row=0, column=4, padx=5, pady=5)
        
        self.private_space_button = ctk.CTkButton(
            self.private_space_frame,
            text="私人空间",
            corner_radius=6,
            width=100,
            fg_color="#9B59B6",  # 紫色作为私人空间的标识颜色
            hover_color="#8E44AD",
            command=self._open_private_space
        )
        self.private_space_button.grid(row=0, column=0, padx=2, pady=2)
        
        # 搜索框区域 - 放在单独的一行以确保在小窗口下正常显示
        self.search_frame = ctk.CTkFrame(self.header_frame, fg_color="transparent")
        self.search_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
        # 设置search_frame内部的列权重，让搜索框扩展
        self.search_frame.grid_columnconfigure(0, weight=1)
        logger.info("搜索框框架已配置为可扩展：sticky=ew, 列0权重=1")
        
        self.search_var = ctk.StringVar()
        
        # 搜索框 - 设置为自动扩展
        self.search_entry = ctk.CTkEntry(
            self.search_frame,
            textvariable=self.search_var,
            placeholder_text="搜索快捷方式...",
            corner_radius=6,
            width=150  # 设置一个基础宽度，但会通过权重自动扩展
        )
        self.search_entry.grid(row=0, column=0, padx=2, pady=5, sticky="ew")
        
        # 搜索按钮 - 确保按钮文本完整显示
        self.search_button = ctk.CTkButton(
            self.search_frame,
            text="搜索",
            corner_radius=6,
            width=60,
            height=28,  # 明确设置高度以匹配搜索框
            command=self._on_search_change
        )
        self.search_button.grid(row=0, column=1, padx=2, pady=5)
        
        # 清除按钮 - 确保按钮文本完整显示
        self.clear_button = ctk.CTkButton(
            self.search_frame,
            text="清除",
            corner_radius=6,
            width=60,
            height=28,  # 明确设置高度以匹配搜索框
            command=self._clear_search
        )
        self.clear_button.grid(row=0, column=2, padx=2, pady=5)
        
        # 分区导航标签栏 - 使用现代化的标签样式
        self.nav_frame = ctk.CTkFrame(self.main_frame, corner_radius=8)
        self.nav_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=0)
        self.nav_frame.grid_columnconfigure((0,1,2,3,4,5,6,7,8,9,10,11), weight=1)
        self.nav_frame.grid_columnconfigure(12, weight=0)  # 新建分区按钮列
        
        # 分区按钮 - 更现代的样式和布局
        self.section_buttons = {}
        
        # 基本分区
        basic_sections = ["all", "work", "entertainment", "document", "website", "folder", "recent"]
        basic_labels = ["全部", "工作", "娱乐", "文档", "网站", "文件夹", "最近使用"]
        
        # 合并所有分区
        all_sections = basic_sections
        all_labels = basic_labels
        
        for i, (section, label) in enumerate(zip(all_sections, all_labels)):
            # 设置按钮外观
            button_fg_color = "transparent"
            button_text_color = None
            
            self.section_buttons[section] = ctk.CTkButton(
                self.nav_frame, 
                text=label, 
                corner_radius=6,
                fg_color=button_fg_color,
                text_color=button_text_color,
                command=lambda s=section: self._filter_by_section(s)
            )
            self.section_buttons[section].grid(row=0, column=i, padx=5, pady=5, sticky="ew")
            
            # 为分区按钮添加拖放事件绑定（使用Tkinter支持的事件）
            # 注释掉不支持的拖放事件绑定
            # Tkinter不支持这些事件类型，会导致启动失败
            # self.section_buttons[section].bind("<DragEnter>", lambda event, s=section: self._on_section_drag_enter(event, s))
            # self.section_buttons[section].bind("<DragLeave>", lambda event, s=section: self._on_section_drag_leave(event, s))
            # self.section_buttons[section].bind("<Drop>", lambda event, s=section: self._on_section_drop(event, s))
            
            # 绑定右键菜单事件（仅对非系统默认分区有效）
            if section not in basic_sections:
                self.section_buttons[section].bind("<Button-3>", lambda event, s=section: self._show_section_context_menu(event, s))
        
        # 添加新建分区按钮
        self.add_section_button = ctk.CTkButton(
            self.nav_frame, 
            text="+ 新建分区", 
            corner_radius=6,
            width=100,
            command=self._add_new_section
        )
        self.add_section_button.grid(row=0, column=12, padx=5, pady=5, sticky="ew")
        
        # 初始化系统分区下拉菜单
        self.system_dropdown_visible = False
        self.system_dropdown_frame = None
        
        # 默认激活"全部"按钮
        self.section_buttons["all"].configure(fg_color="#2b5797")  # 使用蓝色作为选中状态颜色
        
        # 内容显示区域 - 使用滚动区域
        self.content_frame = ctk.CTkScrollableFrame(self.main_frame, corner_radius=8)
        self.content_frame.grid(row=2, column=0, sticky="nsew", padx=10, pady=10)
        self.content_frame.grid_columnconfigure(0, weight=1)
        
        # 为内容区域添加拖放支持
        self._setup_content_drag_and_drop()
        
        # 状态栏 - 显示当前状态信息
        self.status_frame = ctk.CTkFrame(self.main_frame, height=30, corner_radius=6)
        self.status_frame.grid(row=3, column=0, sticky="ew", padx=10, pady=5)
        
        self.status_label = ctk.CTkLabel(
            self.status_frame,
            textvariable=self.status_var,
            font=ctk.CTkFont(size=12)
        )
        self.status_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
    
    def _filter_by_section(self, section):
        """按分区筛选快捷方式"""
        try:
            # 更新当前分区
            self.current_section = section
            
            # 更新按钮状态
            for sec, button in self.section_buttons.items():
                if sec == section:
                    button.configure(fg_color="#2b5797")  # 选中状态
                    button.configure(text_color="white")
                else:
                    button.configure(fg_color="transparent")  # 未选中状态
                    button.configure(text_color=None)
        except Exception as e:
            if hasattr(self, 'logger') and self.logger:
                self.logger.error(f"分区过滤错误: {e}")
            if hasattr(self, 'status_var'):
                self.status_var.set(f"操作失败: {str(e)}")
        
        # 如果下拉菜单是打开的，关闭它
        if hasattr(self, 'dropdown_visible') and self.dropdown_visible:
            self.dropdown_menu_frame.grid_forget()
            self.dropdown_visible = False
            self.add_dropdown_button.configure(text="添加 ▼")
        
        # 更新显示
        self._update_shortcuts_display()
        
        # 更新状态栏
        section_labels = {
            "all": "全部",
            "work": "工作",
            "entertainment": "娱乐",
            "document": "文档",
            "website": "网站",
            "folder": "文件夹",
            "recent": "最近使用"
        }
        self.status_var.set(f"已切换到 {section_labels.get(section, section)} 分区")
    
    def _on_search_change(self, *args):
        """搜索按钮点击时更新显示"""
        self.search_keyword = self.search_var.get().lower()
        self._update_shortcuts_display()
    
    def _clear_search(self):
        """清除搜索内容"""
        self.search_var.set("")
        self.search_keyword = ""
        self._update_shortcuts_display()
        
    def _add_new_section(self):
        """创建新分区的对话框，包含输入验证、异常处理和键盘事件支持"""
        try:
            # 创建对话框
            dialog = ctk.CTkToplevel(self.root)
            dialog.title("新建分区")
            dialog.geometry("300x200")
            dialog.resizable(False, False)
            dialog.transient(self.root)  # 设置为主窗口的子窗口
            dialog.grab_set()  # 模态对话框
            
            # 添加键盘事件支持
            dialog.bind("<Escape>", lambda event: dialog.destroy())
            
            # 居中显示
            dialog.update_idletasks()
            width = dialog.winfo_width()
            height = dialog.winfo_height()
            x = (self.root.winfo_width() // 2) + self.root.winfo_x() - (width // 2)
            y = (self.root.winfo_height() // 2) + self.root.winfo_y() - (height // 2)
            dialog.geometry(f"{width}x{height}+{x}+{y}")
            
            # 创建输入框和按钮
            frame = ctk.CTkFrame(dialog)
            frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            # 标签
            label = ctk.CTkLabel(frame, text="请输入分区名称:")
            label.pack(pady=10)
            
            # 输入框
            section_var = ctk.StringVar()
            entry = ctk.CTkEntry(frame, textvariable=section_var, placeholder_text="分区名称")
            entry.pack(fill="x", pady=10)
            entry.focus()
            
            # 添加键盘事件支持
            entry.bind("<Return>", lambda event: validate_and_create())
            entry.bind("<Escape>", lambda event: dialog.destroy())
            
            # 状态标签
            status_var = ctk.StringVar()
            status_label = ctk.CTkLabel(frame, textvariable=status_var, text_color="#ff0000")
            status_label.pack(pady=5)
            
            # 验证并创建分区
            def validate_and_create():
                try:
                    section_name = section_var.get().strip()
                    
                    # 验证输入
                    if not section_name:
                        status_var.set("分区名称不能为空")
                        return
                    
                    # 检查特殊字符和保留名称
                    import re
                    if re.search(r'[<>\"/\\|?*]', section_name):
                        status_var.set("分区名称不能包含特殊字符: < > \" / \\ | ? *")
                        return
                    
                    # 检查是否与系统分区冲突
                    system_labels = {"桌面": "desktop", "文档": "documents", "下载": "downloads", 
                                    "图片": "pictures", "视频": "videos", "音乐": "music"}
                    if section_name in system_labels:
                        status_var.set(f"分区名称 '{section_name}' 为系统保留名称")
                        return
                    
                    # 检查是否已存在
                    if section_name.lower() in ["all", "recent"] or section_name in self.section_buttons:
                        status_var.set("该分区已存在")
                        return
                    
                    # 创建新分区
                    new_section_key = section_name
                    
                    # 添加到分区列表
                    if hasattr(self, 'sections'):
                        self.sections.append(new_section_key)
                    
                    # 将新分区添加到按钮列表
                    # 首先计算新按钮的位置
                    column_count = len(self.section_buttons)
                    
                    # 更新grid配置
                    self.nav_frame.grid_columnconfigure(column_count, weight=1)
                    self.nav_frame.grid_columnconfigure(column_count + 1, weight=0)  # 更新新建按钮的位置
                    
                    # 创建新按钮
                    self.section_buttons[new_section_key] = ctk.CTkButton(
                        self.nav_frame, 
                        text=section_name, 
                        corner_radius=6,
                        command=lambda s=new_section_key: self._filter_by_section(s)
                    )
                    self.section_buttons[new_section_key].grid(row=0, column=column_count, padx=5, pady=5, sticky="ew")
                    
                    # 为新创建的分区按钮绑定右键菜单事件和拖放事件
                    self.section_buttons[new_section_key].bind("<Button-3>", lambda event, s=new_section_key: self._show_section_context_menu(event, s))
                    self.section_buttons[new_section_key].bind("<DragEnter>", lambda event, s=new_section_key: self._on_section_drag_enter(event, s))
                    self.section_buttons[new_section_key].bind("<DragLeave>", lambda event, s=new_section_key: self._on_section_drag_leave(event, s))
                    self.section_buttons[new_section_key].bind("<Drop>", lambda event, s=new_section_key: self._on_section_drop(event, s))
                    
                    # 移动新建分区按钮
                    self.add_section_button.grid(row=0, column=column_count + 1)
                    
                    # 关闭对话框
                    dialog.destroy()
                    
                    # 更新状态栏
                    self.status_var.set(f"成功创建新分区: {section_name}")
                except Exception as e:
                    status_var.set(f"创建分区失败: {str(e)}")
                    logger.error(f"创建分区失败: {str(e)}")
            
            # 按钮框架
            buttons_frame = ctk.CTkFrame(frame, fg_color="transparent")
            buttons_frame.pack(fill="x", pady=10)
            
            # 创建按钮
            create_button = ctk.CTkButton(buttons_frame, text="创建", command=validate_and_create)
            create_button.pack(side="right", padx=5)
            
            # 取消按钮
            cancel_button = ctk.CTkButton(buttons_frame, text="取消", command=dialog.destroy)
            cancel_button.pack(side="right", padx=5)
        except Exception as e:
            logger.error(f"创建分区对话框失败: {str(e)}")
            messagebox.showerror("错误", f"创建分区对话框失败: {str(e)}")
    
    def _update_shortcuts_display(self):
        """更新快捷方式显示"""
        # 清除现有内容
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        # 获取所有快捷方式
        all_shortcuts = self.shortcuts_handler.get_all_shortcuts()
        
        # 根据当前分区和搜索关键词筛选快捷方式
        filtered_shortcuts = self._filter_shortcuts(all_shortcuts)
        
        # 确保数据格式正确
        if isinstance(filtered_shortcuts, dict):
            temp_shortcuts = []
            for name, data in filtered_shortcuts.items():
                temp_shortcuts.append((name, data))
            filtered_shortcuts = temp_shortcuts
        # 如果已经是列表，但第一个元素不是元组，则记录警告
        elif isinstance(filtered_shortcuts, list) and len(filtered_shortcuts) > 0 and not isinstance(filtered_shortcuts[0], tuple):
            logger.warning("快捷方式列表格式不正确，预期为(name, data)元组列表")
        
        # 根据视图模式显示快捷方式
        if self.view_mode == 'list':
            self._display_list_view(filtered_shortcuts)
        else:
            self._display_icon_view(filtered_shortcuts)
        
        # 更新状态栏
        self.status_var.set(f"共找到 {len(filtered_shortcuts)} 个快捷方式")
    
    def _filter_shortcuts(self, shortcuts):
        filtered = []
        
        # 确保shortcuts是字典类型
        if isinstance(shortcuts, dict):
            for name, data in shortcuts.items():
                # 搜索关键词筛选
                if self.search_keyword and self.search_keyword.lower() not in name.lower():
                    continue
                
                # 确保data是字典类型，如果不是，转换为字典
                if isinstance(data, str):
                    # 旧格式数据，转换为新格式
                    shortcut_data = {
                        "path": data,
                        "type": "folder" if os.path.isdir(data) else "file",
                        "icon": None
                    }
                else:
                    shortcut_data = data
                
                # 分区筛选
                if self.current_section == "all":
                    filtered.append((name, shortcut_data))
                elif self.current_section == "recent":
                    # 最近使用的快捷方式
                    if name in self.recently_used:
                        filtered.append((name, shortcut_data))
                else:
                    # 检查是否匹配自定义分区
                    section_mapping = {
                        "work": "工作",
                        "entertainment": "娱乐",
                        "document": "文档",
                        "website": "网站",
                        "folder": "文件夹"
                    }
                    
                    # 获取当前分区对应的显示名称
                    current_section_display = section_mapping.get(self.current_section, self.current_section)
                    
                    # 检查快捷方式的section字段是否匹配当前分区
                    if shortcut_data.get('section') == current_section_display:
                        filtered.append((name, shortcut_data))
                    # 特定类型筛选（作为备用方案）
                    elif self.current_section == "folder" and shortcut_data.get('type') == 'folder':
                        filtered.append((name, shortcut_data))
                    elif self.current_section == "website" and shortcut_data.get('type') == 'website':
                        filtered.append((name, shortcut_data))
                    elif shortcut_data.get('type') == 'file':
                        # 文件类型根据扩展名进一步分类
                        file_ext = os.path.splitext(shortcut_data.get('path', ''))[1].lower()
                        if self.current_section == "work" and file_ext in ['.docx', '.xlsx', '.pptx', '.pdf', '.txt', '.md']:
                            filtered.append((name, shortcut_data))
                        elif self.current_section == "entertainment" and file_ext in ['.mp3', '.mp4', '.avi', '.mkv', '.jpg', '.png']:
                            filtered.append((name, shortcut_data))
                        elif self.current_section == "document" and file_ext in ['.docx', '.pdf', '.txt', '.md']:
                            filtered.append((name, shortcut_data))
        
        # 如果是最近使用的分区，按使用时间排序
        if self.current_section == "recent":
            filtered.sort(key=lambda x: self.recently_used.get(x[0], 0), reverse=True)
        
        return filtered
    
    def _display_list_view(self, shortcuts):
        """列表视图显示快捷方式"""
        # 创建表头
        header_frame = ctk.CTkFrame(self.content_frame, corner_radius=6)
        header_frame.grid(row=0, column=0, sticky="ew", padx=0, pady=0)
        header_frame.grid_columnconfigure(0, weight=0)
        header_frame.grid_columnconfigure(1, weight=3)
        header_frame.grid_columnconfigure(2, weight=1)
        header_frame.grid_columnconfigure(3, weight=1)
        
        # 确保内容框架可以扩展到整个可用宽度
        self.content_frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(header_frame, text="", width=0).grid(row=0, column=0, padx=0, pady=0)
        ctk.CTkLabel(header_frame, text="名称", font=ctk.CTkFont(weight="bold")).grid(row=0, column=1, padx=184, pady=0,sticky="w")
        ctk.CTkLabel(header_frame, text="类型", font=ctk.CTkFont(weight="bold")).grid(row=0, column=2, padx=(0, 164), pady=0,sticky="w")
        ctk.CTkLabel(header_frame, text="操作", font=ctk.CTkFont(weight="bold")).grid(row=0, column=3, padx=(0, 15), pady=0,sticky="w")
        
        # 显示快捷方式列表
        for i, (name, data) in enumerate(shortcuts):
            # 使用交替行颜色提升可读性
            bg_color = "#2C2C2C" if i % 2 == 0 else "#363636"
            
            item_frame = ctk.CTkFrame(self.content_frame, corner_radius=6, fg_color=bg_color)
            item_frame.grid(row=i+1, column=0, sticky="ew", padx=0, pady=0)
            item_frame.grid_columnconfigure(0, weight=0)
            item_frame.grid_columnconfigure(1, weight=3)
            item_frame.grid_columnconfigure(2, weight=1)
            item_frame.grid_columnconfigure(3, weight=1)
            
            # 复选框
            checkbox_var = ctk.BooleanVar()
            checkbox = ctk.CTkCheckBox(item_frame, text="", variable=checkbox_var)
            checkbox.grid(row=0, column=0, padx=0, pady=0)
            
            # 名称标签
            type_icon = "📄"  # 默认图标
            if data.get('type') == 'folder':
                type_icon = "📁"
            elif data.get('type') == 'website':
                type_icon = "🌐"
            
            name_label = ctk.CTkLabel(
                item_frame, 
                text=f"{type_icon} {name}",
                font=ctk.CTkFont(size=14),
                width=200,
                cursor="hand2"
            )
            name_label.grid(row=0, column=1, padx=0, pady=0, sticky="w")
            name_label.bind("<Button-1>", lambda e, n=name: self._run_shortcut(n))
            name_label.bind("<Button-3>", lambda e, n=name: self._show_context_menu(e, n))
            
            # 文件后缀到中文类型名称的映射字典
            file_type_mapping = {
                # 文档类
                '.doc': 'Word文档', '.docx': 'Word文档',
                '.xls': 'Excel表格', '.xlsx': 'Excel表格',
                '.ppt': 'PowerPoint演示', '.pptx': 'PowerPoint演示',
                '.pdf': 'PDF文档',
                '.txt': '文本文档',
                '.md': 'Markdown文档',
                '.csv': 'CSV文件',
                '.rtf': '富文本文档',
                
                # 图片类
                '.jpg': 'JPEG图片', '.jpeg': 'JPEG图片',
                '.png': 'PNG图片',
                '.gif': 'GIF图片',
                '.bmp': '位图文件',
                '.tiff': 'TIFF图片', '.tif': 'TIFF图片',
                '.svg': 'SVG矢量图',
                
                # 音频类
                '.mp3': 'MP3音频',
                '.wav': 'WAV音频',
                '.flac': 'FLAC音频',
                '.m4a': 'M4A音频',
                
                # 视频类
                '.mp4': 'MP4视频',
                '.avi': 'AVI视频',
                '.mov': 'QuickTime视频',
                '.mkv': 'MKV视频',
                '.flv': 'FLV视频',
                
                # 压缩包类
                '.zip': 'ZIP压缩包',
                '.rar': 'RAR压缩包',
                '.7z': '7Z压缩包',
                '.tar': 'TAR压缩包',
                '.gz': 'GZIP压缩包',
                
                # 编程相关
                '.py': 'Python文件',
                '.js': 'JavaScript文件',
                '.html': 'HTML文件',
                '.css': 'CSS文件',
                '.java': 'Java文件',
                '.c': 'C语言文件',
                '.cpp': 'C++文件',
                '.h': '头文件',
                '.cs': 'C#文件',
                
                # 其他常见格式
                '.exe': '可执行文件',
                '.lnk': '快捷方式',
                '.iso': '光盘镜像',
                '.dll': '动态链接库',
                '.bat': '批处理文件',
                '.sh': 'Shell脚本',
            }
            
            # 确定类型文本
            type_text = ""
            shortcut_type = data.get('type', '').lower()
            
            if shortcut_type == 'folder':
                type_text = '文件夹'
            elif shortcut_type == 'website':
                type_text = '网址'
            elif shortcut_type == 'file':
                # 获取文件路径和后缀
                file_path = data.get('path', '')
                _, file_extension = os.path.splitext(file_path)
                file_extension = file_extension.lower()
                
                # 根据后缀获取中文类型名称，如果没有映射则显示文件类型
                type_text = file_type_mapping.get(file_extension, '文件')
            else:
                type_text = '未知类型'
            
            # 创建类型标签，使用统一字体和对齐方式
            type_label = ctk.CTkLabel(
                item_frame, 
                text=type_text,
                font=ctk.CTkFont(size=14), 
                anchor="center"  # 设置文本锚点居中
            )
            # 在单元格中完全填充并对齐
            type_label.grid(row=0, column=2, padx=0, pady=0, sticky="nsew")
            
            # 操作按钮
            actions_frame = ctk.CTkFrame(item_frame, fg_color="transparent")
            actions_frame.grid(row=0, column=3, padx=0, pady=0, sticky="e")
            # 设置列权重，使按钮均匀分布
            actions_frame.grid_columnconfigure(0, weight=1)
            actions_frame.grid_columnconfigure(1, weight=1)
            actions_frame.grid_columnconfigure(2, weight=1)
            
            # 统一按钮宽度和样式
            button_width = 60
            button_height = 28
            
            run_button = ctk.CTkButton(
                actions_frame,
                text="运行",
                width=button_width,
                height=button_height,
                corner_radius=4,
                font=ctk.CTkFont(size=12),
                command=lambda n=name: self._run_shortcut(n)
            )
            run_button.grid(row=0, column=0, padx=2, pady=2, sticky="ew")
            
            edit_button = ctk.CTkButton(
                actions_frame,
                text="编辑",
                width=button_width,
                height=button_height,
                corner_radius=4,
                font=ctk.CTkFont(size=12),
                command=lambda n=name: self._update_shortcut_dialog(n)
            )
            edit_button.grid(row=0, column=1, padx=2, pady=2, sticky="ew")
            
            # 删除按钮 - 红色样式
            delete_button = ctk.CTkButton(
                actions_frame,
                text="删除",
                width=button_width,
                height=button_height,
                corner_radius=4,
                font=ctk.CTkFont(size=12),
                fg_color="#e74c3c",
                hover_color="#c0392b",
                command=lambda n=name: self._delete_shortcut(n)
            )
            delete_button.grid(row=0, column=2, padx=2, pady=2, sticky="ew")
    
    def _display_icon_view(self, shortcuts):
        """图标视图显示快捷方式"""
        # 清空当前内容
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        # 获取内容框架的宽度，用于动态计算每行显示的图标数量
        # 考虑到每个图标项的宽度约为120 + 40(padx) = 160
        try:
            frame_width = self.content_frame.winfo_width()
            # 如果窗口尚未显示，使用默认值
            if frame_width <= 1:
                frame_width = 800  # 默认宽度
            
            # 计算每行可以显示的图标数量，确保至少显示3个
            icon_width = 160  # 图标宽度 + 左右边距
            icons_per_row = max(3, frame_width // icon_width)
            
            # 确保内容框架的列配置为左对齐
            for i in range(icons_per_row):
                self.content_frame.grid_columnconfigure(i, weight=0)
        except:
            # 如果获取窗口宽度失败，使用默认值
            icons_per_row = 6
        
        # 网格布局，一行排满后自动换行
        for i, (name, data) in enumerate(shortcuts):
            row = i // icons_per_row
            col = i % icons_per_row
            # 设置sticky为'nw'确保左对齐
            self._create_icon_item(name, data, row, col, self.content_frame)
        
        # 添加窗口大小变化的事件处理，以便在窗口大小改变时重新计算图标布局
        # 确保只注册一次事件处理
        if not hasattr(self, '_icon_view_configured'):
            def on_configure(event):
                # 避免循环更新
                if hasattr(self, '_last_width') and abs(event.width - self._last_width) < 50:
                    return
                self._last_width = event.width
                # 延迟更新以避免频繁刷新
                self.root.after(100, lambda: self._update_shortcuts_display())
            
            self.content_frame.bind('<Configure>', on_configure)
            self._icon_view_configured = True
            self._last_width = 0
    
    def _create_icon_item(self, name, data, row, col, parent_frame=None):
        """创建图标项"""
        logger.debug(f"创建图标项: {name}, 数据: {data}")
        # 确定父框架
        if parent_frame is None:
            parent_frame = self.content_frame
        
        # 模拟Windows桌面图标样式的按钮
        item_frame = ctk.CTkButton(
            parent_frame,
            text="",
            width=120,
            height=130,
            fg_color="transparent",
            hover_color="#3b82f6",  # 使用蓝色替代rgba格式
            corner_radius=0,
            command=lambda n=name: self._run_shortcut(n)
        )
        item_frame.grid(row=row, column=col, padx=20, pady=20, sticky="nw")  # 使用nw确保左对齐
        item_frame.grid_columnconfigure(0, weight=1)
        
        # 图标区域 - 尝试获取并显示原始图标
        path = data.get('path', '')
        shortcut_type = data.get('type', 'file')
        
        # 初始化LRU图标缓存（作为类属性而非实例属性）
        if not hasattr(ModernUI, '_icon_cache'):
            # 使用OrderedDict实现LRU缓存，限制最大缓存数量
            from collections import OrderedDict
            ModernUI._icon_cache = OrderedDict()
            ModernUI._icon_cache_max_size = 1000  # 最大缓存数量
            ModernUI._icon_cache_hits = 0  # 缓存命中计数
            ModernUI._icon_cache_misses = 0  # 缓存未命中计数
            logger.debug("初始化全局LRU图标缓存，最大容量: 1000")
        
        # 创建默认图标标签作为后备
        icon_label = None
        icon_photo = None
        
        try:
            # 无论什么类型都尝试获取原始图标，包括website
            if path:
                try:
                    # 标准化路径以提高缓存命中率
                    if isinstance(path, str) and path.strip():
                        normalized_path = os.path.normpath(path)
                        logger.debug(f"标准化路径: {path} -> {normalized_path}")
                        
                        # 检查缓存
                        cache_key = normalized_path
                        if cache_key in ModernUI._icon_cache:
                            # 缓存命中，将该项移到最后（最近使用）
                            icon_photo = ModernUI._icon_cache.pop(cache_key)
                            ModernUI._icon_cache[cache_key] = icon_photo
                            ModernUI._icon_cache_hits += 1
                            logger.debug(f"从LRU缓存获取图标: {cache_key} (缓存命中: {ModernUI._icon_cache_hits}, 未命中: {ModernUI._icon_cache_misses})")
                        else:
                            # 缓存未命中，创建新图标
                            ModernUI._icon_cache_misses += 1
                            # 即使路径不存在也尝试获取图标（可能是URL或其他特殊路径）
                            is_folder = shortcut_type == 'folder'
                            logger.debug(f"调用_get_file_icon获取图标，路径: {normalized_path}, 是否文件夹: {is_folder}")
                            icon_photo = self._get_file_icon(normalized_path, is_folder)
                            
                            if icon_photo is not None:
                                # 检查缓存大小，如果超过限制，删除最旧的项（最不常用）
                                if len(ModernUI._icon_cache) >= ModernUI._icon_cache_max_size:
                                    oldest_key, _ = ModernUI._icon_cache.popitem(last=False)
                                    logger.debug(f"缓存已满，移除最旧项: {oldest_key}")
                                
                                # 添加到缓存，放在最后（最近使用）
                                ModernUI._icon_cache[cache_key] = icon_photo
                                logger.debug(f"图标添加到LRU缓存: {cache_key} (当前缓存大小: {len(ModernUI._icon_cache)})")
                            else:
                                logger.warning(f"_get_file_icon返回None: {normalized_path}")
                    else:
                        logger.warning(f"无效的路径: {path}")
                except Exception as e:
                    logger.error(f"获取图标过程出错: {e}", exc_info=True)
            
            # 如果成功获取图标则使用，否则使用默认图标
            if icon_photo is not None:
                try:
                    # 创建图标标签，强制设置固定尺寸为48x48
                    icon_label = ctk.CTkLabel(
                        item_frame,
                        image=icon_photo,
                        text="",  # 空文本，确保只显示图标
                        width=48,  # 固定宽度48
                        height=48,  # 固定高度48
                        anchor="center"
                    )
                    # 保存引用防止被垃圾回收 - 关键修复：将图标引用存储在标签对象上
                    icon_label.image = icon_photo
                    # 保存引用在框架上也很重要，双重保险
                    item_frame.icon_reference = icon_photo
                    logger.debug(f"成功创建图标标签并设置图片: {name}, 图标对象类型: {type(icon_photo)}, 尺寸: {icon_photo.width()}x{icon_photo.height()}")
                except Exception as e:
                    logger.error(f"创建图标标签失败: {e}", exc_info=True)
                    icon_label = None
            
            # 确保有一个有效的图标标签
            if icon_label is None:
                # 显示不同类型的默认emoji图标，根据文件类型提供更丰富的emoji
                if shortcut_type == 'folder':
                    icon_text = "📁"
                elif shortcut_type == 'website':
                    icon_text = "🌐"
                elif path and path.lower().endswith('.exe'):
                    icon_text = "⚙️"
                elif path and path.lower().endswith(('.pdf', '.doc', '.docx')):
                    icon_text = "📄"
                elif path and path.lower().endswith(('.jpg', '.jpeg', '.png', '.gif')):
                    icon_text = "🖼️"
                elif path and path.lower().endswith(('.mp3', '.wav', '.flac')):
                    icon_text = "🎵"
                elif path and path.lower().endswith(('.mp4', '.avi', '.mov')):
                    icon_text = "🎬"
                else:
                    icon_text = "📄"  # 默认图标
                
                icon_label = ctk.CTkLabel(
                    item_frame,
                    text=icon_text,
                    font=ctk.CTkFont(size=40)
                )
                logger.debug(f"使用默认emoji图标: {name}, 类型: {shortcut_type}, emoji: {icon_text}")
        except Exception as e:
            logger.error(f"创建图标项时发生异常: {e}", exc_info=True)
            # 终极异常处理，确保总是有一个有效的图标标签
            icon_label = ctk.CTkLabel(
                item_frame,
                text="📄",
                font=ctk.CTkFont(size=40)
            )
            logger.debug("使用终极异常处理图标")
        
        icon_label.grid(row=0, column=0, pady=(10, 5))
        
        # 名称标签 - 居中显示，不包含图标，支持文本换行
        name_label = ctk.CTkLabel(
            item_frame,
            text=name,
            font=ctk.CTkFont(size=12),
            width=120,
            cursor="hand2",
            wraplength=110,
            anchor="center"
        )
        name_label.grid(row=1, column=0, pady=5)
        
        # 右键菜单支持
        item_frame.bind("<Button-3>", lambda e, n=name: self._show_context_menu(e, n))
        
        # 保存名称和数据到框架上，用于拖动功能
        item_frame.shortcut_name = name
        item_frame.shortcut_data = data
        
        # 添加拖动支持
        item_frame.bind("<Button-1>", self._on_item_drag_start)
        item_frame.bind("<B1-Motion>", self._on_item_drag_motion)
        item_frame.bind("<ButtonRelease-1>", self._on_item_drag_end)
    
    def toggle_add_dropdown(self):
        """切换下拉菜单的显示/隐藏状态"""
        if self.dropdown_visible:
            # 隐藏下拉菜单
            self.dropdown_menu_frame.grid_forget()
            self.dropdown_visible = False
            self.add_dropdown_button.configure(text="添加 ▼")
        else:
            # 显示下拉菜单
            self.dropdown_menu_frame.grid(row=1, column=0, padx=0, pady=0, sticky="ew")
            self.dropdown_visible = True
            self.add_dropdown_button.configure(text="添加 ▲")  # 改为向上箭头
        
        # 绑定点击外部关闭下拉菜单的事件
        if self.dropdown_visible:
            self.root.bind("<Button-1>", self._close_dropdown_on_click_outside)
    
    def _dropdown_option_selected(self, command):
        """选择下拉菜单选项后执行的操作"""
        # 先隐藏下拉菜单
        self.dropdown_menu_frame.grid_forget()
        self.dropdown_visible = False
        self.add_dropdown_button.configure(text="添加 ▼")
        
        # 执行选中的命令
        command()
        
    def _show_system_dropdown(self):
        """显示系统分区下拉菜单"""
        # 如果已经显示，则隐藏
        if hasattr(self, 'system_dropdown_visible') and self.system_dropdown_visible and hasattr(self, 'system_dropdown_frame'):
            self.system_dropdown_frame.grid_forget()
            self.system_dropdown_visible = False
            return
        
        # 隐藏其他可能打开的下拉菜单
        if hasattr(self, 'dropdown_visible') and self.dropdown_visible and hasattr(self, 'dropdown_menu_frame'):
            self.dropdown_menu_frame.grid_forget()
            self.dropdown_visible = False
            if hasattr(self, 'add_dropdown_button'):
                self.add_dropdown_button.configure(text="添加 ▼")
        
        # 创建下拉菜单框架
        if not hasattr(self, 'system_dropdown_frame') or self.system_dropdown_frame is None:
            self.system_dropdown_frame = ctk.CTkFrame(
                self.nav_frame, 
                corner_radius=8,
                fg_color="#2b5797"  # 与系统分区按钮颜色一致
            )
            
            # 添加下拉菜单选项
            menu_items = [
                ("this_pc", "此电脑", lambda: self._filter_by_section("this_pc")),
                ("network", "网络", lambda: self._filter_by_section("network"))
            ]
            
            for i, (item_id, label, command) in enumerate(menu_items):
                button = ctk.CTkButton(
                    self.system_dropdown_frame,
                    text=label,
                    corner_radius=6,
                    fg_color="transparent",  # 透明背景，继承框架颜色
                    text_color="white",  # 白色文字
                    hover_color="#3b67a7",  # 悬停颜色稍亮
                    width=200,
                    command=command
                )
                button.grid(row=i, column=0, padx=5, pady=2, sticky="ew")
        
        # 获取系统按钮的位置
        system_button = self.section_buttons.get("system")
        if system_button:
            # 计算下拉菜单的位置
            x = system_button.winfo_x()
            y = system_button.winfo_y() + system_button.winfo_height() + 5
            
            # 显示下拉菜单
            self.system_dropdown_frame.grid(row=1, column=0, padx=x, pady=y, sticky="nw")
            self.system_dropdown_visible = True
            
            # 添加点击外部关闭下拉菜单的事件
            self.root.bind("<Button-1>", self._close_system_dropdown_on_click_outside, add="+")
            
    def _close_system_dropdown_on_click_outside(self, event):
        """点击下拉菜单外部时关闭下拉菜单"""
        if hasattr(self, 'system_dropdown_visible') and self.system_dropdown_visible and hasattr(self, 'system_dropdown_frame'):
            # 检查点击是否在下拉菜单内
            x, y, width, height = self.system_dropdown_frame.winfo_x(), self.system_dropdown_frame.winfo_y(), \
                                 self.system_dropdown_frame.winfo_width(), self.system_dropdown_frame.winfo_height()
            
            # 检查点击是否在系统按钮内
            system_button = self.section_buttons.get("system")
            button_x, button_y, button_width, button_height = 0, 0, 0, 0
            if system_button:
                button_x, button_y, button_width, button_height = system_button.winfo_x(), system_button.winfo_y(), \
                                                                 system_button.winfo_width(), system_button.winfo_height()
            
            # 如果点击不在下拉菜单和按钮内，则关闭下拉菜单
            if not ((x <= event.x <= x + width and y <= event.y <= y + height) or 
                    (button_x <= event.x <= button_x + button_width and button_y <= event.y <= button_y + button_height)):
                self.system_dropdown_frame.grid_forget()
                self.system_dropdown_visible = False
                self.root.unbind("<Button-1>", self._close_system_dropdown_on_click_outside)
    
    def _handle_button_release(self, event):
        """处理按钮释放事件，作为拖放的备选方案"""
        # 此方法主要用于兼容性，实际的Windows拖放通过WM_DROPFILES消息处理
        pass
        
    def _close_dropdown_on_click_outside(self, event):
        """点击下拉菜单外部时关闭下拉菜单"""
        # 检查点击是否在下拉菜单区域外
        if not self.add_dropdown_frame.winfo_containing(event.x_root, event.y_root):
            self.dropdown_menu_frame.grid_forget()
            self.dropdown_visible = False
            self.add_dropdown_button.configure(text="添加 ▼")
            # 解除绑定
            self.root.unbind("<Button-1>")
    
    def _switch_theme(self, theme):
        """切换主题模式：深色或浅色"""
        ctk.set_appearance_mode(theme)
        
        # 更新按钮状态
        if theme == 'dark':
            self.dark_mode_button.configure(fg_color="#2b5797")
            self.light_mode_button.configure(fg_color="transparent")
        else:
            self.dark_mode_button.configure(fg_color="transparent")
            self.light_mode_button.configure(fg_color="#2b5797")
        
        # 重新显示快捷方式以应用新主题
        self._update_shortcuts_display()
    
    def _switch_view_mode(self, mode):
        """切换视图模式"""
        self.view_mode = mode
        
        # 更新按钮状态 - 使用更可靠的颜色设置
        if mode == 'list':
            self.list_view_button.configure(fg_color="#2b5797")  # 选中颜色
            self.icon_view_button.configure(fg_color="transparent")  # 重置为默认颜色
        else:
            self.list_view_button.configure(fg_color="transparent")  # 重置为默认颜色
            self.icon_view_button.configure(fg_color="#2b5797")  # 选中颜色
        
        # 更新显示
        self._update_shortcuts_display()
    
    def _create_temporary_folder(self):
        """打开D盘下的临时文件夹（不存在则创建）"""
        try:
            # 使用正确的Windows路径格式
            if sys.platform.startswith('win'):
                temp_folder_path = 'D:\\临时文件夹'
            else:
                temp_folder_path = os.path.join('D:', "临时文件夹")
            
            logger.info(f"检查临时文件夹: {temp_folder_path}")
            
            # 确保临时文件夹存在
            if not os.path.exists(temp_folder_path):
                logger.info(f"临时文件夹不存在，尝试创建: {temp_folder_path}")
                try:
                    # 创建文件夹，包括所有必要的中间目录
                    os.makedirs(temp_folder_path, exist_ok=True)
                    logger.info(f"成功创建临时文件夹: {temp_folder_path}")
                except Exception as create_error:
                    logger.error(f"创建临时文件夹失败: {create_error}")
                    self.status_var.set(f"创建临时文件夹失败: {str(create_error)}")
                    messagebox.showerror("错误", f"创建临时文件夹失败: {str(create_error)}")
                    return
            else:
                logger.info(f"临时文件夹已存在: {temp_folder_path}")
            
            # 显示操作消息
            self.status_var.set(f"已打开临时文件夹: {temp_folder_path}")
            
            # 打开临时文件夹
            try:
                if sys.platform.startswith('win'):
                    logger.info(f"尝试使用os.startfile打开: {temp_folder_path}")
                    os.startfile(temp_folder_path)
                else:
                    logger.info(f"尝试使用xdg-open打开: {temp_folder_path}")
                    subprocess.run(["xdg-open", temp_folder_path])
            except Exception as open_error:
                logger.error(f"打开临时文件夹失败: {open_error}")
                # 尝试使用cmd作为备选方案
                if sys.platform.startswith('win'):
                    try:
                        logger.info(f"尝试使用cmd打开: {temp_folder_path}")
                        subprocess.run(["cmd", "/c", "start", "", temp_folder_path], shell=False)
                    except Exception as cmd_error:
                        logger.error(f"使用cmd打开也失败: {cmd_error}")
                        self.status_var.set(f"打开临时文件夹失败: {str(cmd_error)}")
                        messagebox.showerror("错误", f"打开临时文件夹失败: {str(cmd_error)}")
                else:
                    self.status_var.set(f"打开临时文件夹失败: {str(open_error)}")
                    messagebox.showerror("错误", f"打开临时文件夹失败: {str(open_error)}")
                
        except Exception as e:
            logger.error(f"创建临时文件夹失败: {e}")
            messagebox.showerror("错误", f"创建临时文件夹失败: {str(e)}")
    
    def _setup_content_drag_and_drop(self):
        """为主内容区域设置拖放支持"""
        try:
            logger.info("设置内容区域拖放支持")
            
            # 确保内容框架存在
            if hasattr(self, 'content_frame'):
                # Windows系统特殊处理
                if sys.platform == 'win32' and hasattr(win32con, 'CF_HDROP'):
                    # 获取内容框架的窗口句柄
                    content_hwnd = self.content_frame.winfo_id()
                    logger.info(f"内容框架窗口句柄: {content_hwnd}")
                    
                    # 注册内容框架为拖放目标
                    try:
                        ctypes.windll.shell32.DragAcceptFiles(content_hwnd, True)
                        logger.info("内容框架拖放目标注册成功")
                    except Exception as e:
                        logger.error(f"内容框架拖放目标注册失败: {e}")
                    
                    # 为内容框架窗口设置消息处理器
                    try:
                        # 定义Windows消息常量
                        WM_DROPFILES = 0x233
                        
                        # 获取原始窗口过程
                        original_wndproc = win32gui.GetWindowLongPtr(content_hwnd, win32con.GWL_WNDPROC)
                        
                        # 定义新的窗口过程回调函数
                        def content_wndproc(hwnd, msg, wParam, lParam):
                            if msg == WM_DROPFILES:
                                try:
                                    logger.info("内容框架接收到拖放文件事件")
                                    # 创建一个临时事件对象来调用_on_drop方法
                                    class TempEvent:
                                        def __init__(self, hdrop):
                                            self.widget = self
                                            self.data = hdrop
                                    
                                    # 调用现有的_on_drop方法处理拖放的文件
                                    self._on_drop(TempEvent(wParam))
                                except Exception as e:
                                    logger.error(f"处理内容框架拖放事件时出错: {e}")
                                return 0
                            # 调用原始窗口过程处理其他消息
                            return win32gui.CallWindowProc(original_wndproc, hwnd, msg, wParam, lParam)
                        
                        # 保存原始窗口过程引用以防止被垃圾回收
                        self._content_original_wndproc = original_wndproc
                        
                        # 设置新的窗口过程
                        win32gui.SetWindowLongPtr(content_hwnd, win32con.GWL_WNDPROC, content_wndproc)
                        logger.info("内容框架窗口过程设置成功")
                    except Exception as e:
                        logger.error(f"设置内容框架窗口过程失败: {e}")
                
                # 为所有视图模式添加通用的拖放事件处理
                # 绑定拖放进入、悬停和离开事件，提供视觉反馈
                self.content_frame.bind("<<DragEnter>>", self._on_content_drag_enter)
                self.content_frame.bind("<<DragLeave>>", self._on_content_drag_leave)
                
                logger.info("内容区域拖放支持设置完成")
        except Exception as e:
            logger.error(f"设置内容区域拖放支持时出错: {e}")
    
    def _on_content_drag_enter(self, event):
        """处理拖放进入内容区域事件"""
        logger.info("拖放进入内容区域")
        # 可以在这里添加视觉反馈，比如改变框架背景色
    
    def _on_content_drag_leave(self, event):
        """处理拖放离开内容区域事件"""
        logger.info("拖放离开内容区域")
        # 可以在这里恢复视觉反馈
    
    def _on_section_drag_enter(self, event, section):
        """当拖拽进入分区按钮时的处理"""
        try:
            # 更改按钮颜色以提供视觉反馈
            event.widget.configure(fg_color="#e0e0e0")
            # 确保事件传播
            return "break"
        except Exception as e:
            logger.error(f"处理拖放进入分区按钮时出错: {e}")
    
    def _on_item_drag_start(self, event):
        """
        处理图标项拖动开始事件
        """
        # 记录拖动开始时的位置和项信息
        widget = event.widget
        if hasattr(widget, 'shortcut_name'):
            self.dragging_item = widget.shortcut_name
            self.dragging_data = widget.shortcut_data
            self.drag_start_x = event.x_root
            self.drag_start_y = event.y_root
            # 创建拖动时的视觉效果（临时透明度变化）
            if hasattr(widget, 'configure'):
                widget.configure(state="disabled")
            logger.debug(f"开始拖动项目: {widget.shortcut_name}")
    
    def _on_item_drag_motion(self, event):
        """
        处理图标项拖动运动事件
        """
        if not hasattr(self, 'dragging_item') or not self.dragging_item:
            return
            
        # 计算拖动距离
        dx = abs(event.x_root - self.drag_start_x)
        dy = abs(event.y_root - self.drag_start_y)
        
        # 只有拖动足够距离才视为有效拖动
        if dx > 5 or dy > 5:
            # 可以在这里添加更多拖动时的视觉反馈
            pass
    
    def _on_item_drag_end(self, event):
        """
        处理图标项拖动结束事件，检查是否拖放到分区按钮上
        """
        if not hasattr(self, 'dragging_item') or not self.dragging_item:
            return
            
        try:
            # 获取鼠标释放位置的窗口组件
            widget_under_mouse = self.root.winfo_containing(event.x_root, event.y_root)
            
            # 检查是否拖放到了分区按钮上
            for section, button in self.section_buttons.items():
                if widget_under_mouse == button or widget_under_mouse in button.winfo_children():
                    # 找到目标分区，更新快捷方式的分区信息
                    if self.dragging_data:
                        # 从旧数据中移除该项目
                        old_section = self.dragging_data.get('section', '未分类')
                        if old_section in self.shortcuts_handler.shortcuts and self.dragging_item in self.shortcuts_handler.shortcuts[old_section]:
                            del self.shortcuts_handler.shortcuts[old_section][self.dragging_item]
                            
                            # 如果旧分区为空，删除该分区
                            if not self.shortcuts_handler.shortcuts[old_section]:
                                del self.shortcuts_handler.shortcuts[old_section]
                        
                        # 添加到新分区
                        if section not in self.shortcuts_handler.shortcuts:
                            self.shortcuts_handler.shortcuts[section] = {}
                        self.shortcuts_handler.shortcuts[section][self.dragging_item] = self.dragging_data
                        
                        # 更新分区信息
                        self.dragging_data['section'] = section
                        
                        # 保存更改
                        self.shortcuts_handler.save_shortcuts()
                        
                        # 更新显示
                        self._update_shortcuts_display()
                        
                        logger.info(f"成功将项目 '{self.dragging_item}' 从 '{old_section}' 移动到分区 '{section}'")
                        
                        # 显示提示信息
                        messagebox.showinfo("成功", f"项目已移动到分区 '{section}'")
            
        except Exception as e:
            logger.error(f"处理项目拖动结束时出错: {str(e)}")
        finally:
            # 重置拖动状态
            del self.dragging_item
            del self.dragging_data
            # 恢复原始组件状态
            if hasattr(event.widget, 'configure'):
                event.widget.configure(state="normal")
            return "break"
    
    def _on_section_drag_over(self, event, section):
        """当拖拽经过分区按钮时的处理"""
        try:
            # 允许拖放操作
            event.widget.configure(state="active")
            # 检查是否是来自应用内部的图标拖放
            if hasattr(self, 'dragging_item') and self.dragging_item:
                # 内部图标拖放时的特殊处理
                pass
            return "break"
        except Exception as e:
            logger.error(f"分区按钮拖放经过错误: {e}")
            return "break"
    
    def _on_section_drag_leave(self, event, section):
        """当拖拽离开分区按钮时的处理"""
        try:
            # 恢复按钮颜色
            event.widget.configure(fg_color="transparent")
            event.widget.configure(state="normal")
            return "break"
        except Exception as e:
            logger.error(f"分区按钮拖放离开错误: {e}")
            return "break"
    
    def _on_section_drop(self, event, section):
        """当在分区按钮上放下文件时的处理"""
        try:
            # 恢复按钮颜色
            event.widget.configure(fg_color="transparent")
            event.widget.configure(state="normal")
            
            # 检查是否是内部图标拖放
            if hasattr(self, 'dragging_item') and self.dragging_item:
                # 内部图标拖放处理已经在_on_item_drag_end中完成
                # 这里只需要清除拖动状态
                if hasattr(self, 'dragging_item'):
                    del self.dragging_item
                if hasattr(self, 'dragging_data'):
                    del self.dragging_data
                return "break"
            
            # 处理Windows拖放数据
            import ctypes
            from ctypes import wintypes
            
            # 尝试获取HDROP句柄
            try:
                # 获取拖放信息
                hdrop = event.data
                if isinstance(hdrop, int):
                    # 处理HDROP句柄
                    file_paths = []
                    shell32 = ctypes.windll.shell32
                    
                    # 获取文件数量
                    file_count = shell32.DragQueryFileW(hdrop, -1, None, 0)
                    
                    # 获取每个文件的路径
                    for i in range(file_count):
                        # 先获取路径长度
                        buffer_size = shell32.DragQueryFileW(hdrop, i, None, 0)
                        if buffer_size > 0:
                            # 创建缓冲区
                            buffer = ctypes.create_unicode_buffer(buffer_size + 1)
                            # 获取路径
                            shell32.DragQueryFileW(hdrop, i, buffer, buffer_size + 1)
                            file_paths.append(buffer.value)
                    
                    # 释放HDROP句柄
                    shell32.DragFinish(hdrop)
                elif isinstance(hdrop, str):
                    # 处理字符串格式的拖放数据
                    file_paths = hdrop.split('{#}')
                else:
                    # 尝试从event.data获取文件路径
                    file_paths = []
                    if hasattr(event, 'data'):
                        if isinstance(event.data, str):
                            file_paths = [event.data]
            except Exception:
                # 失败时尝试从剪贴板获取
                file_paths = []
            
            # 如果有文件被拖放，处理它们
            if file_paths:
                # 先切换到目标分区
                self._filter_by_section(section)
                
                # 处理每个文件
                for file_path in file_paths:
                    # 调用现有的_on_drop方法处理文件
                    # 创建一个临时事件对象来传递数据
                    class TempEvent:
                        def __init__(self, data):
                            self.data = data
                    
                    temp_event = TempEvent(file_path)
                    self._on_drop(temp_event)
            
            return "break"
        except Exception as e:
            logger.error(f"分区按钮拖放处理错误: {e}")
            # 显示错误消息
            if hasattr(self, 'status_var'):
                self.status_var.set(f"拖放失败: {str(e)}")
            return "break"
    
    def _on_item_drag_start(self, event):
        """
        处理图标项拖动开始事件
        """
        # 记录拖动开始时的位置和项信息
        widget = event.widget
        if hasattr(widget, 'shortcut_name'):
            self.dragging_item = widget.shortcut_name
            self.dragging_data = widget.shortcut_data
            self.drag_start_x = event.x_root
            self.drag_start_y = event.y_root
            # 创建拖动时的视觉效果
            if hasattr(widget, 'configure'):
                widget.configure(state="disabled")
            logger.debug(f"开始拖动项目: {widget.shortcut_name}")
    
    def _on_item_drag_motion(self, event):
        """
        处理图标项拖动运动事件
        """
        if not hasattr(self, 'dragging_item') or not self.dragging_item:
            return
            
        # 计算拖动距离
        dx = abs(event.x_root - self.drag_start_x)
        dy = abs(event.y_root - self.drag_start_y)
        
        # 只有拖动足够距离才视为有效拖动
        if dx > 5 or dy > 5:
            # 可以在这里添加更多拖动时的视觉反馈
            pass
    
    def _on_item_drag_end(self, event):
        """
        处理图标项拖动结束事件，检查是否拖放到分区按钮上
        """
        if not hasattr(self, 'dragging_item') or not self.dragging_item:
            return
            
        try:
            # 获取鼠标释放位置的窗口组件
            widget_under_mouse = self.root.winfo_containing(event.x_root, event.y_root)
            
            # 检查是否拖放到了分区按钮上
            for section, button in self.section_buttons.items():
                if widget_under_mouse == button or widget_under_mouse in button.winfo_children():
                    # 找到目标分区，更新快捷方式的分区信息
                    if self.dragging_data:
                        # 从旧数据中移除该项目
                        old_section = self.dragging_data.get('section', '未分类')
                        if old_section in self.shortcuts_handler.shortcuts and self.dragging_item in self.shortcuts_handler.shortcuts[old_section]:
                            del self.shortcuts_handler.shortcuts[old_section][self.dragging_item]
                            
                            # 如果旧分区为空，删除该分区
                            if not self.shortcuts_handler.shortcuts[old_section]:
                                del self.shortcuts_handler.shortcuts[old_section]
                        
                        # 添加到新分区
                        if section not in self.shortcuts_handler.shortcuts:
                            self.shortcuts_handler.shortcuts[section] = {}
                        self.shortcuts_handler.shortcuts[section][self.dragging_item] = self.dragging_data
                        
                        # 更新分区信息
                        self.dragging_data['section'] = section
                        
                        # 保存更改
                        self.shortcuts_handler.save_shortcuts()
                        
                        # 更新显示
                        self._update_shortcuts_display()
                        
                        logger.info(f"成功将项目 '{self.dragging_item}' 从 '{old_section}' 移动到分区 '{section}'")
                        
                        # 显示提示信息
                        messagebox.showinfo("成功", f"项目已移动到分区 '{section}'")
        except Exception as e:
            logger.error(f"处理项目拖动结束时出错: {str(e)}")
        finally:
            # 重置拖动状态
            if hasattr(self, 'dragging_item'):
                del self.dragging_item
            if hasattr(self, 'dragging_data'):
                del self.dragging_data
            # 恢复原始组件状态
            if hasattr(event.widget, 'configure'):
                event.widget.configure(state="normal")
    
    def _show_context_menu(self, event, name):
        """显示右键菜单"""
        context_menu = Menu(self.root, tearoff=0, font=ctk.CTkFont(size=12))
        
        context_menu.add_command(label="运行", command=lambda: self._run_shortcut(name))
        context_menu.add_command(label="编辑", command=lambda: self._update_shortcut_dialog(name))
        context_menu.add_separator()
        context_menu.add_command(label="删除", command=lambda: self._delete_shortcut(name))
        
        try:
            context_menu.post(event.x_root, event.y_root)
        except Exception as e:
            logger.error(f"显示右键菜单失败: {e}")
    
    def _show_section_context_menu(self, event, section):
        """显示分区右键菜单"""
        # 只允许删除自定义分区，不允许删除默认分区
        basic_sections = ["all", "work", "entertainment", "document", "website", "folder", "recent"]
        if section in basic_sections:
            return
        
        context_menu = Menu(self.root, tearoff=0, font=ctk.CTkFont(size=12))
        context_menu.add_command(label="删除分区", command=lambda: self._delete_section(section))
        
        try:
            context_menu.post(event.x_root, event.y_root)
        except Exception as e:
            logger.error(f"显示分区右键菜单失败: {e}")
    
    def _delete_section(self, section):
        """删除分区"""
        try:
            # 确认删除
            confirm = messagebox.askyesno("确认删除", f"确定要删除分区 '{section}' 吗？\n请注意：该分区下的快捷方式将不会被删除，它们仍然可以在'全部'分区中查看。")
            if not confirm:
                return
            
            # 获取要删除按钮的列号
            delete_col = None
            for s, button in self.section_buttons.items():
                info = button.grid_info()
                if s == section:
                    delete_col = info['column']
                    break
            
            if delete_col is None:
                raise ValueError(f"未找到分区 '{section}'")
            
            # 从UI中移除按钮
            self.section_buttons[section].destroy()
            del self.section_buttons[section]
            
            # 重新排列按钮
            basic_sections = ["all", "work", "entertainment", "document", "website", "folder", "recent"]
            custom_sections = [s for s in self.section_buttons.keys() if s not in basic_sections and s != "recent"]
            
            # 构建新的分区顺序
            new_order = basic_sections.copy()
            if "recent" in self.section_buttons:
                new_order.append("recent")
            new_order.extend(custom_sections)
            
            # 重新布局按钮
            for i, s in enumerate(new_order):
                if s in self.section_buttons:
                    self.section_buttons[s].grid(row=0, column=i, padx=5, pady=5, sticky="ew")
            
            # 更新新建分区按钮位置
            self.add_section_button.grid(row=0, column=len(new_order))
            
            # 更新所有快捷方式的分区信息（如果有快捷方式在该分区中）
            # 注意：这里我们不会删除快捷方式，只是移除它们的分区关联
            for name, data in self.shortcuts_handler.shortcuts.items():
                if isinstance(data, dict) and data.get('section') == section:
                    # 如果快捷方式在被删除的分区中，清除其分区信息
                    # 这样它仍然可以在'全部'分区中显示
                    data.pop('section', None)
            
            # 保存更新后的数据
            self.shortcuts_handler.save_shortcuts()
            
            # 如果当前正在查看被删除的分区，切换到'全部'分区
            if self.current_section == section:
                self._filter_by_section("all")
            else:
                # 否则刷新当前视图
                self._update_shortcuts_display()
            
            # 更新状态栏
            self.status_var.set(f"成功删除分区: {section}")
            
        except Exception as e:
            logger.error(f"删除分区失败: {e}")
            messagebox.showerror("错误", f"删除分区失败: {str(e)}")
            self.status_var.set(f"删除分区失败: {str(e)}")
    
    def _update_shortcut_dialog(self, name):
        # 获取快捷方式数据
        data = self.shortcuts_handler.shortcuts.get(name)
        if not data:
            messagebox.showerror("错误", "找不到该快捷方式")
            return
        
        # 创建对话框
        dialog = ctk.CTkToplevel(self.root)
        dialog.title("编辑快捷方式")
        dialog.geometry("500x300")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.grid_columnconfigure(0, weight=1)
        
        # 标题标签
        title_label = ctk.CTkLabel(
            dialog,
            text="编辑快捷方式",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        title_label.grid(row=0, column=0, pady=20, padx=20)
        
        # 内容框架
        content_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        content_frame.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")
        content_frame.grid_columnconfigure(1, weight=1)
        
        # 名称输入
        ctk.CTkLabel(content_frame, text="名称: ", font=ctk.CTkFont(size=14)).grid(
            row=0, column=0, padx=10, pady=10, sticky="w")
        
        name_var = ctk.StringVar(value=name)
        name_entry = ctk.CTkEntry(
            content_frame,
            textvariable=name_var,
            width=300,
            corner_radius=6,
            font=ctk.CTkFont(size=14)
        )
        name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        # 路径输入
        ctk.CTkLabel(content_frame, text="路径: ", font=ctk.CTkFont(size=14)).grid(
            row=1, column=0, padx=10, pady=10, sticky="w")
        
        path_var = ctk.StringVar(value=data.get('path', ''))
        path_entry = ctk.CTkEntry(
            content_frame,
            textvariable=path_var,
            width=300,
            corner_radius=6,
            font=ctk.CTkFont(size=14)
        )
        path_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        # 状态标签
        status_var = ctk.StringVar()
        status_label = ctk.CTkLabel(content_frame, textvariable=status_var, text_color="#FF5252")
        status_label.grid(row=2, column=0, columnspan=2, padx=10, pady=5, sticky="w")
        
        def save_changes():
            new_name = name_var.get().strip()
            new_path = path_var.get().strip()
            
            if not new_name:
                status_var.set("请输入名称")
                return
            
            if not new_path:
                status_var.set("请输入路径")
                return
            
            # 验证路径
            shortcut_type = data.get('type', 'file')
            if shortcut_type == 'file' and not os.path.isfile(new_path):
                status_var.set("文件路径不存在")
                return
            elif shortcut_type == 'folder' and not os.path.isdir(new_path):
                status_var.set("文件夹路径不存在")
                return
            elif shortcut_type == 'website' and not self._is_valid_url(new_path):
                # 如果没有协议，自动添加http://
                if not new_path.startswith(("http://", "https://")):
                    new_path = "http://" + new_path
                    if not self._is_valid_url(new_path):
                        status_var.set("请输入有效的网址格式")
                        return
            
            try:
                # 如果名称改变，先删除旧的
                if new_name != name:
                    self.shortcuts_handler.delete_shortcut(name)
                
                # 更新快捷方式
                self.shortcuts_handler.add_shortcut(new_name, new_path, shortcut_type)
                
                # 更新显示
                self._update_shortcuts_display()
                
                # 关闭对话框
                dialog.destroy()
                
                # 更新状态栏
                self.status_var.set(f"快捷方式 '{new_name}' 已更新")
                
            except Exception as e:
                logger.error(f"更新快捷方式失败: {e}")
                status_var.set(f"更新失败: {str(e)}")
        
        # 按钮区域
        buttons_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        buttons_frame.grid(row=2, column=0, pady=20)
        
        save_button = ctk.CTkButton(
            buttons_frame,
            text="保存",
            width=100,
            corner_radius=6,
            command=save_changes
        )
        save_button.grid(row=0, column=0, padx=10, pady=5)
        
        cancel_button = ctk.CTkButton(
            buttons_frame,
            text="取消",
            width=100,
            corner_radius=6,
            command=dialog.destroy
        )
        cancel_button.grid(row=0, column=1, padx=10, pady=5)
    
    def show_add_options_dialog(self):
        """显示添加选项对话框"""
        # 创建对话框
        dialog = ctk.CTkToplevel(self.root)
        dialog.title("添加快捷方式")
        dialog.geometry("400x300")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.grid_columnconfigure(0, weight=1)
        
        # 标题标签
        title_label = ctk.CTkLabel(
            dialog,
            text="选择添加类型",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        title_label.grid(row=0, column=0, pady=20, padx=20)
        
        # 选项按钮框架
        options_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        options_frame.grid(row=1, column=0, pady=20)
        
        # 添加文件按钮
        add_file_button = ctk.CTkButton(
            options_frame,
            text="📄 添加文件",
            width=200,
            height=60,
            corner_radius=8,
            font=ctk.CTkFont(size=14),
            command=lambda: [self._add_file(), dialog.destroy()]
        )
        add_file_button.grid(row=0, column=0, pady=10)
        
        # 添加文件夹按钮
        add_folder_button = ctk.CTkButton(
            options_frame,
            text="📁 添加文件夹",
            width=200,
            height=60,
            corner_radius=8,
            font=ctk.CTkFont(size=14),
            command=lambda: [self._add_folder(), dialog.destroy()]
        )
        add_folder_button.grid(row=1, column=0, pady=10)
        
        # 添加网址按钮
        add_website_button = ctk.CTkButton(
            options_frame,
            text="🌐 添加网址",
            width=200,
            height=60,
            corner_radius=8,
            font=ctk.CTkFont(size=14),
            command=lambda: [self._add_website(), dialog.destroy()]
        )
        add_website_button.grid(row=2, column=0, pady=10)
    
    def _add_file(self):
        """添加文件快捷方式"""
        # 获取桌面路径作为默认目录
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        
        # 打开文件选择对话框，默认打开桌面目录，只允许选择文件
        file_path = filedialog.askopenfilename(
            title="选择文件",
            initialdir=desktop_path
        )
        
        if file_path:
            # 获取文件名作为默认名称
            default_name = os.path.basename(file_path)
            
            # 创建对话框
            dialog = ctk.CTkToplevel(self.root)
            dialog.title("添加文件快捷方式")
            dialog.geometry("500x300")
            dialog.transient(self.root)
            dialog.grab_set()
            dialog.grid_columnconfigure(0, weight=1)
            
            # 内容框架
            content_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            content_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
            content_frame.grid_columnconfigure(1, weight=1)
            
            # 名称输入
            ctk.CTkLabel(content_frame, text="名称: ", font=ctk.CTkFont(size=14)).grid(
                row=0, column=0, padx=10, pady=10, sticky="w")
            
            name_var = ctk.StringVar(value=default_name)

            name_entry = ctk.CTkEntry(
                content_frame,
                textvariable=name_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
            
            # 路径显示
            ctk.CTkLabel(content_frame, text="路径: ", font=ctk.CTkFont(size=14)).grid(
                row=1, column=0, padx=10, pady=10, sticky="w")
            
            path_var = ctk.StringVar(value=file_path)
            path_entry = ctk.CTkEntry(
                content_frame,
                textvariable=path_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            path_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            
            # 分区选择
            ctk.CTkLabel(content_frame, text="分区: ", font=ctk.CTkFont(size=14)).grid(
                row=2, column=0, padx=10, pady=10, sticky="w")
            
            # 分区选项框架
            section_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            section_frame.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
            section_frame.grid_columnconfigure(0, weight=1)
            
            # 预定义分区列表，添加系统分区
            default_sections = ["工作", "娱乐", "文档", "网站", "文件夹", "全部"]
            # 获取已保存的自定义分区
            custom_sections = []
            if hasattr(self.shortcuts_handler, 'shortcuts'):
                # 收集所有自定义分区
                all_sections = set(default_sections)
                for shortcut_data in self.shortcuts_handler.shortcuts.values():
                    if isinstance(shortcut_data, dict) and 'section' in shortcut_data:
                        all_sections.add(shortcut_data['section'])
                custom_sections = list(all_sections)
                custom_sections.sort()
            else:
                custom_sections = default_sections
            
            section_var = ctk.StringVar(value="全部")
            section_combo = ctk.CTkComboBox(
                section_frame,
                values=custom_sections,
                variable=section_var,
                width=200,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            section_combo.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
            
            # 新建分区按钮
            def create_new_section():
                new_section_dialog = ctk.CTkToplevel(dialog)
                new_section_dialog.title("新建分区")
                new_section_dialog.geometry("300x150")
                new_section_dialog.transient(dialog)
                new_section_dialog.grab_set()
                
                ctk.CTkLabel(new_section_dialog, text="分区名称: ", font=ctk.CTkFont(size=14)).pack(
                    padx=20, pady=(20, 10), anchor="w")
                
                new_section_var = ctk.StringVar()
                new_section_entry = ctk.CTkEntry(
                    new_section_dialog,
                    textvariable=new_section_var,
                    width=200,
                    corner_radius=6,
                    font=ctk.CTkFont(size=14)
                )
                new_section_entry.pack(padx=20, pady=10)
                new_section_entry.focus()
                
                def save_new_section():
                    section_name = new_section_var.get().strip()
                    if not section_name:
                        messagebox.showerror("错误", "分区名称不能为空")
                        return
                    
                    if section_name in custom_sections or section_name == "系统":
                        if section_name == "系统":
                            messagebox.showerror("错误", "'系统'是保留分区名称，不能创建")
                        else:
                            messagebox.showerror("错误", "该分区名称已存在")
                        return
                    
                    # 更新下拉框选项
                    custom_sections.append(section_name)
                    section_combo.configure(values=custom_sections)
                    section_var.set(section_name)
                    
                    new_section_dialog.destroy()
                
                buttons_frame = ctk.CTkFrame(new_section_dialog, fg_color="transparent")
                buttons_frame.pack(pady=10)
                
                ctk.CTkButton(
                    buttons_frame,
                    text="确定",
                    width=80,
                    corner_radius=6,
                    command=save_new_section
                ).grid(row=0, column=0, padx=10, pady=5)
                
                ctk.CTkButton(
                    buttons_frame,
                    text="取消",
                    width=80,
                    corner_radius=6,
                    command=new_section_dialog.destroy
                ).grid(row=0, column=1, padx=10, pady=5)
            
            new_section_button = ctk.CTkButton(
                section_frame,
                text="新建分区",
                width=80,
                corner_radius=6,
                font=ctk.CTkFont(size=12),
                command=create_new_section
            )
            new_section_button.grid(row=0, column=1, padx=5, pady=5)
            
            # 状态标签
            status_var = ctk.StringVar()
            status_label = ctk.CTkLabel(content_frame, textvariable=status_var, text_color="#FF5252")
            status_label.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="w")
            
            def validate_and_add():
                name = name_var.get().strip()
                path = path_var.get().strip()
                selected_section = section_var.get()
                
                if not name:
                    status_var.set("请输入名称")
                    return
                
                if not path or not os.path.isfile(path):
                    status_var.set("文件路径不存在")
                    return
                
                try:
                    # 创建快捷方式数据，包含分区信息
                    shortcut_data = {
                        "path": path,
                        "type": "file",
                        "section": selected_section
                    }
                    
                    # 直接添加到shortcuts字典
                    if hasattr(self.shortcuts_handler, 'shortcuts'):
                        self.shortcuts_handler.shortcuts[name] = shortcut_data
                        self.shortcuts_handler.save_shortcuts()
                    else:
                        # 降级方案，传递section参数
                        self.shortcuts_handler.add_shortcut(name, path, 'file', section=selected_section)
                    
                    # 更新显示
                    self._update_shortcuts_display()
                    
                    # 关闭对话框
                    dialog.destroy()
                    
                    # 更新状态栏
                    self.status_var.set(f"文件快捷方式 '{name}' 已添加到 {selected_section} 分区")
                    
                except Exception as e:
                    logger.error(f"添加文件快捷方式失败: {e}")
                    status_var.set(f"添加失败: {str(e)}")
            
            # 按钮区域
            buttons_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            buttons_frame.grid(row=1, column=0, padx=20, pady=10)
            
            add_button = ctk.CTkButton(
                buttons_frame,
                text="添加",
                width=100,
                corner_radius=6,
                command=validate_and_add
            )
            add_button.grid(row=0, column=0, padx=10, pady=5)
            
            cancel_button = ctk.CTkButton(
                buttons_frame,
                text="取消",
                width=100,
                corner_radius=6,
                command=dialog.destroy
            )
            cancel_button.grid(row=0, column=1, padx=10, pady=5)
    
    def _add_folder(self):
        """添加文件夹快捷方式"""
        # 获取桌面路径作为默认目录
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        
        # 打开文件夹选择对话框，默认打开桌面目录，只允许选择文件夹
        folder_path = filedialog.askdirectory(
            title="选择文件夹",
            initialdir=desktop_path
        )
        
        if folder_path:
            # 获取文件夹名作为默认名称
            default_name = os.path.basename(folder_path)
            
            # 创建对话框
            dialog = ctk.CTkToplevel(self.root)
            dialog.title("添加文件夹快捷方式")
            dialog.geometry("500x300")  # 调整高度以容纳分区选择
            dialog.transient(self.root)
            dialog.grab_set()
            dialog.grid_columnconfigure(0, weight=1)
            
            # 内容框架
            content_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            content_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
            content_frame.grid_columnconfigure(1, weight=1)
            
            # 名称输入
            ctk.CTkLabel(content_frame, text="名称: ", font=ctk.CTkFont(size=14)).grid(
                row=0, column=0, padx=10, pady=10, sticky="w")
            
            name_var = ctk.StringVar(value=default_name)
            name_entry = ctk.CTkEntry(
                content_frame,
                textvariable=name_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
            
            # 路径显示
            ctk.CTkLabel(content_frame, text="路径: ", font=ctk.CTkFont(size=14)).grid(
                row=1, column=0, padx=10, pady=10, sticky="w")
            
            path_var = ctk.StringVar(value=folder_path)
            path_entry = ctk.CTkEntry(
                content_frame,
                textvariable=path_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            path_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            
            # 分区选择
            ctk.CTkLabel(content_frame, text="分区: ", font=ctk.CTkFont(size=14)).grid(
                row=2, column=0, padx=10, pady=10, sticky="w")
            
            # 分区选项框架
            section_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            section_frame.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
            section_frame.grid_columnconfigure(0, weight=1)
            
            # 预定义分区列表，添加系统分区
            default_sections = ["工作", "娱乐", "文档", "网站", "文件夹", "全部"]
            # 获取已保存的自定义分区
            custom_sections = []
            if hasattr(self.shortcuts_handler, 'shortcuts'):
                # 收集所有自定义分区
                all_sections = set(default_sections)
                for shortcut_data in self.shortcuts_handler.shortcuts.values():
                    if isinstance(shortcut_data, dict) and 'section' in shortcut_data:
                        all_sections.add(shortcut_data['section'])
                custom_sections = list(all_sections)
                custom_sections.sort()
            else:
                custom_sections = default_sections
            
            section_var = ctk.StringVar(value="文件夹")
            section_combo = ctk.CTkComboBox(
                section_frame,
                values=custom_sections,
                variable=section_var,
                width=200,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            section_combo.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
            
            # 新建分区按钮
            def create_new_section():
                new_section_dialog = ctk.CTkToplevel(dialog)
                new_section_dialog.title("新建分区")
                new_section_dialog.geometry("300x150")
                new_section_dialog.transient(dialog)
                new_section_dialog.grab_set()
                
                ctk.CTkLabel(new_section_dialog, text="分区名称: ", font=ctk.CTkFont(size=14)).pack(
                    padx=20, pady=(20, 10), anchor="w")
                
                new_section_var = ctk.StringVar()
                new_section_entry = ctk.CTkEntry(
                    new_section_dialog,
                    textvariable=new_section_var,
                    width=200,
                    corner_radius=6,
                    font=ctk.CTkFont(size=14)
                )
                new_section_entry.pack(padx=20, pady=10)
                new_section_entry.focus()
                
                def save_new_section():
                    section_name = new_section_var.get().strip()
                    if not section_name:
                        messagebox.showerror("错误", "分区名称不能为空")
                        return
                    
                    if section_name in custom_sections:
                        messagebox.showerror("错误", "该分区名称已存在")
                        return
                    
                    # 更新下拉框选项
                    custom_sections.append(section_name)
                    section_combo.configure(values=custom_sections)
                    section_var.set(section_name)
                    
                    new_section_dialog.destroy()
                
                buttons_frame = ctk.CTkFrame(new_section_dialog, fg_color="transparent")
                buttons_frame.pack(pady=10)
                
                ctk.CTkButton(
                    buttons_frame,
                    text="确定",
                    width=80,
                    corner_radius=6,
                    command=save_new_section
                ).grid(row=0, column=0, padx=10, pady=5)
                
                ctk.CTkButton(
                    buttons_frame,
                    text="取消",
                    width=80,
                    corner_radius=6,
                    command=new_section_dialog.destroy
                ).grid(row=0, column=1, padx=10, pady=5)
            
            new_section_button = ctk.CTkButton(
                section_frame,
                text="新建分区",
                width=80,
                corner_radius=6,
                font=ctk.CTkFont(size=12),
                command=create_new_section
            )
            new_section_button.grid(row=0, column=1, padx=5, pady=5)
            
            # 状态标签
            status_var = ctk.StringVar()
            status_label = ctk.CTkLabel(content_frame, textvariable=status_var, text_color="#FF5252")
            status_label.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="w")
            
            def validate_and_add():
                name = name_var.get().strip()
                path = path_var.get().strip()
                selected_section = section_var.get()
                
                if not name:
                    status_var.set("请输入名称")
                    return
                
                if not path or not os.path.isdir(path):
                    status_var.set("文件夹路径不存在")
                    return
                
                try:
                    # 创建快捷方式数据，包含分区信息
                    shortcut_data = {
                        "path": path,
                        "type": "folder",
                        "section": selected_section
                    }
                    
                    # 直接添加到shortcuts字典
                    if hasattr(self.shortcuts_handler, 'shortcuts'):
                        self.shortcuts_handler.shortcuts[name] = shortcut_data
                        self.shortcuts_handler.save_shortcuts()
                    else:
                        # 降级方案，传递section参数
                        self.shortcuts_handler.add_shortcut(name, path, 'folder', section=selected_section)
                    
                    # 更新显示
                    self._update_shortcuts_display()
                    
                    # 关闭对话框
                    dialog.destroy()
                    
                    # 更新状态栏
                    self.status_var.set(f"文件夹快捷方式 '{name}' 已添加到 {selected_section} 分区")
                    
                except Exception as e:
                    logger.error(f"添加文件夹快捷方式失败: {e}")
                    status_var.set(f"添加失败: {str(e)}")
            
            # 按钮区域
            buttons_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            buttons_frame.grid(row=1, column=0, pady=10)
            
            add_button = ctk.CTkButton(
                buttons_frame,
                text="添加",
                width=100,
                corner_radius=6,
                command=validate_and_add
            )
            add_button.grid(row=0, column=0, padx=10, pady=5)
            
            cancel_button = ctk.CTkButton(
                buttons_frame,
                text="取消",
                width=100,
                corner_radius=6,
                command=dialog.destroy
            )
            cancel_button.grid(row=0, column=1, padx=10, pady=5)
    
    def _add_shortcut_file(self):
        """添加快捷方式文件（.lnk文件）"""
        # 获取桌面路径作为默认目录
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        
        # 打开文件选择对话框，只允许选择.lnk文件
        file_path = filedialog.askopenfilename(
            title="选择快捷方式文件",
            initialdir=desktop_path,
            filetypes=[("快捷方式文件", "*.lnk")]
        )
        
        if file_path:
            # 获取文件名作为默认名称
            default_name = os.path.basename(file_path).replace('.lnk', '')
            
            # 创建对话框
            dialog = ctk.CTkToplevel(self.root)
            dialog.title("小易管理器")
            dialog.geometry("500x300")  # 调整高度以容纳分区选择
            dialog.transient(self.root)
            dialog.grab_set()
            dialog.grid_columnconfigure(0, weight=1)
            
            # 内容框架
            content_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            content_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
            content_frame.grid_columnconfigure(1, weight=1)
            
            # 名称输入
            ctk.CTkLabel(content_frame, text="名称: ", font=ctk.CTkFont(size=14)).grid(
                row=0, column=0, padx=10, pady=10, sticky="w")
            
            name_var = ctk.StringVar(value=default_name)
            name_entry = ctk.CTkEntry(
                content_frame,
                textvariable=name_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
            
            # 路径显示
            ctk.CTkLabel(content_frame, text="路径: ", font=ctk.CTkFont(size=14)).grid(
                row=1, column=0, padx=10, pady=10, sticky="w")
            
            path_var = ctk.StringVar(value=file_path)
            path_entry = ctk.CTkEntry(
                content_frame,
                textvariable=path_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            path_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            
            # 分区选择
            ctk.CTkLabel(content_frame, text="分区: ", font=ctk.CTkFont(size=14)).grid(
                row=2, column=0, padx=10, pady=10, sticky="w")
            
            # 分区选项框架
            section_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            section_frame.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
            section_frame.grid_columnconfigure(0, weight=1)
            
            # 预定义分区列表，添加系统分区
            default_sections = ["工作", "娱乐", "文档", "网站", "文件夹", "全部"]
            # 获取已保存的自定义分区
            custom_sections = []
            if hasattr(self.shortcuts_handler, 'shortcuts'):
                # 收集所有自定义分区
                all_sections = set(default_sections)
                for shortcut_data in self.shortcuts_handler.shortcuts.values():
                    if isinstance(shortcut_data, dict) and 'section' in shortcut_data:
                        all_sections.add(shortcut_data['section'])
                custom_sections = list(all_sections)
                custom_sections.sort()
            else:
                custom_sections = default_sections
            
            section_var = ctk.StringVar(value="全部")
            section_combo = ctk.CTkComboBox(
                section_frame,
                values=custom_sections,
                variable=section_var,
                width=200,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            section_combo.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
            
            # 新建分区按钮
            def create_new_section():
                new_section_dialog = ctk.CTkToplevel(dialog)
                new_section_dialog.title("新建分区")
                new_section_dialog.geometry("300x150")
                new_section_dialog.transient(dialog)
                new_section_dialog.grab_set()
                
                ctk.CTkLabel(new_section_dialog, text="分区名称: ", font=ctk.CTkFont(size=14)).pack(
                    padx=20, pady=(20, 10), anchor="w")
                
                new_section_var = ctk.StringVar()
                new_section_entry = ctk.CTkEntry(
                    new_section_dialog,
                    textvariable=new_section_var,
                    width=200,
                    corner_radius=6,
                    font=ctk.CTkFont(size=14)
                )
                new_section_entry.pack(padx=20, pady=10)
                new_section_entry.focus()
                
                def save_new_section():
                    section_name = new_section_var.get().strip()
                    if not section_name:
                        messagebox.showerror("错误", "分区名称不能为空")
                        return
                    
                    if section_name in custom_sections or section_name == "系统":
                        if section_name == "系统":
                            messagebox.showerror("错误", "'系统'是保留分区名称，不能创建")
                        else:
                            messagebox.showerror("错误", "该分区名称已存在")
                        return
                    
                    # 更新下拉框选项
                    custom_sections.append(section_name)
                    section_combo.configure(values=custom_sections)
                    section_var.set(section_name)
                    
                    new_section_dialog.destroy()
                
                buttons_frame = ctk.CTkFrame(new_section_dialog, fg_color="transparent")
                buttons_frame.pack(pady=10)
                
                ctk.CTkButton(
                    buttons_frame,
                    text="确定",
                    width=80,
                    corner_radius=6,
                    command=save_new_section
                ).grid(row=0, column=0, padx=10, pady=5)
                
                ctk.CTkButton(
                    buttons_frame,
                    text="取消",
                    width=80,
                    corner_radius=6,
                    command=new_section_dialog.destroy
                ).grid(row=0, column=1, padx=10, pady=5)
            
            new_section_button = ctk.CTkButton(
                section_frame,
                text="新建分区",
                width=80,
                corner_radius=6,
                font=ctk.CTkFont(size=12),
                command=create_new_section
            )
            new_section_button.grid(row=0, column=1, padx=5, pady=5)
            
            # 状态标签
            status_var = ctk.StringVar()
            status_label = ctk.CTkLabel(content_frame, textvariable=status_var, text_color="#FF5252")
            status_label.grid(row=3, column=0, columnspan=2, padx=10, pady=5, sticky="w")
            
            def validate_and_add():
                name = name_var.get().strip()
                path = path_var.get().strip()
                selected_section = section_var.get()
                
                if not name:
                    status_var.set("请输入名称")
                    return
                
                if not path or not os.path.isfile(path):
                    status_var.set("文件路径不存在")
                    return
                
                try:
                    # 创建快捷方式数据，包含分区信息
                    shortcut_data = {
                        "path": path,
                        "type": "file",
                        "section": selected_section
                    }
                    
                    # 直接添加到shortcuts字典
                    if hasattr(self.shortcuts_handler, 'shortcuts'):
                        self.shortcuts_handler.shortcuts[name] = shortcut_data
                        self.shortcuts_handler.save_shortcuts()
                    else:
                        # 降级方案，传递section参数
                        self.shortcuts_handler.add_shortcut(name, path, 'file', section=selected_section)
                    
                    # 更新显示
                    self._update_shortcuts_display()
                    
                    # 关闭对话框
                    dialog.destroy()
                    
                    # 更新状态栏
                    self.status_var.set(f"快捷方式 '{name}' 已添加到 {selected_section} 分区")
                    
                except Exception as e:
                    logger.error(f"添加快捷方式失败: {e}")
                    status_var.set(f"添加失败: {str(e)}")
            
            # 按钮区域
            buttons_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            buttons_frame.grid(row=1, column=0, pady=10)
            
            add_button = ctk.CTkButton(
                buttons_frame,
                text="添加",
                width=100,
                corner_radius=6,
                command=validate_and_add
            )
            add_button.grid(row=0, column=0, padx=10, pady=5)
            
            cancel_button = ctk.CTkButton(
                buttons_frame,
                text="取消",
                width=100,
                corner_radius=6,
                command=dialog.destroy
            )
            cancel_button.grid(row=0, column=1, padx=10, pady=5)
            
    def _add_website(self):
        """添加网址快捷方式"""
        # 创建添加网址对话框
        dialog = ctk.CTkToplevel(self.root)
        dialog.title("添加网址")
        dialog.geometry("550x300")
        dialog.minsize(500, 280)
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.grid_columnconfigure(0, weight=1)
        
        # 标题标签
        title_label = ctk.CTkLabel(
            dialog, 
            text="添加网址快捷方式", 
            font=ctk.CTkFont(size=18, weight="bold")
        )
        title_label.grid(row=0, column=0, pady=20, padx=20, sticky="n")
        
        # 内容框架
        content_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        content_frame.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")
        content_frame.grid_columnconfigure(1, weight=1)
        
        # 名称输入
        ctk.CTkLabel(content_frame, text="名称: ", font=ctk.CTkFont(size=14)).grid(
            row=0, column=0, padx=10, pady=10, sticky="w")
        
        name_var = ctk.StringVar()
        name_entry = ctk.CTkEntry(
            content_frame, 
            textvariable=name_var, 
            width=400,
            corner_radius=6,
            font=ctk.CTkFont(size=14)
        )
        name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        name_entry.focus_set()  # 设置焦点
        
        # 网址输入
        ctk.CTkLabel(content_frame, text="网址: ", font=ctk.CTkFont(size=14)).grid(
            row=1, column=0, padx=10, pady=10, sticky="w")
        
        url_var = ctk.StringVar()
        url_entry = ctk.CTkEntry(
            content_frame, 
            textvariable=url_var, 
            width=400,
            corner_radius=6,
            font=ctk.CTkFont(size=14)
        )
        url_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        
        # 状态标签
        status_var = ctk.StringVar()
        status_label = ctk.CTkLabel(content_frame, textvariable=status_var, text_color="#FF5252")
        status_label.grid(row=2, column=0, columnspan=2, padx=10, pady=5, sticky="w")
        
        def validate_and_add():
            name = name_var.get().strip()
            url = url_var.get().strip()
            selected_section = section_var.get()
            
            if not name:
                status_var.set("请输入名称")
                return
            
            if not url:
                status_var.set("请输入网址")
                return
            
            # 验证URL格式
            if not self._is_valid_url(url):
                # 如果没有协议，自动添加http://
                if not url.startswith(("http://", "https://")):
                    url = "http://" + url
                    if not self._is_valid_url(url):
                        status_var.set("请输入有效的网址格式")
                        return
            
            try:
                # 添加网址快捷方式，传递section参数
                self.shortcuts_handler.add_shortcut(name, url, 'website', section=selected_section)
                
                # 更新显示
                self._update_shortcuts_display()
                
                # 关闭对话框
                dialog.destroy()
                
                # 更新状态栏
                self.status_var.set(f"网址快捷方式 '{name}' 已添加到 {selected_section} 分区")
                
            except Exception as e:
                logger.error(f"添加网址快捷方式失败: {e}")
                status_var.set(f"添加失败: {str(e)}")
        
        # 按钮区域
        buttons_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        buttons_frame.grid(row=2, column=0, pady=20)
        
        add_button = ctk.CTkButton(
            buttons_frame,
            text="添加",
            width=100,
            corner_radius=6,
            command=validate_and_add
        )
        add_button.grid(row=0, column=0, padx=10, pady=5)
        
        cancel_button = ctk.CTkButton(
            buttons_frame,
            text="取消",
            width=100,
            corner_radius=6,
            command=dialog.destroy
        )
        cancel_button.grid(row=0, column=1, padx=10, pady=5)
    
    def _is_valid_url(self, url):
        """验证URL格式是否有效"""
        try:
            # 简单的URL验证正则表达式
            url_pattern = re.compile(
                r'^(https?://)?'  # 可选的http或https协议
                r'((([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})|'  # 域名
                r'localhost|'  # localhost
                r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # IP地址
                r'(\:\d+)?'  # 可选的端口号
                r'(\/[-a-zA-Z0-9%_.~+]*)*'  # 可选的路径
                r'(\?[;&a-zA-Z0-9%_.~+=-]*)?'  # 可选的查询参数
                r'(\#[-a-zA-Z0-9_]*)?$',  # 可选的锚点
                re.IGNORECASE
            )
            return bool(url_pattern.match(url))
        except Exception as e:
            logger.error(f"URL验证失败: {e}")
            return False
    
    def _on_drop(self, event):
        """处理拖放事件，支持从桌面拖动快捷方式添加，同时支持Windows HDROP句柄"""
        try:
            logger.info("_on_drop方法被调用")
            file_paths = []
            
            # 检查是否是Windows HDROP句柄
            if hasattr(event, 'data') and isinstance(event.data, int) and sys.platform == 'win32':
                logger.info("处理Windows HDROP句柄")
                hdrop = event.data
                
                # 获取拖放的文件数量
                file_count = ctypes.windll.shell32.DragQueryFileW(hdrop, -1, None, 0)
                logger.info(f"拖放的文件数量: {file_count}")
                
                # 获取每个文件的路径
                for i in range(file_count):
                    # 首先获取路径长度
                    path_length = ctypes.windll.shell32.DragQueryFileW(hdrop, i, None, 0)
                    # 创建缓冲区并获取路径
                    path_buffer = ctypes.create_unicode_buffer(path_length + 1)
                    ctypes.windll.shell32.DragQueryFileW(hdrop, i, path_buffer, path_length + 1)
                    file_path = path_buffer.value
                    file_paths.append(file_path)
                    logger.info(f"从HDROP获取的文件路径: {file_path}")
                
                # 释放HDROP资源
                ctypes.windll.shell32.DragFinish(hdrop)
            
            # 处理传统的字符串格式拖放数据
            elif hasattr(event, 'data') and isinstance(event.data, str):
                logger.info(f"处理字符串格式拖放数据: {event.data}")
                # 获取拖放的文件路径列表
                file_paths = event.data.strip().split()
                logger.info(f"解析出的文件路径列表: {file_paths}")
            
            # 处理每个拖放的文件
            added_count = 0
            for file_path in file_paths:
                # 清理路径（移除引号等）
                file_path = file_path.strip('"')
                logger.info(f"处理文件: {file_path}")
                
                # 检查文件是否存在
                if not os.path.exists(file_path):
                    logger.warning(f"文件不存在: {file_path}")
                    continue
                
                # 确定文件类型
                if file_path.endswith('.lnk'):
                    # 快捷方式文件
                    logger.info(f"处理快捷方式文件: {file_path}")
                    self._add_dropped_shortcut(file_path)
                    added_count += 1
                elif os.path.isdir(file_path):
                    # 文件夹
                    logger.info(f"处理文件夹: {file_path}")
                    self._add_dropped_folder(file_path)
                    added_count += 1
                else:
                    # 普通文件
                    logger.info(f"处理普通文件: {file_path}")
                    self._add_dropped_file(file_path)
                    added_count += 1
            
            # 如果成功添加了快捷方式，更新显示
            if added_count > 0:
                logger.info(f"成功处理 {added_count} 个文件")
                self._update_shortcuts_display()
                self.status_var.set(f"成功添加 {added_count} 个快捷方式")
        except Exception as e:
            logger.error(f"处理拖放失败: {e}")
            self.status_var.set(f"添加失败: {str(e)}")
    
    def _add_dropped_shortcut(self, file_path):
        """添加拖放的快捷方式文件，显示对话框让用户确认"""
        # 获取文件名作为默认名称
        default_name = os.path.basename(file_path).replace('.lnk', '')
        self._show_add_dialog(default_name, file_path, 'file')
    
    def _add_dropped_folder(self, folder_path):
        """添加拖放的文件夹，显示对话框让用户确认"""
        # 获取文件夹名作为默认名称
        default_name = os.path.basename(folder_path)
        self._show_add_dialog(default_name, folder_path, 'folder')
    
    def _add_dropped_file(self, file_path):
        """添加拖放的普通文件，显示对话框让用户确认"""
        # 获取文件名作为默认名称
        default_name = os.path.basename(file_path)
        self._show_add_dialog(default_name, file_path, 'file')
        
    def _show_add_dialog(self, default_name, path, shortcut_type):
        """显示添加快捷方式的对话框"""
        try:
            logger.info(f"_show_add_dialog被调用: 名称={default_name}, 路径={path}, 类型={shortcut_type}")
            # 创建对话框
            dialog = ctk.CTkToplevel(self.root)
            dialog.title("小易管理器")
            dialog.geometry("500x300")
            dialog.transient(self.root)
            dialog.grab_set()
            dialog.lift()  # 确保对话框显示在最前面
            dialog.focus_force()  # 强制获取焦点
            dialog.grid_columnconfigure(0, weight=1)
            
            # 内容框架
            content_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            content_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
            content_frame.grid_columnconfigure(1, weight=1)
            
            # 名称输入
            ctk.CTkLabel(content_frame, text="名称: ", font=ctk.CTkFont(size=14)).grid(
                row=0, column=0, padx=10, pady=10, sticky="w")
            
            name_var = ctk.StringVar(value=default_name)
            name_entry = ctk.CTkEntry(
                content_frame,
                textvariable=name_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            name_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
            
            # 路径显示
            ctk.CTkLabel(content_frame, text="路径: ", font=ctk.CTkFont(size=14)).grid(
                row=1, column=0, padx=10, pady=10, sticky="w")
            
            path_var = ctk.StringVar(value=path)
            path_entry = ctk.CTkEntry(
                content_frame,
                textvariable=path_var,
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            path_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            path_entry.configure(state="disabled")  # 路径不可编辑
            
            # 分区选择
            ctk.CTkLabel(content_frame, text="分区: ", font=ctk.CTkFont(size=14)).grid(
                row=2, column=0, padx=10, pady=10, sticky="w")
            
            # 分区选项框架
            section_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            section_frame.grid(row=2, column=1, padx=10, pady=10, sticky="ew")
            section_frame.grid_columnconfigure(0, weight=1)
            
            # 预定义分区列表
            default_sections = ["工作", "娱乐", "文档", "网站", "文件夹", "全部"]
            # 获取已保存的自定义分区
            custom_sections = []
            if hasattr(self.shortcuts_handler, 'shortcuts'):
                # 收集所有自定义分区
                all_sections = set(default_sections)
                for shortcut_data in self.shortcuts_handler.shortcuts.values():
                    if isinstance(shortcut_data, dict) and 'section' in shortcut_data:
                        all_sections.add(shortcut_data['section'])
                custom_sections = list(all_sections)
                custom_sections.sort()
            else:
                custom_sections = default_sections
            
            section_var = ctk.StringVar(value="全部")
            section_combo = ctk.CTkComboBox(
                section_frame,
                values=custom_sections,
                variable=section_var,
                width=200,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            section_combo.grid(row=0, column=0, padx=5, pady=5, sticky="ew")
            
            # 按钮框架
            button_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            button_frame.grid(row=3, column=0, columnspan=2, padx=10, pady=20, sticky="e")
            
            # 确认按钮
            def on_confirm():
                name = name_var.get().strip()
                if not name:
                    self.status_var.set("名称不能为空")
                    return
                
                try:
                    selected_section = section_var.get()
                    if hasattr(self.shortcuts_handler, 'add_shortcut'):
                        # 添加到快捷方式管理器
                        if shortcut_type == 'file':
                            self.shortcuts_handler.add_shortcut(name, path, 'file', section=selected_section)
                        elif shortcut_type == 'folder':
                            self.shortcuts_handler.add_shortcut(name, path, 'folder', section=selected_section)
                        
                        self.status_var.set(f"成功添加快捷方式: {name}")
                        dialog.destroy()
                        # 更新显示
                        self._update_shortcuts_display()
                except Exception as e:
                    logger.error(f"添加快捷方式失败: {e}")
                    self.status_var.set(f"添加失败: {str(e)}")
            
            confirm_button = ctk.CTkButton(
                button_frame,
                text="确定",
                width=100,
                corner_radius=6,
                font=ctk.CTkFont(size=14),
                command=on_confirm
            )
            confirm_button.pack(side="right", padx=10)
            
            # 取消按钮
            cancel_button = ctk.CTkButton(
                button_frame,
                text="取消",
                width=100,
                corner_radius=6,
                font=ctk.CTkFont(size=14),
                command=dialog.destroy
            )
            cancel_button.pack(side="right")
        except Exception as e:
            logger.error(f"显示添加对话框失败: {e}")
            self.status_var.set(f"显示对话框失败: {str(e)}")
    
    def _get_file_icon(self, path, is_folder=False):
        """获取文件或文件夹的原始系统图标 - 直接使用Windows API获取文件或应用程序本身的原始图标"""
        # 强制清除所有缓存，确保每次都使用新的图标获取逻辑
        if hasattr(ModernUI, '_icon_cache'):
            ModernUI._icon_cache.clear()
            logger.debug("已清除所有图标缓存，强制重新获取图标")
        
        logger.debug(f"===== 开始图标加载调试 =====")
        logger.debug(f"尝试获取图标，路径: {path}, 是否文件夹: {is_folder}")
        
        # 确保导入必要的模块
        try:
            from PIL import Image, ImageTk
            pil_available = True
            logger.debug("PIL库可用")
        except ImportError:
            pil_available = False
            logger.warning("PIL库不可用")
        
        try:
            # 验证路径是否存在
            if path is None or not isinstance(path, str):
                logger.error(f"无效的路径参数: {path}")
                return self._get_default_emoji_icon()
            
            logger.debug(f"当前工作目录: {os.getcwd()}")
            normalized_path = os.path.normpath(path)
            logger.debug(f"标准化后的路径: {normalized_path}")
            
            # 对于快捷方式文件，我们需要解析它以获取目标路径
            original_path = normalized_path  # 保存原始路径用于日志
            if normalized_path.lower().endswith('.lnk'):
                try:
                    import pythoncom
                    from win32com.client import Dispatch
                    
                    logger.debug(f"解析快捷方式: {normalized_path}")
                    shell = Dispatch('WScript.Shell')
                    shortcut = shell.CreateShortcut(normalized_path)
                    target_path = shortcut.TargetPath
                    logger.debug(f"快捷方式目标路径: {target_path}")
                    
                    # 使用快捷方式的目标路径获取图标
                    normalized_path = target_path
                    # 重新检查目标是否为文件夹
                    is_folder = os.path.isdir(normalized_path)
                except Exception as e:
                    logger.warning(f"解析快捷方式失败: {e}")
            
            # 确保路径存在
            if not os.path.exists(normalized_path) and not is_folder:
                logger.warning(f"文件不存在: {normalized_path}")
            
            # 尝试使用Windows API获取原始系统图标
            try:
                import win32gui
                import win32con
                import win32api
                from ctypes import byref, wintypes
                
                logger.debug("使用Windows API获取原始系统图标")
                
                # 定义常量 - 确保使用正确的标志来获取准确的图标
                SHGFI_ICON = 0x000000100  # 请求图标
                SHGFI_LARGEICON = 0x000000000  # 大图标
                SHGFI_SMALLICON = 0x000000001  # 小图标
                SHGFI_USEFILEATTRIBUTES = 0x000000010  # 使用文件属性而非实际文件
                SHGFI_OPENICON = 0x000000002  # 获取打开状态的图标
                FILE_ATTRIBUTE_DIRECTORY = 0x00000010  # 文件夹属性
                
                # 定义SHFILEINFO结构
                class SHFILEINFO(ctypes.Structure):
                    _fields_ = [
                        ("hIcon", wintypes.HANDLE),
                        ("iIcon", ctypes.c_int),
                        ("dwAttributes", wintypes.DWORD),
                        ("szDisplayName", ctypes.c_char * 260),
                        ("szTypeName", ctypes.c_char * 80)
                    ]
                
                shinfo = SHFILEINFO()
                
                # 首先尝试直接获取文件或文件夹的实际图标
                if os.path.exists(normalized_path):
                    logger.debug(f"路径存在，直接获取实际图标: {normalized_path}")
                    flags = SHGFI_ICON | SHGFI_LARGEICON
                    
                    if is_folder:
                        # 获取实际文件夹的图标
                        logger.debug("获取实际文件夹图标")
                        ctypes.windll.shell32.SHGetFileInfoW(
                            normalized_path,
                            FILE_ATTRIBUTE_DIRECTORY,
                            byref(shinfo),
                            ctypes.sizeof(shinfo),
                            flags
                        )
                    else:
                        # 获取实际文件的图标
                        logger.debug("获取实际文件图标")
                        ctypes.windll.shell32.SHGetFileInfoW(
                            normalized_path,
                            0,
                            byref(shinfo),
                            ctypes.sizeof(shinfo),
                            flags
                        )
                else:
                    # 如果路径不存在但我们知道它是文件夹，使用属性获取文件夹图标
                    if is_folder:
                        logger.debug(f"路径不存在，但标记为文件夹，使用属性获取图标: {normalized_path}")
                        flags = SHGFI_ICON | SHGFI_LARGEICON | SHGFI_USEFILEATTRIBUTES
                        ctypes.windll.shell32.SHGetFileInfoW(
                            normalized_path,
                            FILE_ATTRIBUTE_DIRECTORY,
                            byref(shinfo),
                            ctypes.sizeof(shinfo),
                            flags
                        )
                    else:
                        # 对于不存在的文件，尝试基于扩展名获取图标
                        logger.debug(f"路径不存在，基于扩展名获取图标: {normalized_path}")
                        flags = SHGFI_ICON | SHGFI_LARGEICON | SHGFI_USEFILEATTRIBUTES
                        ctypes.windll.shell32.SHGetFileInfoW(
                            normalized_path,
                            0,
                            byref(shinfo),
                            ctypes.sizeof(shinfo),
                            flags
                        )
                
                # 如果成功获取图标句柄
                if shinfo.hIcon != 0:
                    logger.debug(f"成功获取图标句柄: {shinfo.hIcon}")
                    
                    # 将Windows图标转换为PIL图像
                    if pil_available:
                        try:
                            # 创建兼容的设备上下文和位图
                            hdc_screen = win32gui.GetDC(None)
                            hdc_mem = win32gui.CreateCompatibleDC(hdc_screen)
                            
                            # 创建目标位图
                            width, height = 48, 48  # 我们需要的尺寸
                            h_bitmap = win32gui.CreateCompatibleBitmap(hdc_screen, width, height)
                            old_bitmap = win32gui.SelectObject(hdc_mem, h_bitmap)
                            
                            # 根据当前主题模式选择合适的背景色
                            is_dark_mode = ctk.get_appearance_mode() == "dark"
                            # 深色模式使用与应用背景协调的颜色
                            bg_color_ref = 0x2A2D2E if is_dark_mode else 0xF0F0F0
                            
                            # 创建与背景色匹配的画刷
                            bg_brush = win32gui.CreateSolidBrush(bg_color_ref)
                            # 填充背景
                            win32gui.FillRect(hdc_mem, (0, 0, width, height), bg_brush)
                            # 清理画刷资源
                            win32gui.DeleteObject(bg_brush)
                            
                            # 直接绘制图标到位图上
                            win32gui.DrawIcon(hdc_mem, 0, 0, shinfo.hIcon)
                            
                            # 清理资源前先创建PIL图像
                            # 使用更安全的方法获取位图数据
                            import win32ui
                            
                            # 使用win32ui位图对象获取位图数据
                            bmp = win32ui.CreateBitmapFromHandle(h_bitmap)
                            bmp_info = bmp.GetInfo()
                            bmp_str = bmp.GetBitmapBits(True)  # 使用win32ui的GetBitmapBits方法
                            
                            # 清理资源
                            win32gui.SelectObject(hdc_mem, old_bitmap)
                            win32gui.DeleteObject(h_bitmap)
                            win32gui.DeleteDC(hdc_mem)
                            win32gui.ReleaseDC(None, hdc_screen)
                            
                            # 创建PIL图像 - Windows位图通常是BGR格式
                            img = Image.frombuffer('RGB', (bmp_info['bmWidth'], bmp_info['bmHeight']), bmp_str, 'raw', 'BGRX', 0, 1)
                            # 添加Alpha通道以支持透明度
                            img = img.convert('RGBA')
                            
                            # 确保图像是RGBA格式以支持透明度
                            if img.mode != 'RGBA':
                                img = img.convert('RGBA')
                            
                            # 图标句柄已经在前面清理过了，这里不需要重复删除
                            win32gui.DestroyIcon(shinfo.hIcon)
                            
                            logger.debug(f"成功将Windows图标转换为PIL图像，尺寸: {img.size}, 模式: {img.mode}")
                            
                            # 转换为PhotoImage
                            photo = ImageTk.PhotoImage(img)
                            logger.debug(f"成功创建PhotoImage对象")
                            return photo
                        except Exception as e:
                            logger.error(f"转换Windows图标失败: {e}")
                            # 确保即使失败也清理图标句柄
                            try:
                                win32gui.DestroyIcon(shinfo.hIcon)
                            except:
                                pass
                    else:
                        logger.warning("PIL不可用，无法转换Windows图标")
                        try:
                            win32gui.DestroyIcon(shinfo.hIcon)
                        except:
                            pass
                else:
                    logger.warning("获取图标句柄失败")
                    # 如果SHGetFileInfoW失败，尝试使用LoadImage
                    try:
                        logger.debug("尝试使用LoadImage作为备选方案")
                        if is_folder:
                            # 对于文件夹，使用系统文件夹图标
                            h_icon = win32gui.LoadIcon(0, win32con.IDI_FOLDER)
                        else:
                            # 对于文件，尝试获取关联图标
                            h_icon = win32gui.LoadImage(0, normalized_path, win32con.IMAGE_ICON, 32, 32, win32con.LR_LOADFROMFILE)
                        
                        if h_icon != 0:
                            logger.debug(f"成功通过LoadImage获取图标句柄: {h_icon}")
                            # 转换为PIL图像的代码...
                            if pil_available:
                                # 使用与上面相同的转换代码
                                hdc_screen = win32gui.GetDC(None)
                                hdc_mem = win32gui.CreateCompatibleDC(hdc_screen)
                                old_bitmap = win32gui.SelectObject(hdc_mem, h_icon)
                                
                                width, height = 48, 48
                                h_bitmap = win32gui.CreateCompatibleBitmap(hdc_screen, width, height)
                                win32gui.SelectObject(hdc_mem, h_bitmap)
                                
                                # 根据当前主题模式选择合适的背景色
                                is_dark_mode = ctk.get_appearance_mode() == "dark"
                                # 深色模式使用与应用背景协调的颜色
                                bg_color_ref = 0x2A2D2E if is_dark_mode else 0xF0F0F0
                                
                                # 创建与背景色匹配的画刷
                                bg_brush = win32gui.CreateSolidBrush(bg_color_ref)
                                # 填充背景
                                win32gui.FillRect(hdc_mem, (0, 0, width, height), bg_brush)
                                # 清理画刷资源
                                win32gui.DeleteObject(bg_brush)
                                win32gui.DrawIcon(hdc_mem, 0, 0, h_icon)
                                
                                # 使用win32ui位图对象获取位图数据
                                import win32ui
                                bmp = win32ui.CreateBitmapFromHandle(h_bitmap)
                                bmp_str = bmp.GetBitmapBits(True)  # 使用win32ui的GetBitmapBits方法
                                
                                win32gui.SelectObject(hdc_mem, old_bitmap)
                                win32gui.DeleteDC(hdc_mem)
                                win32gui.ReleaseDC(None, hdc_screen)
                                
                                img = Image.frombuffer(
                                    'RGBA',
                                    (width, height),
                                    bmp_str,
                                    'raw',
                                    'BGRX',
                                    0,
                                    1
                                )
                                
                                if img.mode != 'RGBA':
                                    img = img.convert('RGBA')
                                
                                # 位图句柄由win32ui自动管理，不需要手动删除
                                win32gui.DestroyIcon(h_icon)
                                
                                photo = ImageTk.PhotoImage(img)
                                return photo
                            else:
                                win32gui.DestroyIcon(h_icon)
                    except Exception as e:
                        logger.error(f"LoadImage方法失败: {e}")
            except ImportError as e:
                logger.warning(f"Windows API模块不可用: {e}")
            except Exception as e:
                logger.error(f"使用Windows API获取图标失败: {e}", exc_info=True)
            
            # 尝试使用PyQt5作为备选方案（如果可用）
            try:
                logger.debug("尝试使用PyQt5作为备选方案获取图标")
                from PyQt5.QtWidgets import QApplication
                from PyQt5.QtGui import QIcon, QPixmap
                
                # 确保QApplication实例存在
                app = QApplication.instance()
                if app is None:
                    app = QApplication([])
                
                # 尝试获取图标
                icon = QIcon(normalized_path)
                if not icon.isNull():
                    logger.debug("成功通过PyQt5获取图标")
                    pixmap = icon.pixmap(48, 48)
                    
                    # 转换为PIL图像
                    if pil_available:
                        # 获取QImage
                        qimage = pixmap.toImage()
                        
                        # 转换为RGBA字节数组
                        width = qimage.width()
                        height = qimage.height()
                        ptr = qimage.bits()
                        ptr.setsize(height * width * 4)
                        img = Image.frombuffer(
                            'RGBA',
                            (width, height),
                            ptr.tobytes(),
                            'raw',
                            'BGRA',
                            0,
                            1
                        )
                        
                        photo = ImageTk.PhotoImage(img)
                        return photo
            except ImportError:
                logger.debug("PyQt5不可用")
            except Exception as e:
                logger.error(f"PyQt5方法获取图标失败: {e}")
            
            # 如果都失败了，使用默认图标
            logger.debug("所有获取原始图标的方法都失败了，使用默认图标")
            return self._get_default_emoji_icon()
            
        except Exception as e:
            logger.error(f"获取图标过程中发生异常: {e}")
            import traceback
            logger.error(f"错误堆栈: {traceback.format_exc()}")
            return self._get_default_emoji_icon()
    
    def _get_default_emoji_icon(self):
        """创建一个默认的文件图标作为后备"""
        try:
            logger.debug("使用默认文件图标")
            # 创建一个简单的默认图标，而不是返回None
            from PIL import Image, ImageTk
            width, height = 48, 48
            img = Image.new('RGBA', (width, height), (255, 255, 255, 0))
            from PIL import ImageDraw
            draw = ImageDraw.Draw(img)
            
            # 绘制灰色圆角矩形作为默认图标
            color = (169, 169, 169)  # 深灰色
            radius = 8
            draw.rectangle([radius, 0, width-radius, height], fill=color)
            draw.rectangle([0, radius, width, height-radius], fill=color)
            draw.ellipse([0, 0, radius*2, radius*2], fill=color)
            draw.ellipse([width-radius*2, 0, width, radius*2], fill=color)
            draw.ellipse([0, height-radius*2, radius*2, height], fill=color)
            draw.ellipse([width-radius*2, height-radius*2, width, height], fill=color)
            
            # 添加文件标记
            file_width, file_height = 24, 28
            file_x = (width - file_width) // 2
            file_y = (height - file_height) // 2
            draw.rectangle([file_x, file_y + 4, file_x + file_width, file_y + file_height], fill=(105, 105, 105))
            draw.rectangle([file_x, file_y, file_x + file_width - 8, file_y + 4], fill=(70, 70, 70))
            
            return ImageTk.PhotoImage(img)
        except Exception as e:
            logger.error(f"创建默认图标失败: {e}")
            # 如果PIL不可用或出错，返回None让调用方处理
            return None
    
    def _run_shortcut(self, name):
        """运行快捷方式"""
        try:
            # 从shortcuts字典直接获取数据
            all_shortcuts = self.shortcuts_handler.get_all_shortcuts()
            if name not in all_shortcuts:
                messagebox.showerror("错误", "找不到该快捷方式")
                return
            
            data = all_shortcuts[name]
            # 确保data是字典类型
            if isinstance(data, str):
                shortcut_data = {
                    "path": data,
                    "type": "folder" if os.path.isdir(data) else "file"
                }
            else:
                shortcut_data = data
            
            path = shortcut_data.get('path', '')
            shortcut_type = shortcut_data.get('type', 'file')
            
            if shortcut_type == 'website':
                # 打开网址
                webbrowser.open(path)
                self.status_var.set(f"正在打开网址: {name}")
            else:
                # 运行文件或打开文件夹
                self.shortcuts_handler.run_shortcut(name)
                self.status_var.set(f"正在运行: {name}")
            
            # 更新最近使用
            self._update_recent_usage(name)
            
        except Exception as e:
            logger.error(f"运行快捷方式失败: {e}")
            messagebox.showerror("错误", f"运行失败: {str(e)}")
            self.status_var.set(f"运行失败: {name}")

    
    def _update_recent_usage(self, name):
        """更新最近使用的快捷方式"""
        # 更新使用时间戳
        self.recently_used[name] = time.time()
        
        # 只保留最近20个
        if len(self.recently_used) > 20:
            # 按时间戳排序并删除最旧的
            sorted_items = sorted(self.recently_used.items(), key=lambda x: x[1])
            self.recently_used = dict(sorted_items[-20:])
    
    def _delete_shortcut(self, name):
        """删除单个快捷方式"""
        if messagebox.askyesno("确认", f"确定要删除快捷方式 '{name}' 吗？"):
            try:
                self.shortcuts_handler.delete_shortcut(name)
                
                # 从最近使用中移除
                if name in self.recently_used:
                    del self.recently_used[name]
                
                # 更新显示
                self._update_shortcuts_display()
                
                # 更新状态栏
                self.status_var.set(f"快捷方式 '{name}' 已删除")
                
            except Exception as e:
                logger.error(f"删除快捷方式失败: {e}")
                messagebox.showerror("错误", f"删除失败: {str(e)}")
    
    def _delete_selected_shortcuts(self):
        """删除选中的快捷方式（预留功能）"""
        # 此功能需要实现多选支持，目前可以提示用户使用右键菜单删除
        messagebox.showinfo("提示", "请在列表视图中选择要删除的项目，或使用右键菜单删除单个项目")
    
    def _open_private_space(self):
        """打开私人空间入口，处理密码验证逻辑"""
        try:
            # 检查是否已设置密码
            if not os.path.exists(self.password_file):
                # 首次使用，显示设置密码对话框
                self._show_set_password_dialog()
            else:
                # 已设置密码，显示验证密码对话框
                self._show_verify_password_dialog()
        except Exception as e:
            logger.error(f"打开私人空间失败: {e}")
            messagebox.showerror("错误", f"打开私人空间失败: {str(e)}")
    
    def _hash_password(self, password):
        """对密码进行哈希处理"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def _show_set_password_dialog(self):
        """显示设置密码对话框"""
        try:
            # 创建对话框
            dialog = ctk.CTkToplevel(self.root)
            dialog.title("设置私人空间密码")
            dialog.geometry("350x250")
            dialog.resizable(False, False)
            dialog.transient(self.root)  # 设置为主窗口的子窗口
            dialog.grab_set()  # 模态对话框
            
            # 居中显示
            dialog.update_idletasks()
            width = dialog.winfo_width()
            height = dialog.winfo_height()
            x = (self.root.winfo_width() // 2) + self.root.winfo_x() - (width // 2)
            y = (self.root.winfo_height() // 2) + self.root.winfo_y() - (height // 2)
            dialog.geometry(f"{width}x{height}+{x}+{y}")
            
            # 创建内容框架
            content_frame = ctk.CTkFrame(dialog)
            content_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            # 标题标签
            title_label = ctk.CTkLabel(
                content_frame,
                text="首次使用私人空间，请设置密码",
                font=ctk.CTkFont(size=16, weight="bold")
            )
            title_label.pack(pady=10)
            
            # 密码输入
            ctk.CTkLabel(content_frame, text="设置密码:", font=ctk.CTkFont(size=14)).pack(anchor="w", pady=(10, 5))
            password_var = ctk.StringVar()
            password_entry = ctk.CTkEntry(
                content_frame,
                textvariable=password_var,
                show="*",
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            password_entry.pack(pady=5)
            
            # 确认密码输入
            ctk.CTkLabel(content_frame, text="确认密码:", font=ctk.CTkFont(size=14)).pack(anchor="w", pady=(10, 5))
            confirm_var = ctk.StringVar()
            confirm_entry = ctk.CTkEntry(
                content_frame,
                textvariable=confirm_var,
                show="*",
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            confirm_entry.pack(pady=5)
            
            # 状态标签
            status_var = ctk.StringVar()
            status_label = ctk.CTkLabel(content_frame, textvariable=status_var, text_color="#FF5252")
            status_label.pack(pady=5)
            
            def set_password():
                password = password_var.get()
                confirm = confirm_var.get()
                
                # 验证密码
                if not password:
                    status_var.set("密码不能为空")
                    return
                
                if len(password) < 6:
                    status_var.set("密码长度至少为6位")
                    return
                
                if password != confirm:
                    status_var.set("两次输入的密码不一致")
                    return
                
                try:
                    # 保存哈希后的密码
                    hashed_password = self._hash_password(password)
                    with open(self.password_file, 'w') as f:
                        f.write(hashed_password)
                    
                    # 初始化私人空间数据
                    self._initialize_private_space_data()
                    
                    # 关闭对话框
                    dialog.destroy()
                    
                    # 打开私人空间
                    self._open_private_space_interface()
                    
                except Exception as e:
                    logger.error(f"保存密码失败: {e}")
                    status_var.set(f"设置密码失败: {str(e)}")
            
            # 按钮区域
            buttons_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            buttons_frame.pack(pady=10)
            
            set_button = ctk.CTkButton(
                buttons_frame,
                text="设置",
                width=100,
                corner_radius=6,
                command=set_password
            )
            set_button.pack(padx=10, pady=5)
            
            # 添加键盘事件
            password_entry.bind("<Return>", lambda event: confirm_entry.focus())
            confirm_entry.bind("<Return>", lambda event: set_password())
            
        except Exception as e:
            logger.error(f"创建设置密码对话框失败: {e}")
            messagebox.showerror("错误", f"创建对话框失败: {str(e)}")
    
    def _show_verify_password_dialog(self):
        """显示验证密码对话框"""
        try:
            # 创建对话框
            dialog = ctk.CTkToplevel(self.root)
            dialog.title("验证私人空间密码")
            dialog.geometry("350x240")  # 增加高度
            dialog.resizable(False, False)
            dialog.transient(self.root)  # 设置为主窗口的子窗口
            dialog.grab_set()  # 模态对话框
            
            # 居中显示
            dialog.update_idletasks()
            width = dialog.winfo_width()
            height = dialog.winfo_height()
            x = (self.root.winfo_width() // 2) + self.root.winfo_x() - (width // 2)
            y = (self.root.winfo_height() // 2) + self.root.winfo_y() - (height // 2)
            dialog.geometry(f"{width}x{height}+{x}+{y}")
            
            # 创建内容框架
            content_frame = ctk.CTkFrame(dialog)
            content_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            # 标题标签
            title_label = ctk.CTkLabel(
                content_frame,
                text="请输入私人空间密码",
                font=ctk.CTkFont(size=16, weight="bold")
            )
            title_label.pack(pady=10)
            
            # 密码输入
            ctk.CTkLabel(content_frame, text="密码:", font=ctk.CTkFont(size=14)).pack(anchor="w", pady=(10, 5))
            password_var = ctk.StringVar()
            password_entry = ctk.CTkEntry(
                content_frame,
                textvariable=password_var,
                show="*",
                width=300,
                corner_radius=6,
                font=ctk.CTkFont(size=14)
            )
            password_entry.pack(pady=5)
            password_entry.focus()
            
            # 状态标签
            status_var = ctk.StringVar()
            status_label = ctk.CTkLabel(content_frame, textvariable=status_var, text_color="#FF5252")
            status_label.pack(pady=5)
            
            def verify_password():
                password = password_var.get()
                
                # 读取存储的哈希密码
                try:
                    with open(self.password_file, 'r') as f:
                        stored_hash = f.read().strip()
                    
                    # 验证密码
                    if self._hash_password(password) == stored_hash:
                        # 密码正确，关闭对话框并打开私人空间
                        dialog.destroy()
                        self._load_private_space_data()
                        self._open_private_space_interface()
                    else:
                        status_var.set("密码错误，请重新输入")
                        password_var.set("")
                        password_entry.focus()
                except Exception as e:
                    logger.error(f"验证密码失败: {e}")
                    status_var.set(f"验证密码失败: {str(e)}")
            
            # 按钮区域
            buttons_frame = ctk.CTkFrame(dialog, fg_color="transparent")
            buttons_frame.pack(fill="x", padx=20, pady=15)
            
            # 设置按钮区域的列配置
            buttons_frame.grid_columnconfigure(0, weight=1)
            buttons_frame.grid_columnconfigure(1, weight=1)
            
            verify_button = ctk.CTkButton(
                buttons_frame,
                text="验证",
                width=100,
                corner_radius=6,
                command=verify_password
            )
            verify_button.grid(row=0, column=0, padx=(0, 5), pady=5, sticky="e")
            
            cancel_button = ctk.CTkButton(
                buttons_frame,
                text="取消",
                width=100,
                corner_radius=6,
                command=dialog.destroy
            )
            cancel_button.grid(row=0, column=1, padx=(5, 0), pady=5, sticky="w")
            
            # 添加键盘事件
            password_entry.bind("<Return>", lambda event: verify_password())
            dialog.bind("<Escape>", lambda event: dialog.destroy())
            
        except Exception as e:
            logger.error(f"创建验证密码对话框失败: {e}")
            messagebox.showerror("错误", f"创建对话框失败: {str(e)}")
    
    def _initialize_private_space_data(self):
        """初始化私人空间数据"""
        self.private_space_data = {
            "items": [],
            "last_updated": time.time()
        }
        self._save_private_space_data()
    
    def _save_private_space_data(self):
        """保存私人空间数据"""
        try:
            # 更新最后修改时间
            self.private_space_data["last_updated"] = time.time()
            
            # 这里应该使用加密保存，暂时使用简单的JSON
            import json
            # 尝试使用当前目录保存数据，避免用户目录权限问题
            private_data_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.private_space_data')
            with open(private_data_file, 'w', encoding='utf-8') as f:
                json.dump(self.private_space_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"调试信息: 保存私人空间数据失败: {str(e)}")
    
    def _load_private_space_data(self):
        """加载私人空间数据"""
        try:
            import json
            # 尝试使用当前目录加载数据
            private_data_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.private_space_data')
            if os.path.exists(private_data_file):
                with open(private_data_file, 'r', encoding='utf-8') as f:
                    self.private_space_data = json.load(f)
            else:
                # 尝试从用户目录加载作为备选
                private_data_file_user = os.path.join(os.path.expanduser('~'), '.private_space_data')
                if os.path.exists(private_data_file_user):
                    with open(private_data_file_user, 'r', encoding='utf-8') as f:
                        self.private_space_data = json.load(f)
                else:
                    self._initialize_private_space_data()
        except Exception as e:
            print(f"调试信息: 加载私人空间数据失败: {str(e)}")
            self._initialize_private_space_data()
    
    def _open_private_space_interface(self):
        """打开私人空间界面"""
        try:
            # 创建私人空间窗口
            private_window = ctk.CTkToplevel(self.root)
            private_window.title("私人空间")
            private_window.geometry("800x600")
            private_window.minsize(600, 400)
            private_window.transient(self.root)  # 设置为主窗口的子窗口
            
            # 居中显示
            private_window.update_idletasks()
            width = private_window.winfo_width()
            height = private_window.winfo_height()
            x = (self.root.winfo_width() // 2) + self.root.winfo_x() - (width // 2)
            y = (self.root.winfo_height() // 2) + self.root.winfo_y() - (height // 2)
            private_window.geometry(f"{width}x{height}+{x}+{y}")
            
            # 创建标题栏
            title_frame = ctk.CTkFrame(private_window, height=50, corner_radius=0)
            title_frame.pack(fill="x", padx=0, pady=0)
            
            # 标题标签
            title_label = ctk.CTkLabel(
                title_frame,
                text="私人空间",
                font=ctk.CTkFont(size=18, weight="bold"),
                text_color="#ffffff"
            )
            title_label.pack(side="left", padx=20, pady=10)
            
            # 统计信息
            stats_var = ctk.StringVar()
            stats_var.set(f"文件数量: {len(self.private_space_data.get('items', []))}")
            stats_label = ctk.CTkLabel(
                title_frame,
                textvariable=stats_var,
                font=ctk.CTkFont(size=14)
            )
            stats_label.pack(side="right", padx=20, pady=10)
            
            # 创建主内容区域
            main_content_frame = ctk.CTkScrollableFrame(
                private_window,
                corner_radius=0
            )
            main_content_frame.pack(fill="both", expand=True, padx=10, pady=10)
            
            # 设置网格布局配置
            main_content_frame.grid_columnconfigure(0, weight=1)
            
            # 创建添加按钮区域
            add_button_frame = ctk.CTkFrame(main_content_frame, corner_radius=12)
            add_button_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
            # 确保add_button_frame可以扩展
            main_content_frame.grid_rowconfigure(0, weight=0, minsize=150)
            
            # 带加号的方块按钮 - 修复只显示一半的问题
            add_button = ctk.CTkButton(
                add_button_frame,
                text="+",  # 直接在按钮文本中显示加号，而不是使用额外的标签
                width=150,  # 减小尺寸以确保完全显示
                height=150,
                corner_radius=12,
                fg_color="transparent",
                hover_color="#3a3a3a",
                border_width=2,
                border_color="#6c6c6c",
                font=ctk.CTkFont(size=48, weight="bold"),  # 直接在按钮上设置字体
                text_color="#6c6c6c",
                command=lambda: self._show_add_item_dialog(private_window, stats_var)
            )
            # 使用grid布局确保按钮完全填充框架
            add_button_frame.grid_rowconfigure(0, weight=1)
            add_button_frame.grid_columnconfigure(0, weight=1)
            add_button.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
            # 添加备用的pack配置以确保兼容性
            add_button.pack(fill="both", expand=True, padx=20, pady=20)
            
            # 添加提示文本
            hint_label = ctk.CTkLabel(
                add_button_frame,
                text="点击添加文件或文件夹",
                font=ctk.CTkFont(size=14)
            )
            hint_label.pack(pady=10)
            
            # 创建文件列表区域标题
            files_title_frame = ctk.CTkFrame(main_content_frame, fg_color="transparent")
            files_title_frame.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
            
            ctk.CTkLabel(
                files_title_frame,
                text="已添加的项目",
                font=ctk.CTkFont(size=16, weight="bold")
            ).pack(side="left", padx=10)
            
            # 创建文件列表区域
            self.private_files_frame = ctk.CTkFrame(main_content_frame, corner_radius=8)
            self.private_files_frame.grid(row=2, column=0, padx=10, pady=5, sticky="nsew")
            self.private_files_frame.grid_columnconfigure(0, weight=1)
            
            # 显示已有的项目
            self._display_private_items(self.private_files_frame, stats_var)
            
            # 添加窗口关闭事件
            private_window.protocol("WM_DELETE_WINDOW", lambda: self._on_private_window_close(private_window))
            
        except Exception as e:
            logger.error(f"打开私人空间界面失败: {e}")
            messagebox.showerror("错误", f"打开私人空间界面失败: {str(e)}")
    
    def _display_private_items(self, parent_frame, stats_var):
        """显示私人空间中的项目"""
        try:
            # 清空现有内容
            for widget in parent_frame.winfo_children():
                widget.destroy()
            
            items = self.private_space_data.get('items', [])
            
            if not items:
                # 如果没有项目，显示空状态
                empty_label = ctk.CTkLabel(
                    parent_frame,
                    text="私人空间中还没有任何项目",
                    font=ctk.CTkFont(size=14, weight="normal"),  # 确保使用正确的字体权重
                    text_color="#888888"
                )
                empty_label.pack(pady=40)
            else:
                # 显示项目列表
                for index, item in enumerate(items):
                    try:
                        item_frame = ctk.CTkFrame(parent_frame, corner_radius=6)
                        item_frame.grid(row=index, column=0, padx=10, pady=5, sticky="ew")
                        
                        # 文件图标 - 使用系统原生图标而不是emoji
                        path = item.get('path', '')
                        is_folder = item.get('type') == 'folder'
                        
                        # 使用_get_file_icon方法获取系统图标
                        try:
                            icon_photo = self._get_file_icon(path, is_folder)
                            if icon_photo:
                                icon_label = ctk.CTkLabel(
                                    item_frame,
                                    image=icon_photo
                                )
                                icon_label.image = icon_photo  # 保持引用以防止被垃圾回收
                            else:
                                # 备用方案：使用emoji图标
                                icon_label = ctk.CTkLabel(
                                    item_frame,
                                    text="📁" if is_folder else "📄",
                                    font=ctk.CTkFont(size=20, weight="normal")
                                )
                        except Exception as icon_e:
                            # 出错时使用备用图标
                            logger.warning(f"获取图标失败: {icon_e}")
                            icon_label = ctk.CTkLabel(
                                item_frame,
                                text="📁" if is_folder else "📄",
                                font=ctk.CTkFont(size=20, weight="normal")
                            )
                        
                        icon_label.pack(side="left", padx=10, pady=10)
                        
                        # 文件信息
                        info_frame = ctk.CTkFrame(item_frame, fg_color="transparent")
                        info_frame.pack(side="left", fill="x", expand=True, padx=10, pady=5)
                        
                        # 增强的文件名称显示，确保总是有正确的名称
                        display_name = item.get('name', '未知')
                        if display_name == '未知' and path:
                            # 如果名称不可用但路径可用，从路径提取名称
                            display_name = os.path.basename(path)
                            
                        name_label = ctk.CTkLabel(
                            info_frame,
                            text=display_name,
                            font=ctk.CTkFont(size=14, weight="normal"),  # 确保使用正确的字体权重
                            wraplength=250  # 添加文本换行，防止长文件名溢出
                        )
                        name_label.pack(anchor="w")
                        
                        path_label = ctk.CTkLabel(
                            info_frame,
                            text=item.get('path', '未知路径'),
                            font=ctk.CTkFont(size=12, weight="normal"),  # 确保使用正确的字体权重
                            text_color="#888888"
                        )
                        path_label.pack(anchor="w", pady=(2, 0))
                        
                        # 操作按钮
                        actions_frame = ctk.CTkFrame(item_frame, fg_color="transparent")
                        actions_frame.pack(side="right", padx=10, pady=10)
                        
                        # 打开按钮
                        open_button = ctk.CTkButton(
                            actions_frame,
                            text="打开",
                            width=60,
                            height=28,
                            font=ctk.CTkFont(size=12, weight="normal"),  # 确保使用正确的字体权重
                            command=lambda p=item.get('path'): self._open_private_item(p)
                        )
                        open_button.pack(side="left", padx=5)
                        
                        # 删除按钮
                        delete_button = ctk.CTkButton(
                            actions_frame,
                            text="删除",
                            width=60,
                            height=28,
                            font=ctk.CTkFont(size=12, weight="normal"),  # 确保使用正确的字体权重
                            fg_color="#e53935",
                            hover_color="#c62828",
                            command=lambda i=index: self._delete_private_item(i, parent_frame, stats_var)
                        )
                        delete_button.pack(side="left", padx=5)
                    except Exception as item_e:
                        # 单个项目创建失败时记录错误并继续
                        import traceback
                        error_trace = traceback.format_exc()
                        logger.error(f"创建项目项 {index} 失败: {item_e}\n{error_trace}")
                        # 创建一个错误占位标签
                        error_label = ctk.CTkLabel(
                            parent_frame,
                            text=f"创建项目时出错",
                            font=ctk.CTkFont(size=12, weight="normal"),
                            text_color="#e53935"
                        )
                        error_label.grid(row=index, column=0, padx=10, pady=5, sticky="ew")
            
            # 更新统计信息
            stats_var.set(f"文件数量: {len(items)}")
            
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"显示私人空间项目失败: {e}\n{error_trace}")
            # 显示更详细的错误信息，帮助定位问题
            messagebox.showerror("错误", f"显示项目失败: {str(e)}\n\n详细信息: {error_trace}")
    
    def _open_private_item(self, path):
        """打开私人空间中的项目"""
        try:
            if os.path.exists(path):
                if os.name == 'nt':  # Windows
                    os.startfile(path)
                elif os.name == 'posix':  # macOS or Linux
                    import subprocess
                    subprocess.run(['xdg-open', path] if os.name == 'posix' and 'darwin' not in sys.platform else ['open', path])
            else:
                messagebox.showerror("错误", f"文件或文件夹不存在: {path}")
        except Exception as e:
            logger.error(f"打开私人空间项目失败: {e}")
            messagebox.showerror("错误", f"打开项目失败: {str(e)}")
    
    def _delete_private_item(self, index, parent_frame, stats_var):
        """删除私人空间中的项目"""
        try:
            if messagebox.askyesno("确认删除", "确定要从私人空间中删除此项目吗？"):
                items = self.private_space_data.get('items', [])
                if 0 <= index < len(items):
                    del items[index]
                    self._save_private_space_data()
                    # 刷新显示
                    self._display_private_items(parent_frame, stats_var)
                    # 更新统计信息
                    stats_var.set(f"文件数量: {len(items)}")
        except Exception as e:
            logger.error(f"删除私人空间项目失败: {e}")
            messagebox.showerror("错误", f"删除项目失败: {str(e)}")
    
    def _on_private_window_close(self, window):
        """私人空间窗口关闭事件"""
        window.destroy()
    
    def _show_add_item_dialog(self, parent_window, stats_var):
        """显示添加项目对话框"""
        try:
            # 创建对话框
            dialog = ctk.CTkToplevel(parent_window)
            dialog.title("添加到私人空间")
            dialog.geometry("400x250")
            dialog.resizable(False, False)
            dialog.transient(parent_window)
            dialog.grab_set()
            
            # 居中显示
            dialog.update_idletasks()
            width = dialog.winfo_width()
            height = dialog.winfo_height()
            x = (parent_window.winfo_width() // 2) + parent_window.winfo_x() - (width // 2)
            y = (parent_window.winfo_height() // 2) + parent_window.winfo_y() - (height // 2)
            dialog.geometry(f"{width}x{height}+{x}+{y}")
            
            # 创建内容框架
            content_frame = ctk.CTkFrame(dialog)
            content_frame.pack(fill="both", expand=True, padx=20, pady=20)
            
            # 标题标签 - 确保使用正确的字体权重
            title_label = ctk.CTkLabel(
                content_frame,
                text="选择添加方式",
                font=ctk.CTkFont(size=16, weight="bold")  # 确保使用bold而不是medium
            )
            title_label.pack(pady=15)
            
            # 按钮区域
            buttons_frame = ctk.CTkFrame(content_frame, fg_color="transparent")
            buttons_frame.pack(fill="x", pady=10)
            
            # 文件选择按钮 - 确保使用正确的字体权重
            file_button = ctk.CTkButton(
                buttons_frame,
                text="选择文件",
                height=40,
                corner_radius=6,
                font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                command=lambda: self._select_file_for_private_space(parent_window, dialog, stats_var)
            )
            file_button.pack(fill="x", pady=5)
            
            # 文件夹选择按钮 - 确保使用正确的字体权重
            folder_button = ctk.CTkButton(
                buttons_frame,
                text="选择文件夹",
                height=40,
                corner_radius=6,
                font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                command=lambda: self._select_folder_for_private_space(parent_window, dialog, stats_var)
            )
            folder_button.pack(fill="x", pady=5)
            
            # 从现有分区选择按钮 - 确保使用正确的字体权重
            section_button = ctk.CTkButton(
                buttons_frame,
                text="从现有分区选择",
                height=40,
                corner_radius=6,
                font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                command=lambda: self._select_from_sections(parent_window, dialog, stats_var)
            )
            section_button.pack(fill="x", pady=5)
            
            # 取消按钮 - 确保使用正确的字体权重
            cancel_button = ctk.CTkButton(
                content_frame,
                text="取消",
                height=35,
                corner_radius=6,
                font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                fg_color="#6c6c6c",
                hover_color="#505050",
                command=dialog.destroy
            )
            cancel_button.pack(fill="x", pady=10)
            
        except Exception as e:
            # 添加更详细的错误处理和日志记录
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"创建添加项目对话框失败: {e}\n{error_trace}")
            messagebox.showerror("错误", f"创建对话框失败: {str(e)}\n\n详细信息: {error_trace}")
    
    def _select_file_for_private_space(self, parent_window, dialog, stats_var):
        """选择文件添加到私人空间"""
        try:
            # 使用系统文件选择对话框
            file_path = filedialog.askopenfilename(
                title="选择要添加到私人空间的文件",
                filetypes=[("所有文件", "*.*")]
            )
            
            if file_path:
                # 检查文件是否已存在于私人空间
                if self._is_item_already_in_private_space(file_path):
                    messagebox.showinfo("提示", "该文件已在私人空间中")
                    return
                
                # 添加到私人空间
                self._add_to_private_space({
                    "type": "file",
                    "name": os.path.basename(file_path),
                    "path": file_path,
                    "added_at": time.time()
                })
                
                # 更新显示
                self._display_private_items(self.private_files_frame, stats_var)
                stats_var.set(f"文件数量: {len(self.private_space_data.get('items', []))}")
                
                # 关闭对话框
                dialog.destroy()
                
                messagebox.showinfo("成功", f"文件 '{os.path.basename(file_path)}' 已添加到私人空间")
                
        except Exception as e:
            # 添加更详细的错误处理和日志记录
            error_msg = f"选择文件失败: {str(e)}"
            print(f"调试信息: {error_msg}, 异常类型: {type(e).__name__}")
            # 直接在消息框中显示更详细的信息，而不是依赖日志
            messagebox.showerror("错误", f"选择文件失败: {str(e)}")
    
    def _select_folder_for_private_space(self, parent_window, dialog, stats_var):
        """选择文件夹添加到私人空间"""
        try:
            # 使用系统文件夹选择对话框
            folder_path = filedialog.askdirectory(
                title="选择要添加到私人空间的文件夹"
            )
            
            if folder_path:
                # 检查文件夹是否已存在于私人空间
                if self._is_item_already_in_private_space(folder_path):
                    messagebox.showinfo("提示", "该文件夹已在私人空间中")
                    return
                
                # 添加到私人空间
                self._add_to_private_space({
                    "type": "folder",
                    "name": os.path.basename(folder_path),
                    "path": folder_path,
                    "added_at": time.time()
                })
                
                # 更新显示
                self._display_private_items(self.private_files_frame, stats_var)
                stats_var.set(f"文件数量: {len(self.private_space_data.get('items', []))}")
                
                # 关闭对话框
                dialog.destroy()
                
                messagebox.showinfo("成功", f"文件夹 '{os.path.basename(folder_path)}' 已添加到私人空间")
                
        except Exception as e:
            # 添加更详细的错误处理和日志记录
            error_msg = f"选择文件夹失败: {str(e)}"
            print(f"调试信息: {error_msg}, 异常类型: {type(e).__name__}")
            # 直接在消息框中显示更详细的信息，而不是依赖日志
            messagebox.showerror("错误", f"选择文件夹失败: {str(e)}")
    
    def _select_from_sections(self, parent_window, dialog, stats_var):
        """从现有分区选择项目添加到私人空间"""
        try:
            # 创建分区选择对话框
            section_dialog = ctk.CTkToplevel(parent_window)
            section_dialog.title("从分区选择")
            section_dialog.geometry("700x500")  # 增大对话框尺寸
            section_dialog.transient(parent_window)
            section_dialog.grab_set()
            
            # 居中显示
            section_dialog.update_idletasks()
            width = section_dialog.winfo_width()
            height = section_dialog.winfo_height()
            x = (parent_window.winfo_width() // 2) + parent_window.winfo_x() - (width // 2)
            y = (parent_window.winfo_height() // 2) + parent_window.winfo_y() - (height // 2)
            section_dialog.geometry(f"{width}x{height}+{x}+{y}")
            
            # 创建标题标签 - 添加一个额外的选项，允许用户直接浏览所有分区
            ctk.CTkLabel(
                section_dialog,
                text="从分区选择文件或文件夹",
                font=ctk.CTkFont(size=16, weight="bold")  # 确保使用bold而不是medium
            ).pack(pady=10)
            
            # 添加直接浏览按钮 - 让用户可以直接浏览所有分区
            browse_all_button = ctk.CTkButton(
                section_dialog,
                text="直接浏览所有分区",
                height=40,
                font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                command=lambda: self._browse_all_drives(parent_window, dialog, stats_var, section_dialog)
            )
            browse_all_button.pack(fill="x", padx=20, pady=10)
            
            # 创建分区选择区域
            section_frame = ctk.CTkFrame(section_dialog)
            section_frame.pack(fill="x", padx=20, pady=10)
            
            ctk.CTkLabel(
                section_frame,
                text="或者从现有分区选择:",
                font=ctk.CTkFont(size=14, weight="normal")  # 明确设置为normal
            ).pack(anchor="w", pady=(5, 0))
            
            # 获取所有分区 - 修复可能的属性错误
            sections = []
            if hasattr(self, 'sections'):
                # 尝试不同的方式获取分区数据
                if isinstance(self.sections, dict):
                    # 方式1: self.sections是字典，直接获取items
                    sections = list(self.sections.items())
                elif hasattr(self, 'shortcuts_handler') and hasattr(self.shortcuts_handler, 'sections'):
                    # 方式2: 从shortcuts_handler获取sections
                    sections = list(self.shortcuts_handler.sections.items())
                elif hasattr(self, 'section_buttons'):
                    # 方式3: 从section_buttons获取分区名称
                    section_names = list(self.section_buttons.keys())
                    # 过滤掉特殊分区
                    section_names = [s for s in section_names if s not in ['system', 'add_section']]
                    sections = [(name, {'name': name}) for name in section_names]
            
            # 添加一些默认分区作为后备
            if not sections:
                default_sections = ["工作", "娱乐", "文档", "网站", "文件夹"]
                sections = [(name, {'name': name}) for name in default_sections]
            
            if not sections:
                ctk.CTkLabel(
                    section_dialog,
                    text="没有可用的分区",
                    font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                    text_color="#888888"
                ).pack(pady=20)
            else:
                # 分区下拉菜单
                selected_section = ctk.StringVar(value=sections[0][0])
                section_dropdown = ctk.CTkOptionMenu(
                    section_frame,
                    variable=selected_section,
                    values=[section[0] for section in sections],
                    font=ctk.CTkFont(size=14, weight="normal")  # 明确设置为normal
                )
                section_dropdown.pack(fill="x", pady=5)
                
                # 创建快捷方式列表
                shortcuts_frame = ctk.CTkScrollableFrame(section_dialog)
                shortcuts_frame.pack(fill="both", expand=True, padx=20, pady=10)
                shortcuts_frame.grid_columnconfigure(0, weight=1)
                
                # 存储选中的快捷方式
                checkboxes = []
                
                def update_shortcuts_list():
                    """更新快捷方式列表"""
                    # 清空现有内容
                    for widget in shortcuts_frame.winfo_children():
                        widget.destroy()
                    
                    # 清空复选框列表
                    checkboxes.clear()
                    
                    # 获取选中分区的快捷方式 - 尝试多种数据获取方式
                    section_name = selected_section.get()
                    section_shortcuts = []
                    
                    # 尝试从self.sections获取
                    if hasattr(self, 'sections') and isinstance(self.sections, dict):
                        section_shortcuts = self.sections.get(section_name, {}).get('shortcuts', [])
                    
                    # 如果没有获取到，尝试从shortcuts_handler获取
                    if not section_shortcuts and hasattr(self, 'shortcuts_handler'):
                        try:
                            # 从shortcuts中过滤出对应分区的项
                            if hasattr(self.shortcuts_handler, 'shortcuts') and isinstance(self.shortcuts_handler.shortcuts, dict):
                                for name, data in self.shortcuts_handler.shortcuts.items():
                                    # 确保data是字典
                                    if isinstance(data, str):
                                        data = {"path": data, "type": "file"}
                                    # 检查分区匹配
                                    if data.get('section') == section_name or \
                                       (section_name == "文件夹" and data.get('type') == 'folder') or \
                                       (section_name == "网站" and data.get('type') == 'website'):
                                        section_shortcuts.append({
                                            "name": name,
                                            "path": data.get('path', ''),
                                            "type": data.get('type', 'file')
                                        })
                        except Exception as e:
                            logger.warning(f"从shortcuts_handler获取分区数据失败: {e}")
                    
                    # 如果还是没有数据，显示提示
                    if not section_shortcuts:
                        ctk.CTkLabel(
                            shortcuts_frame,
                            text="该分区没有快捷方式或无法访问数据",
                            font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                            text_color="#888888"
                        ).pack(pady=20)
                        return
                    
                    # 显示快捷方式列表
                    for index, shortcut in enumerate(section_shortcuts):
                        try:
                            item_frame = ctk.CTkFrame(shortcuts_frame, corner_radius=6)
                            item_frame.grid(row=index, column=0, padx=5, pady=3, sticky="ew")
                            
                            # 复选框
                            is_checked = ctk.BooleanVar(value=False)
                            checkbox = ctk.CTkCheckBox(
                                item_frame,
                                variable=is_checked,
                                text="",
                                corner_radius=4
                            )
                            checkbox.pack(side="left", padx=10, pady=10)
                            checkboxes.append((checkbox, is_checked, shortcut))
                            
                            # 快捷方式信息
                            info_frame = ctk.CTkFrame(item_frame, fg_color="transparent")
                            info_frame.pack(side="left", fill="x", expand=True, padx=10, pady=5)
                            
                            # 确保使用正确的字体权重
                            name_label = ctk.CTkLabel(
                                info_frame,
                                text=shortcut.get('name', '未知'),
                                font=ctk.CTkFont(size=14, weight="normal")  # 明确设置为normal
                            )
                            name_label.pack(anchor="w")
                            
                            # 确保使用正确的字体权重
                            path_label = ctk.CTkLabel(
                                info_frame,
                                text=shortcut.get('path', '未知路径'),
                                font=ctk.CTkFont(size=12, weight="normal"),  # 明确设置为normal
                                text_color="#888888"
                            )
                            path_label.pack(anchor="w", pady=(2, 0))
                        except Exception as item_e:
                            # 单个项目创建失败时记录错误并继续
                            import traceback
                            error_trace = traceback.format_exc()
                            logger.error(f"创建快捷方式项失败: {item_e}\n{error_trace}")
                
                # 初始更新列表
                update_shortcuts_list()
                
                # 绑定分区选择变化事件
                selected_section.trace_add("write", lambda *args: update_shortcuts_list())
                
                # 按钮区域
                buttons_frame = ctk.CTkFrame(section_dialog, fg_color="transparent")
                buttons_frame.pack(fill="x", padx=20, pady=10)
                
                # 全选按钮 - 确保使用正确的字体权重
                select_all_button = ctk.CTkButton(
                    buttons_frame,
                    text="全选",
                    width=100,
                    height=35,
                    font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                    command=lambda: self._toggle_select_all(checkboxes)
                )
                select_all_button.pack(side="left", padx=5)
                
                # 添加按钮 - 确保使用正确的字体权重
                add_section_button = ctk.CTkButton(
                    buttons_frame,
                    text="添加选中项",
                    width=120,
                    height=35,
                    font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                    command=lambda: self._add_selected_items_to_private_space(
                        checkboxes, section_dialog, dialog, stats_var
                    )
                )
                add_section_button.pack(side="right", padx=5)
            
            # 取消按钮 - 始终显示 - 确保使用正确的字体权重
            cancel_section_button = ctk.CTkButton(
                section_dialog,
                text="取消",
                width=100,
                height=35,
                font=ctk.CTkFont(size=14, weight="normal"),  # 明确设置为normal
                fg_color="#6c6c6c",
                hover_color="#505050",
                command=section_dialog.destroy
            )
            cancel_section_button.pack(side="bottom", pady=10)
            
        except Exception as e:
            # 添加更详细的错误处理和日志记录
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"从分区选择失败: {e}\n{error_trace}")
            messagebox.showerror("错误", f"从分区选择失败: {str(e)}\n\n详细信息: {error_trace}")
            
    def _browse_all_drives(self, parent_window, dialog, stats_var, section_dialog):
        """允许用户直接浏览所有驱动器和分区，支持选择文件或文件夹"""
        try:
            # 关闭当前分区选择对话框
            section_dialog.destroy()
            
            # 先询问用户是选择文件还是文件夹
            selection_type_dialog = ctk.CTkToplevel(parent_window)
            selection_type_dialog.title("选择类型")
            selection_type_dialog.geometry("300x200")
            selection_type_dialog.transient(parent_window)
            selection_type_dialog.grab_set()
            
            # 居中显示
            selection_type_dialog.update_idletasks()
            width = selection_type_dialog.winfo_width()
            height = selection_type_dialog.winfo_height()
            x = (parent_window.winfo_width() // 2) + parent_window.winfo_x() - (width // 2)
            y = (parent_window.winfo_height() // 2) + parent_window.winfo_y() - (height // 2)
            selection_type_dialog.geometry(f"{width}x{height}+{x}+{y}")
            
            # 创建提示标签
            ctk.CTkLabel(
                selection_type_dialog,
                text="请选择要添加的类型:",
                font=ctk.CTkFont(size=14, weight="normal")
            ).pack(pady=20)
            
            # 创建按钮区域
            buttons_frame = ctk.CTkFrame(selection_type_dialog, fg_color="transparent")
            buttons_frame.pack(fill="x", padx=20, pady=10)
            
            # 选择文件函数
            def select_file():
                selection_type_dialog.destroy()
                # 使用系统文件选择对话框，允许用户浏览所有驱动器
                file_path = filedialog.askopenfilename(
                    title="选择文件",
                    filetypes=[("所有文件", "*.*")],
                    multiple=False  # 一次选择一个文件
                )
                
                if file_path:
                    add_item_to_private_space(file_path, "file")
            
            # 选择文件夹函数
            def select_folder():
                selection_type_dialog.destroy()
                # 使用系统文件夹选择对话框
                folder_path = filedialog.askdirectory(
                    title="选择文件夹"
                )
                
                if folder_path:
                    add_item_to_private_space(folder_path, "folder")
            
            # 添加项目到私人空间的通用函数
            def add_item_to_private_space(path, item_type):
                # 检查项目是否已存在于私人空间
                if self._is_item_already_in_private_space(path):
                    messagebox.showinfo("提示", f"该{item_type == 'file' and '文件' or '文件夹'}已在私人空间中")
                    return
                
                # 添加到私人空间
                self._add_to_private_space({
                    "type": item_type,
                    "name": os.path.basename(path),
                    "path": path,
                    "added_at": time.time()
                })
                
                # 更新显示
                if hasattr(self, 'private_files_frame'):
                    self._display_private_items(self.private_files_frame, stats_var)
                stats_var.set(f"文件数量: {len(self.private_space_data.get('items', []))}")
                
                # 关闭添加对话框
                dialog.destroy()
                
                messagebox.showinfo("成功", f"{item_type == 'file' and '文件' or '文件夹'} '{os.path.basename(path)}' 已添加到私人空间")
            
            # 文件按钮
            file_button = ctk.CTkButton(
                buttons_frame,
                text="选择文件",
                height=35,
                font=ctk.CTkFont(size=14, weight="normal"),
                command=select_file
            )
            file_button.pack(fill="x", pady=5)
            
            # 文件夹按钮
            folder_button = ctk.CTkButton(
                buttons_frame,
                text="选择文件夹",
                height=35,
                font=ctk.CTkFont(size=14, weight="normal"),
                command=select_folder
            )
            folder_button.pack(fill="x", pady=5)
            
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"浏览驱动器失败: {e}\n{error_trace}")
            messagebox.showerror("错误", f"浏览驱动器失败: {str(e)}\n\n详细信息: {error_trace}")
    
    def _toggle_select_all(self, checkboxes):
        """切换全选/取消全选"""
        # 检查是否所有都已选中
        all_checked = all(checkbox[1].get() for checkbox in checkboxes)
        
        # 反选所有
        for checkbox, var, _ in checkboxes:
            var.set(not all_checked)
    
    def _add_selected_items_to_private_space(self, checkboxes, section_dialog, main_dialog, stats_var):
        """将选中的项添加到私人空间"""
        try:
            added_count = 0
            existing_count = 0
            invalid_count = 0
            
            for checkbox, var, shortcut in checkboxes:
                if var.get():
                    path = shortcut.get('path', '')
                    
                    # 检查路径是否有效
                    if not path or not (os.path.isfile(path) or os.path.isdir(path)):
                        logger.warning(f"路径无效或不存在: {path}")
                        invalid_count += 1
                        continue
                    
                    # 检查是否已存在
                    if not self._is_item_already_in_private_space(path):
                        # 确定类型
                        item_type = 'folder' if os.path.isdir(path) else 'file'
                        
                        # 添加到私人空间
                        self._add_to_private_space({
                            "type": item_type,
                            "name": shortcut.get('name', os.path.basename(path)),
                            "path": path,
                            "added_at": time.time()
                        })
                        added_count += 1
                    else:
                        existing_count += 1
            
            if added_count > 0:
                # 更新显示
                if hasattr(self, 'private_files_frame'):
                    self._display_private_items(self.private_files_frame, stats_var)
                stats_var.set(f"文件数量: {len(self.private_space_data.get('items', []))}")
                
                # 关闭对话框
                section_dialog.destroy()
                main_dialog.destroy()
                
                message = f"成功添加 {added_count} 个项目到私人空间"
                if existing_count > 0:
                    message += f"\n{existing_count} 个项目已存在于私人空间中"
                if invalid_count > 0:
                    message += f"\n{invalid_count} 个项目路径无效或不存在"
                
                messagebox.showinfo("成功", message)
            else:
                message = "请选择要添加的项目"
                if existing_count > 0:
                    message += f"\n{existing_count} 个项目已存在于私人空间中"
                elif invalid_count > 0:
                    message = f"{invalid_count} 个项目路径无效或不存在"
                elif checkboxes and all(not var.get() for _, var, _ in checkboxes):
                    message = "请先选择要添加的项目"
                
                messagebox.showinfo("提示", message)
                
        except Exception as e:
            import traceback
            error_trace = traceback.format_exc()
            logger.error(f"添加选中项失败: {e}\n{error_trace}")
            messagebox.showerror("错误", f"添加选中项失败: {str(e)}\n\n详细信息: {error_trace}")
    
    def _is_item_already_in_private_space(self, path):
        """检查项目是否已在私人空间中"""
        items = self.private_space_data.get('items', [])
        return any(item.get('path') == path for item in items)
    
    def _add_to_private_space(self, item):
        """添加项目到私人空间"""
        items = self.private_space_data.get('items', [])
        items.append(item)
        self._save_private_space_data()
    
    def run(self):
        """运行应用程序"""
        # 设置窗口最小尺寸，确保搜索区域有足够空间显示
        self.root.minsize(1024, 768)
        logger.info("应用程序启动，主循环开始")
        # 启动主循环
        self.root.mainloop()