# 桌面小易 - 快捷方式管理工具

一个现代化的桌面快捷方式管理工具，支持文件、文件夹和网站快捷方式的添加、编辑和管理。

## 项目结构

```
desktop_yi/
├── src/
│   ├── __init__.py
│   ├── main.py              # 程序入口
│   ├── data_manager.py      # 数据管理模块（从shortcuts.py重构）
│   ├── ui/
│   │   ├── __init__.py
│   │   ├── main_ui.py       # 主界面模块（合并ModernUI类）
│   │   └── components.py    # UI组件
│   └── utils/
│       ├── __init__.py
│       ├── icon_handler.py  # 图标处理工具
│       └── helpers.py       # 通用辅助函数
├── config/
│   └── shortcuts.json       # 统一的配置文件存储位置
├── requirements.txt
└── README.md
```

## 功能特性

- 支持文件、文件夹和网站快捷方式管理
- 多种视图模式（列表视图、图标视图）
- 主题切换（深色/浅色模式）
- 快捷方式分组和分类
- 搜索功能
- 数据备份与恢复

## 安装说明

```bash
pip install -r requirements.txt
```

## 运行程序

```bash
python src/main.py
```