def _create_ui(self):
    # 使用grid布局实现更灵活的窗口结构
    self.root.grid_columnconfigure(0, weight=1)
    self.root.grid_rowconfigure(0, weight=1)
    
    # 创建主布局 - 使用圆角和阴影提升视觉效果
    self.main_frame = ctk.CTkFrame(self.root, corner_radius=10)
    self.main_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
    self.main_frame.grid_columnconfigure(0, weight=1)
    self.main_frame.grid_rowconfigure(2, weight=1)  # 内容区域权重最高
    
    # 基础事件绑定
    if hasattr(self.root, 'bind'):
        self.root.bind("<ButtonRelease-1>", self._handle_button_release)
        logger.info("基础事件绑定已设置")