import os
import json
import hashlib
import logging
from datetime import datetime

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('FileTransfer')

# 块大小设置（4MB）
CHUNK_SIZE = 4 * 1024 * 1024

class FileTransferManager:
    def __init__(self):
        self.transfer_code = None
        self.file_info = None
        self.total_chunks = 0
        self.current_chunk = 0
        self.transfer_speed = 0
        self.estimated_time = 0
        self.is_transferring = False
        self.callbacks = {
            'progress': None,
            'completed': None,
            'error': None,
            'file_info_received': None
        }
    
    def get_file_info(self, file_path):
        """获取文件信息"""
        try:
            if os.path.isfile(file_path):
                # 单个文件
                file_size = os.path.getsize(file_path)
                file_name = os.path.basename(file_path)
                total_chunks = (file_size + CHUNK_SIZE - 1) // CHUNK_SIZE
                
                # 计算文件哈希
                file_hash = self._calculate_file_hash(file_path)
                
                return {
                    'type': 'file',
                    'name': file_name,
                    'size': file_size,
                    'path': file_path,
                    'total_chunks': total_chunks,
                    'hash': file_hash,
                    'created_at': datetime.now().isoformat()
                }
            elif os.path.isdir(file_path):
                # 文件夹
                dir_name = os.path.basename(file_path)
                file_list = []
                total_size = 0
                
                # 遍历文件夹收集所有文件信息
                for root, dirs, files in os.walk(file_path):
                    for file in files:
                        file_full_path = os.path.join(root, file)
                        try:
                            file_size = os.path.getsize(file_full_path)
                            relative_path = os.path.relpath(file_full_path, file_path)
                            
                            file_info = {
                                'name': file,
                                'size': file_size,
                                'path': file_full_path,
                                'relative_path': relative_path,
                                'hash': self._calculate_file_hash(file_full_path)
                            }
                            file_list.append(file_info)
                            total_size += file_size
                        except Exception as e:
                            logger.warning(f"获取文件 {file_full_path} 信息失败: {e}")
                
                return {
                    'type': 'folder',
                    'name': dir_name,
                    'size': total_size,
                    'path': file_path,
                    'file_count': len(file_list),
                    'files': file_list,
                    'created_at': datetime.now().isoformat()
                }
            else:
                logger.error(f"路径不存在或不可访问: {file_path}")
                return None
        except Exception as e:
            logger.error(f"获取文件信息失败: {e}")
            return None
    
    def start_sending(self, client, file_path, transfer_code):
        """开始发送文件或文件夹"""
        try:
            self.transfer_code = transfer_code
            self.is_transferring = True
            self.current_chunk = 0
            
            # 获取文件信息
            self.file_info = self.get_file_info(file_path)
            if not self.file_info:
                raise Exception("获取文件信息失败")
            
            # 发送文件信息
            if not client.send_file_info(self.file_info):
                raise Exception("发送文件信息失败")
            
            # 根据文件类型进行处理
            if self.file_info['type'] == 'file':
                # 发送单个文件
                self._send_single_file(client, self.file_info)
            else:
                # 发送文件夹
                self._send_folder(client, self.file_info)
            
            # 发送传输完成消息
            client.send_transfer_complete()
            
            # 调用完成回调
            if self.callbacks['completed']:
                self.callbacks['completed'](self.file_info)
            
            self.is_transferring = False
            return True
        except Exception as e:
            logger.error(f"发送文件失败: {e}")
            self.is_transferring = False
            # 调用错误回调
            if self.callbacks['error']:
                self.callbacks['error'](str(e))
            return False
    
    def start_receiving(self, file_info, save_dir):
        """准备接收文件或文件夹"""
        try:
            self.file_info = file_info
            self.current_chunk = 0
            self.total_chunks = 0
            
            # 验证保存目录
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)
            
            # 根据文件类型准备
            if file_info['type'] == 'file':
                self.total_chunks = file_info['total_chunks']
                self.save_path = os.path.join(save_dir, file_info['name'])
                # 创建文件
                self._prepare_receive_file()
            else:
                # 为文件夹创建目录
                self.save_path = os.path.join(save_dir, file_info['name'])
                if not os.path.exists(self.save_path):
                    os.makedirs(self.save_path)
                self.total_chunks = sum((f['size'] + CHUNK_SIZE - 1) // CHUNK_SIZE for f in file_info['files'])
            
            # 调用文件信息接收回调
            if self.callbacks['file_info_received']:
                self.callbacks['file_info_received'](file_info)
            
            return True
        except Exception as e:
            logger.error(f"准备接收文件失败: {e}")
            if self.callbacks['error']:
                self.callbacks['error'](str(e))
            return False
    
    def receive_chunk(self, chunk_data, chunk_index):
        """接收文件块"""
        try:
            if self.file_info['type'] == 'file':
                # 写入单个文件块
                with open(self.save_path, 'ab') as f:
                    f.write(chunk_data)
            else:
                # 对于文件夹，需要根据索引确定是哪个文件的哪个块
                # 这里简化处理，实际可能需要更复杂的逻辑
                # 暂时不实现文件夹分块接收的具体逻辑
                pass
            
            self.current_chunk += 1
            
            # 计算进度
            progress = (self.current_chunk / self.total_chunks) * 100
            
            # 调用进度回调
            if self.callbacks['progress']:
                self.callbacks['progress']({
                    'progress': progress,
                    'current_chunk': self.current_chunk,
                    'total_chunks': self.total_chunks,
                    'file_info': self.file_info
                })
            
            # 检查是否完成
            if self.current_chunk >= self.total_chunks:
                self.is_transferring = False
                if self.callbacks['completed']:
                    self.callbacks['completed'](self.file_info)
                return True
            
            return False
        except Exception as e:
            logger.error(f"接收文件块失败: {e}")
            if self.callbacks['error']:
                self.callbacks['error'](str(e))
            return False
    
    def register_callback(self, callback_type, callback_func):
        """注册回调函数"""
        if callback_type in self.callbacks:
            self.callbacks[callback_type] = callback_func
    
    def _send_single_file(self, client, file_info):
        """发送单个文件"""
        try:
            with open(file_info['path'], 'rb') as f:
                chunk_index = 0
                while True:
                    chunk = f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    
                    # 发送块数据
                    if not client.send_file_chunk(chunk.decode('latin1')):
                        raise Exception("发送文件块失败")
                    
                    chunk_index += 1
                    
                    # 计算进度
                    progress = (chunk_index / file_info['total_chunks']) * 100
                    
                    # 调用进度回调
                    if self.callbacks['progress']:
                        self.callbacks['progress']({
                            'progress': progress,
                            'current_chunk': chunk_index,
                            'total_chunks': file_info['total_chunks'],
                            'file_info': file_info
                        })
        except Exception as e:
            raise Exception(f"发送文件过程中出错: {e}")
    
    def _send_folder(self, client, folder_info):
        """发送文件夹（简化版，需要与接收端配合）"""
        # 这里需要更复杂的逻辑，包括发送文件列表、逐个发送文件等
        # 暂时简化处理，实际使用时需要完善
        pass
    
    def _prepare_receive_file(self):
        """准备接收文件"""
        # 如果文件已存在，先删除
        if os.path.exists(self.save_path):
            os.remove(self.save_path)
    
    def _calculate_file_hash(self, file_path):
        """计算文件哈希值"""
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                # 分块读取文件
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except Exception as e:
            logger.warning(f"计算文件哈希值失败 {file_path}: {e}")
            return None
    
    def format_size(self, size_bytes):
        """格式化文件大小"""
        if size_bytes < 0:
            return "0 B"
        
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} PB"

# 测试代码
if __name__ == "__main__":
    # 这个是测试代码，实际使用时会在主程序中调用
    manager = FileTransferManager()
    # 测试获取文件信息
    # file_info = manager.get_file_info("test.txt")
    # print(json.dumps(file_info, ensure_ascii=False, indent=2))