import socket
import json
import threading
import time
import logging

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('SocketClient')

class FastTransferClient:
    def __init__(self):
        self.client_socket = None
        self.server_host = None
        self.server_port = None
        self.transfer_code = None
        self.role = None  # 'sender' 或 'receiver'
        self.is_connected = False
        self.lock = threading.RLock()
        self.message_handlers = {}
        self.receive_thread = None
        self.heartbeat_thread = None
    
    def generate_transfer_code(self, host='localhost', port=5555):
        """生成传输码
        
        Args:
            host: 服务器主机地址
            port: 服务器端口
            
        Returns:
            tuple: (是否成功, 传输码或错误信息)
        """
        temp_socket = None
        try:
            # 创建临时socket
            temp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            temp_socket.settimeout(5.0)
            temp_socket.connect((host, port))
            
            # 发送生成传输码请求
            request = {'action': 'generate_code'}
            json_data = json.dumps(request, ensure_ascii=False)
            length = len(json_data.encode('utf-8'))
            temp_socket.sendall(length.to_bytes(4, byteorder='big'))
            temp_socket.sendall(json_data.encode('utf-8'))
            
            # 接收响应
            length_bytes = temp_socket.recv(4)
            if not length_bytes:
                return False, "服务器无响应"
            
            length = int.from_bytes(length_bytes, byteorder='big')
            data = b''
            while len(data) < length:
                packet = temp_socket.recv(min(4096, length - len(data)))
                if not packet:
                    return False, "接收数据失败"
                data += packet
            
            response = json.loads(data.decode('utf-8'))
            
            if response.get('status') == 'success':
                code = response.get('transfer_code')
                logger.info(f"成功生成传输码: {code}")
                return True, code
            else:
                error_msg = response.get('message', '生成传输码失败')
                logger.error(f"生成传输码失败: {error_msg}")
                return False, error_msg
                
        except Exception as e:
            logger.error(f"生成传输码时出错: {e}")
            return False, str(e)
        finally:
            if temp_socket:
                try:
                    temp_socket.close()
                except:
                    pass
    
    def validate_transfer_code(self, code, host='localhost', port=5555):
        """验证传输码是否有效
        
        Args:
            code: 要验证的传输码
            host: 服务器主机地址
            port: 服务器端口
            
        Returns:
            tuple: (是否成功, 验证结果或错误信息)
        """
        temp_socket = None
        try:
            # 创建临时socket
            temp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            temp_socket.settimeout(5.0)
            temp_socket.connect((host, port))
            
            # 发送验证传输码请求
            request = {
                'action': 'validate_code',
                'transfer_code': code
            }
            json_data = json.dumps(request, ensure_ascii=False)
            length = len(json_data.encode('utf-8'))
            temp_socket.sendall(length.to_bytes(4, byteorder='big'))
            temp_socket.sendall(json_data.encode('utf-8'))
            
            # 接收响应
            length_bytes = temp_socket.recv(4)
            if not length_bytes:
                return False, "服务器无响应"
            
            length = int.from_bytes(length_bytes, byteorder='big')
            data = b''
            while len(data) < length:
                packet = temp_socket.recv(min(4096, length - len(data)))
                if not packet:
                    return False, "接收数据失败"
                data += packet
            
            response = json.loads(data.decode('utf-8'))
            
            is_valid = response.get('status') == 'valid'
            logger.info(f"传输码 {code} 验证结果: {'有效' if is_valid else '无效'}")
            return True, is_valid
            
        except Exception as e:
            logger.error(f"验证传输码时出错: {e}")
            return False, str(e)
        finally:
            if temp_socket:
                try:
                    temp_socket.close()
                except:
                    pass
    
    def connect(self, server_host='localhost', server_port=5555, transfer_code=None, role='sender'):
        """连接到服务器"""
        try:
            # 如果已经连接，先断开
            if self.is_connected:
                self.disconnect()
            
            self.server_host = server_host
            self.server_port = server_port
            self.transfer_code = transfer_code
            self.role = role
            
            # 创建socket连接
            self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client_socket.connect((server_host, server_port))
            self.is_connected = True
            
            logger.info(f"已连接到服务器 {server_host}:{server_port}")
            
            # 发送认证信息
            auth_data = {
                'action': 'auth',
                'transfer_code': transfer_code,
                'role': role
            }
            self._send_data(auth_data)
            
            # 启动接收消息的线程
            self.receive_thread = threading.Thread(target=self._receive_messages)
            self.receive_thread.daemon = True
            self.receive_thread.start()
            
            # 启动心跳线程
            self.heartbeat_thread = threading.Thread(target=self._heartbeat)
            self.heartbeat_thread.daemon = True
            self.heartbeat_thread.start()
            
            return True
        except Exception as e:
            logger.error(f"连接服务器失败: {e}")
            self.is_connected = False
            return False
    
    def disconnect(self):
        """断开与服务器的连接"""
        with self.lock:
            self.is_connected = False
            if self.client_socket:
                try:
                    self.client_socket.close()
                except:
                    pass
                self.client_socket = None
            
            # 等待线程结束
            if self.receive_thread and self.receive_thread.is_alive():
                self.receive_thread.join(timeout=1)
            if self.heartbeat_thread and self.heartbeat_thread.is_alive():
                self.heartbeat_thread.join(timeout=1)
            
            logger.info("已断开与服务器的连接")
    
    def send_file_info(self, file_info):
        """发送文件信息"""
        if not self.is_connected:
            logger.error("未连接到服务器")
            return False
        
        try:
            data = {
                'action': 'file_info',
                'file_info': file_info
            }
            self._send_data(data)
            return True
        except Exception as e:
            logger.error(f"发送文件信息失败: {e}")
            return False
    
    def send_file_chunk(self, chunk_data):
        """发送文件数据块"""
        if not self.is_connected:
            logger.error("未连接到服务器")
            return False
        
        try:
            data = {
                'action': 'file_chunk',
                'chunk': chunk_data
            }
            self._send_data(data)
            return True
        except Exception as e:
            logger.error(f"发送文件块失败: {e}")
            return False
    
    def send_transfer_complete(self):
        """发送传输完成消息"""
        if not self.is_connected:
            logger.error("未连接到服务器")
            return False
        
        try:
            data = {
                'action': 'transfer_complete'
            }
            self._send_data(data)
            return True
        except Exception as e:
            logger.error(f"发送传输完成消息失败: {e}")
            return False
    
    def register_handler(self, message_type, handler_func):
        """注册消息处理器"""
        with self.lock:
            self.message_handlers[message_type] = handler_func
    
    def unregister_handler(self, message_type):
        """注销消息处理器"""
        with self.lock:
            if message_type in self.message_handlers:
                del self.message_handlers[message_type]
    
    def _receive_messages(self):
        """接收消息的线程函数"""
        while self.is_connected:
            try:
                # 设置超时，以便能够定期检查连接状态
                self.client_socket.settimeout(1.0)
                
                # 接收数据
                data = self._receive_data()
                if data:
                    # 处理接收到的消息
                    self._handle_message(data)
            except socket.timeout:
                # 超时，继续循环
                continue
            except Exception as e:
                logger.error(f"接收消息时出错: {e}")
                self.is_connected = False
                # 调用断开连接处理器
                if 'disconnect' in self.message_handlers:
                    try:
                        self.message_handlers['disconnect']({})
                    except:
                        pass
                break
    
    def _handle_message(self, data):
        """处理接收到的消息"""
        with self.lock:
            # 获取消息类型
            action = data.get('action', 'unknown')
            
            # 心跳消息不需要处理
            if action == 'heartbeat':
                return
            
            # 如果有对应的处理器，调用它
            if action in self.message_handlers:
                try:
                    self.message_handlers[action](data)
                except Exception as e:
                    logger.error(f"处理消息 {action} 时出错: {e}")
            # 状态消息的处理
            elif 'status' in data:
                status = data['status']
                if status in self.message_handlers:
                    try:
                        self.message_handlers[status](data)
                    except Exception as e:
                        logger.error(f"处理状态消息 {status} 时出错: {e}")
    
    def _heartbeat(self):
        """心跳线程，定期检查连接"""
        while self.is_connected:
            try:
                time.sleep(2)
            except:
                break
    
    def _send_data(self, data):
        """发送数据"""
        with self.lock:
            if not self.is_connected or not self.client_socket:
                raise Exception("未连接到服务器")
            
            try:
                json_data = json.dumps(data, ensure_ascii=False)
                # 发送数据长度作为前缀
                length = len(json_data.encode('utf-8'))
                self.client_socket.sendall(length.to_bytes(4, byteorder='big'))
                self.client_socket.sendall(json_data.encode('utf-8'))
            except Exception as e:
                self.is_connected = False
                raise
    
    def _receive_data(self):
        """接收数据"""
        with self.lock:
            if not self.is_connected or not self.client_socket:
                return None
            
            try:
                # 接收数据长度
                length_bytes = self.client_socket.recv(4)
                if not length_bytes:
                    self.is_connected = False
                    return None
                length = int.from_bytes(length_bytes, byteorder='big')
                
                # 接收实际数据
                data = b''
                while len(data) < length:
                    packet = self.client_socket.recv(min(4096, length - len(data)))
                    if not packet:
                        self.is_connected = False
                        return None
                    data += packet
                
                return json.loads(data.decode('utf-8'))
            except Exception as e:
                self.is_connected = False
                raise

# 测试代码
if __name__ == "__main__":
    # 这个是测试客户端，实际使用时会在主程序中调用
    client = FastTransferClient()
    
    # 测试生成传输码
    # success, code_or_error = client.generate_transfer_code()
    # if success:
    #     print(f"生成的传输码: {code_or_error}")
    #     # 测试验证传输码
    #     validate_success, result = client.validate_transfer_code(code_or_error)
    #     print(f"验证结果: {'有效' if result else '无效'}")
    # else:
    #     print(f"生成传输码失败: {code_or_error}")
    
    # 等待用户输入退出
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        client.disconnect()