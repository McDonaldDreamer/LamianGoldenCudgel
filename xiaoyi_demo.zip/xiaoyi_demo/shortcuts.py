import os
import json
import subprocess
import sys
import datetime
import shutil
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('ShortcutsHandler')

class ShortcutsHandler:
    def __init__(self, data_dir=None, auto_backup=True, max_backups=5):
        # 设置数据目录
        if data_dir is None:
            self.data_dir = os.path.join('D:', ".shortcut_manager")
        else:
            self.data_dir = data_dir
        
        self._ensure_data_dir_exists()
        self.data_file = os.path.join(self.data_dir, "shortcuts.json")
        
        # 备份配置
        self.auto_backup = auto_backup
        self.max_backups = max_backups
        self.backup_dir = os.path.join(self.data_dir, "backups")
        
        # 确保备份目录存在
        if not os.path.exists(self.backup_dir):
            os.makedirs(self.backup_dir)
        
        # 初始化数据
        self.shortcuts = {}
        try:
            self.shortcuts = self.load_shortcuts()
            logger.info(f"成功加载 {len(self.shortcuts)} 个快捷方式")
        except Exception as e:
            logger.error(f"加载快捷方式失败: {e}")
            # 尝试从备份恢复
            if self._restore_from_backup():
                logger.info("从备份成功恢复数据")
            else:
                logger.warning("无法从备份恢复数据，使用空数据")
    
    def _ensure_data_dir_exists(self):
        if not os.path.exists(self.data_dir):
            try:
                os.makedirs(self.data_dir)
                logger.info(f"创建数据目录: {self.data_dir}")
            except Exception as e:
                logger.error(f"创建数据目录失败: {e}")
                raise
    
    def load_shortcuts(self):
        try:
            if os.path.exists(self.data_file):
                # 验证文件大小，避免读取过大文件
                if os.path.getsize(self.data_file) > 10 * 1024 * 1024:  # 10MB 限制
                    logger.error(f"数据文件过大: {os.path.getsize(self.data_file)} 字节")
                    return {}
                
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    # 验证JSON结构
                    data = json.load(f)
                    if not isinstance(data, dict):
                        logger.error("数据格式错误: 预期字典类型")
                        return {}
                    
                    # 转换旧格式数据（如果存在）
                    for name, value in data.items():
                        if isinstance(value, str):
                            # 转换为新的数据格式
                            path = value
                            data[name] = {
                                "path": path,
                                "type": "folder" if os.path.isdir(path) else "file",
                                "icon": None
                            }
                    
                    return data
            logger.warning("数据文件不存在，返回空数据")
        except json.JSONDecodeError as e:
            logger.error(f"JSON解析错误: {e}")
            # 尝试修复简单的JSON错误
            # 尝试修复简单的JSON错误（方法暂未实现，先跳过）
            logger.warning("JSON解析错误，跳过修复尝试")
            return {}
        except IOError as e:
            logger.error(f"IO错误: {e}")
        except Exception as e:
            logger.error(f"加载数据时发生未知错误: {e}")
        
        # 返回空字典作为默认值
        return {}
    
    def save_shortcuts(self):
        """保存快捷方式数据到文件 - 增强稳定性"""
        # 创建临时文件，成功后再替换原文件
        temp_file = self.data_file + ".tmp"
        
        try:
            # 自动备份
            if self.auto_backup and os.path.exists(self.data_file):
                self._create_backup()
            
            # 确保数据目录存在
            self._ensure_data_dir_exists()
            
            # 写入临时文件
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(self.shortcuts, f, ensure_ascii=False, indent=4)
            
            # 验证写入的数据
            with open(temp_file, 'r', encoding='utf-8') as f:
                json.load(f)  # 如果JSON无效，会抛出异常
            
            # 原子操作：替换原文件
            os.replace(temp_file, self.data_file)
            logger.info(f"成功保存 {len(self.shortcuts)} 个快捷方式")
            
            # 清理旧备份
            self._cleanup_old_backups()
            
            return True
        except Exception as e:
            logger.error(f"保存数据失败: {e}")
            # 清理临时文件
            if os.path.exists(temp_file):
                try:
                    os.remove(temp_file)
                except:
                    pass
            return False
    
    def add_shortcut(self, name, path, icon=None, section=""):
        """添加一个新的快捷方式，支持自定义图标、文件夹快捷方式和网址"""
        # 验证参数
        if not name or not isinstance(name, str):
            raise ValueError("快捷方式名称不能为空且必须为字符串")
        
        if not path or not isinstance(path, str):
            raise ValueError("快捷方式路径不能为空且必须为字符串")
        
        # 检查名称是否已存在
        if name in self.shortcuts:
            raise ValueError(f"快捷方式名称 '{name}' 已存在")
        
        # 确定快捷方式类型
        # 如果icon参数明确指定为'website'，则将其视为网址类型
        if icon == 'website':
            # 对于网址，不需要验证路径是否存在
            shortcut_data = {
                "path": path,
                "type": "website",
                "icon": None
            }
        else:
            # 验证文件/文件夹路径是否存在
            if not os.path.exists(path):
                raise FileNotFoundError(f"文件/文件夹不存在: {path}")
            
            # 创建快捷方式数据字典
            shortcut_data = {
                "path": path,
                "type": "folder" if os.path.isdir(path) else "file",
                "icon": icon  # 自定义图标路径，如果为None则使用系统默认
            }
        
        # 如果提供了分区信息，则添加到快捷方式数据中
        if section:
            shortcut_data['section'] = section
        
        # 添加快捷方式
        self.shortcuts[name] = shortcut_data
        
        # 保存数据
        return self.save_shortcuts()
    
    def update_shortcut(self, old_name, new_name=None, new_path=None, new_icon=None):
        """更新现有快捷方式，支持更新自定义图标"""
        # 验证参数
        if not old_name or not isinstance(old_name, str):
            raise ValueError("原快捷方式名称不能为空且必须为字符串")
        
        if new_name and not isinstance(new_name, str):
            raise ValueError("新快捷方式名称必须为字符串")
        
        if new_path and not isinstance(new_path, str):
            raise ValueError("新快捷方式路径必须为字符串")
        
        if new_icon and not isinstance(new_icon, str):
            raise ValueError("新快捷方式图标路径必须为字符串")
        
        if old_name not in self.shortcuts:
            raise KeyError(f"找不到快捷方式 '{old_name}'")
        
        # 创建操作前的副本，以便出错记录
        backup = self.shortcuts.copy()
        
        try:
            # 如果要更改名称
            if new_name and new_name != old_name:
                if new_name in self.shortcuts:
                    raise ValueError(f"快捷方式名称 '{new_name}' 已存在")
                self.shortcuts[new_name] = self.shortcuts.pop(old_name)
                old_name = new_name
            
            # 获取当前快捷方式数据
            shortcut_data = self.shortcuts[old_name]
            
            # 确保是字典格式（向后兼容）
            if isinstance(shortcut_data, str):
                # 转换旧格式为新格式
                path = shortcut_data
                shortcut_data = {
                    "path": path,
                    "type": "folder" if os.path.isdir(path) else "file",
                    "icon": None
                }
            
            # 如果要更改路径
            if new_path:
                if not os.path.exists(new_path):
                    raise FileNotFoundError(f"文件/文件夹不存在: {new_path}")
                shortcut_data["path"] = new_path
                shortcut_data["type"] = "folder" if os.path.isdir(new_path) else "file"
            
            # 如果要更改图标
            if new_icon is not None:
                shortcut_data["icon"] = new_icon
            
            # 更新快捷方式数据
            self.shortcuts[old_name] = shortcut_data
            
            # 保存数据
            if self.save_shortcuts():
                logger.info(f"成功更新快捷方式 '{old_name}'")
                return True
            else:
                # 恢复到备份状态
                self.shortcuts = backup
                return False
        except Exception as e:
            # 发生错误时恢复数据
            self.shortcuts = backup
            logger.error(f"更新快捷方式失败: {e}")
            raise
    
    def delete_shortcut(self, name):
        """删除快捷方式 - 修复文件夹快捷方式删除bug"""
        # 验证参数
        if not name or not isinstance(name, str):
            raise ValueError("快捷方式名称不能为空且必须为字符串")
        
        if name not in self.shortcuts:
            raise KeyError(f"找不到快捷方式 '{name}'")
        
        try:
            # 创建备份
            self._create_backup()
            
            # 删除快捷方式
            del self.shortcuts[name]
            
            # 保存数据
            self.save_shortcuts()
            
            logger.info(f"成功删除快捷方式 '{name}'")
            return True
            
        except Exception as e:
            # 记录错误但不恢复备份（避免重复错误）
            logger.error(f"删除快捷方式失败: {e}")
            # 尝试直接保存当前状态
            try:
                self.save_shortcuts()
            except:
                pass
            raise
    
    def run_shortcut(self, name):
        """运行指定的快捷方式（支持文件和文件夹） - 增强.lnk文件支持"""
        if name not in self.shortcuts:
            raise KeyError(f"找不到快捷方式 '{name}'")
        
        shortcut_data = self.shortcuts[name]
        
        # 获取路径（向后兼容）
        if isinstance(shortcut_data, str):
            path = shortcut_data
        else:
            path = shortcut_data.get("path", "")
        
        # 即使路径不存在也尝试运行（处理.lnk文件）
        if not os.path.exists(path):
            logger.warning(f"快捷方式路径不存在: {path}，但仍尝试运行")
        
        # 运行应用程序或打开文件夹
        try:
            if sys.platform.startswith('win'):
                # Windows系统 - 增强.lnk文件支持
                if path.lower().endswith('.lnk'):
                    # 使用shell=True来处理.lnk文件
                    subprocess.run(f'"{path}"', shell=True)
                else:
                    try:
                        os.startfile(path)
                    except Exception as inner_e:
                        logger.error(f"使用os.startfile打开失败: {inner_e}")
                        # 尝试使用cmd打开
                        subprocess.run(["cmd", "/c", "start", "", path], shell=False)
            else:
                # 其他系统
                try:
                    subprocess.run(["xdg-open", path])
                except Exception as e:
                    logger.error(f"使用xdg-open失败: {e}")
                    # 尝试使用open命令(macOS)或直接运行
                    try:
                        subprocess.run(["open", path])
                    except:
                        subprocess.Popen([path], shell=True)
            logger.info(f"成功运行快捷方式 '{name}'")
            return True
        except Exception as e:
            logger.error(f"运行快捷方式失败: {e}")
            return False
    
    def get_shortcut_path(self, name):
        """获取快捷方式的路径"""
        if not name or not isinstance(name, str):
            raise ValueError("快捷方式名称不能为空且必须为字符串")
        
        if name not in self.shortcuts:
            raise KeyError(f"找不到快捷方式 '{name}'")
        
        shortcut_data = self.shortcuts[name]
        # 向后兼容：如果是字符串格式，直接返回
        if isinstance(shortcut_data, str):
            return shortcut_data
        return shortcut_data.get("path", "")
    
    def get_shortcut_icon(self, name):
        """获取快捷方式的图标路径"""
        if not name or not isinstance(name, str):
            raise ValueError("快捷方式名称不能为空且必须为字符串")
        
        if name not in self.shortcuts:
            raise KeyError(f"找不到快捷方式 '{name}'")
        
        shortcut_data = self.shortcuts[name]
        # 向后兼容：如果是字符串格式，返回None
        if isinstance(shortcut_data, str):
            return None
        return shortcut_data.get("icon", None)
    
    def get_shortcut_type(self, name):
        """获取快捷方式类型（文件或文件夹）"""
        if not name or not isinstance(name, str):
            raise ValueError("快捷方式名称不能为空且必须为字符串")
        
        if name not in self.shortcuts:
            raise KeyError(f"找不到快捷方式 '{name}'")
        
        shortcut_data = self.shortcuts[name]
        # 向后兼容：如果是字符串格式，根据路径判断
        if isinstance(shortcut_data, str):
            path = shortcut_data
            return "folder" if os.path.isdir(path) else "file"
        return shortcut_data.get("type", "file")
    
    def get_all_shortcuts(self):
        """获取所有快捷方式"""
        # 返回副本以避免直接修改
        return self.shortcuts.copy()
    
    def _create_backup(self):
        """创建数据备份"""
        try:
            # 生成备份文件名，包含时间戳
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(self.backup_dir, f"shortcuts_{timestamp}.json")
            
            # 创建备份
            shutil.copy2(self.data_file, backup_file)
            logger.info(f"创建备份: {backup_file}")
            
            # 清理旧备份
            self._cleanup_old_backups()
            return True
        except Exception as e:
            logger.error(f"创建备份失败: {e}")
            return False
    
    def _cleanup_old_backups(self):
        """清理超过指定数量的旧备份"""
        try:
            # 获取所有备份文件并按修改时间排序
            backup_files = [os.path.join(self.backup_dir, f) 
                          for f in os.listdir(self.backup_dir) 
                          if f.startswith("shortcuts_") and f.endswith(".json")]
            backup_files.sort(key=os.path.getmtime, reverse=True)
            
            # 删除超出数量限制的旧备份
            for old_backup in backup_files[self.max_backups:]:
                os.remove(old_backup)
                logger.info(f"删除旧备份: {old_backup}")
        except Exception as e:
            logger.error(f"清理旧备份失败: {e}")
    

    
    def _restore_from_backup(self):
        """尝试从最新备份恢复数据"""
        try:
            # 获取最新的备份文件
            backup_files = [os.path.join(self.backup_dir, f) 
                          for f in os.listdir(self.backup_dir) 
                          if f.startswith("shortcuts_") and f.endswith(".json")]
            
            if not backup_files:
                return False
            
            # 按修改时间排序，获取最新的
            backup_files.sort(key=os.path.getmtime, reverse=True)
            latest_backup = backup_files[0]
            
            # 尝试加载备份文件
            with open(latest_backup, 'r', encoding='utf-8') as f:
                backup_data = json.load(f)
            
            # 验证数据格式
            if not isinstance(backup_data, dict):
                logger.error("备份文件数据格式错误")
                return False
            
            # 使用备份数据
            self.shortcuts = backup_data
            
            # 保存到主文件
            self.save_shortcuts()
            logger.info(f"从备份恢复数据: {latest_backup}")
            return True
        except Exception as e:
            logger.error(f"从备份恢复失败: {e}")
            return False