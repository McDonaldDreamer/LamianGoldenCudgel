import socket
import threading
import json
import os
import time
import logging
import random

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('SocketServer')

class FastTransferServer:
    def __init__(self, host='0.0.0.0', port=5555):
        self.host = host
        self.port = port
        self.server_socket = None
        self.connections = {}  # 存储连接的客户端 {传输码: {socket, address}}
        self.active_sessions = {}  # 存储活动会话 {传输码: {sender, receiver}}
        self.active_transfer_codes = {}  # 存储活跃传输码及其时间戳
        self.transfer_code_timeout = 30 * 60  # 传输码超时时间（30分钟）
        self.lock = threading.RLock()  # 用于线程安全
        self.is_running = False
    
    def start(self):
        """启动服务器"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)
            self.is_running = True
            logger.info(f"服务器启动在 {self.host}:{self.port}")
            
            # 启动接受连接的线程
            accept_thread = threading.Thread(target=self._accept_connections)
            accept_thread.daemon = True
            accept_thread.start()
            
            # 启动清理线程
            cleanup_thread = threading.Thread(target=self._cleanup_expired)
            cleanup_thread.daemon = True
            cleanup_thread.start()
            
            return True
        except Exception as e:
            logger.error(f"服务器启动失败: {e}")
            return False
    
    def stop(self):
        """停止服务器"""
        self.is_running = False
        try:
            if self.server_socket:
                self.server_socket.close()
            # 关闭所有连接
            with self.lock:
                for conn_info in self.connections.values():
                    try:
                        conn_info['socket'].close()
                    except:
                        pass
                self.connections.clear()
                self.active_sessions.clear()
                self.active_transfer_codes.clear()
            logger.info("服务器已停止")
        except Exception as e:
            logger.error(f"停止服务器时出错: {e}")
    
    def _accept_connections(self):
        """接受新连接的线程函数"""
        while self.is_running:
            try:
                client_socket, address = self.server_socket.accept()
                logger.info(f"接受连接从 {address}")
                # 为每个客户端创建一个线程处理
                client_thread = threading.Thread(target=self._handle_client, args=(client_socket, address))
                client_thread.daemon = True
                client_thread.start()
            except socket.timeout:
                continue
            except Exception as e:
                if self.is_running:  # 只有在服务器运行时记录错误
                    logger.error(f"接受连接时出错: {e}")
    
    def generate_transfer_code(self):
        """生成唯一的4位数字传输码"""
        with self.lock:
            max_attempts = 100
            for _ in range(max_attempts):
                # 生成4位随机数字传输码
                code = ''.join([str(random.randint(0, 9)) for _ in range(4)])
                
                # 检查是否已存在或已过期
                if code not in self.active_transfer_codes or self._is_transfer_code_expired(code):
                    # 添加到活跃传输码列表
                    self.active_transfer_codes[code] = {
                        'created_at': time.time(),
                        'last_used': time.time()
                    }
                    logger.info(f"生成新的传输码: {code}")
                    return code
            
            # 如果尝试了多次还是没有生成唯一的，就返回None
            logger.error("生成传输码失败: 达到最大尝试次数")
            return None
    
    def validate_transfer_code(self, code):
        """验证传输码是否有效"""
        with self.lock:
            if not self._validate_transfer_code_format(code):
                return False
            
            if code not in self.active_transfer_codes:
                return False
            
            # 检查是否过期
            if self._is_transfer_code_expired(code):
                # 移除过期的传输码
                del self.active_transfer_codes[code]
                return False
            
            # 更新最后使用时间
            self.active_transfer_codes[code]['last_used'] = time.time()
            return True
    
    def _validate_transfer_code_format(self, code):
        """验证传输码格式是否为4位数字"""
        return isinstance(code, str) and len(code) == 4 and code.isdigit()
    
    def _is_transfer_code_expired(self, code):
        """检查传输码是否已过期"""
        if code in self.active_transfer_codes:
            code_info = self.active_transfer_codes[code]
            return time.time() - code_info['last_used'] > self.transfer_code_timeout
        return True
    
    def _cleanup_expired(self):
        """清理过期的传输码和会话"""
        while self.is_running:
            try:
                time.sleep(60)  # 每分钟清理一次
                
                current_time = time.time()
                expired_codes = []
                expired_sessions = []
                
                with self.lock:
                    # 清理过期传输码
                    for code, code_info in self.active_transfer_codes.items():
                        if current_time - code_info['last_used'] > self.transfer_code_timeout:
                            expired_codes.append(code)
                    
                    # 清理过期会话
                    for code, session in self.active_sessions.items():
                        if code not in self.active_transfer_codes or self._is_transfer_code_expired(code):
                            expired_sessions.append(code)
                
                # 移除过期传输码
                for code in expired_codes:
                    with self.lock:
                        if code in self.active_transfer_codes:
                            del self.active_transfer_codes[code]
                            logger.info(f"清理过期传输码: {code}")
                
                # 移除过期会话
                for code in expired_sessions:
                    with self.lock:
                        if code in self.active_sessions:
                            del self.active_sessions[code]
                            logger.info(f"清理过期会话: {code}")
            except Exception as e:
                logger.error(f"清理过期项时出错: {e}")
    
    def _handle_client(self, client_socket, address):
        """处理客户端连接的线程函数"""
        transfer_code = None
        try:
            # 接收客户端的认证信息
            auth_data = self._receive_data(client_socket)
            if not auth_data or 'action' not in auth_data:
                raise ValueError("无效的数据")
                
            action = auth_data['action']
            
            # 处理生成传输码请求
            if action == 'generate_code':
                code = self.generate_transfer_code()
                if code:
                    self._send_data(client_socket, {'status': 'success', 'transfer_code': code})
                else:
                    self._send_data(client_socket, {'status': 'error', 'message': '生成传输码失败'})
                return
            
            # 处理验证传输码请求
            elif action == 'validate_code':
                code = auth_data.get('transfer_code')
                is_valid = self.validate_transfer_code(code)
                self._send_data(client_socket, {'status': 'valid' if is_valid else 'invalid'})
                return
            
            # 处理认证请求
            elif action == 'auth':
                transfer_code = auth_data['transfer_code']
                role = auth_data['role']  # 'sender' 或 'receiver'
                
                # 验证传输码格式和有效性
                if not self._validate_transfer_code_format(transfer_code) or not self.validate_transfer_code(transfer_code):
                    raise ValueError("传输码无效或已过期")
                
                with self.lock:
                    # 检查传输码是否已存在
                    if transfer_code in self.connections:
                        # 已有客户端使用此传输码
                        existing_conn = self.connections[transfer_code]
                        
                        # 建立会话
                        if role == 'sender' and transfer_code not in self.active_sessions:
                            self.active_sessions[transfer_code] = {'sender': client_socket, 'receiver': None}
                            self.connections[transfer_code]['socket'] = client_socket
                            logger.info(f"发送方已连接到传输码 {transfer_code}")
                            self._send_data(client_socket, {'status': 'waiting', 'message': '等待接收方连接'})
                        elif role == 'receiver' and transfer_code in self.active_sessions:
                            # 通知发送方接收方已连接
                            sender_socket = self.active_sessions[transfer_code]['sender']
                            self.active_sessions[transfer_code]['receiver'] = client_socket
                            self._send_data(sender_socket, {'status': 'ready', 'message': '接收方已连接，可以开始传输'})
                            self._send_data(client_socket, {'status': 'connected', 'message': '已连接到发送方'})
                            logger.info(f"接收方已连接到传输码 {transfer_code}")
                            
                            # 启动数据转发线程
                            threading.Thread(target=self._forward_data, args=(sender_socket, client_socket, transfer_code)).start()
                        else:
                            raise ValueError("无法建立连接")
                    else:
                        # 新的传输码
                        if role == 'sender':
                            self.connections[transfer_code] = {'socket': client_socket, 'address': address}
                            self.active_sessions[transfer_code] = {'sender': client_socket, 'receiver': None}
                            logger.info(f"发送方创建了传输码 {transfer_code}")
                            self._send_data(client_socket, {'status': 'waiting', 'message': '等待接收方连接'})
                        else:
                            raise ValueError("传输码不存在")
            else:
                raise ValueError("未知的操作")
            
            # 保持连接活动
            while self.is_running:
                # 定期发送心跳包
                self._send_data(client_socket, {'action': 'heartbeat', 'timestamp': time.time()})
                
                # 如果有传输码，更新其最后使用时间
                if transfer_code:
                    with self.lock:
                        if transfer_code in self.active_transfer_codes:
                            self.active_transfer_codes[transfer_code]['last_used'] = time.time()
                
                time.sleep(5)
                
        except Exception as e:
            logger.error(f"处理客户端 {address} 时出错: {e}")
        finally:
            # 清理连接
            with self.lock:
                if transfer_code:
                    if transfer_code in self.active_sessions:
                        # 通知对方连接已断开
                        session = self.active_sessions[transfer_code]
                        if session['sender'] != client_socket and session['sender']:
                            try:
                                self._send_data(session['sender'], {'action': 'disconnect', 'message': '接收方已断开连接'})
                            except:
                                pass
                        if session['receiver'] != client_socket and session['receiver']:
                            try:
                                self._send_data(session['receiver'], {'action': 'disconnect', 'message': '发送方已断开连接'})
                            except:
                                pass
                        del self.active_sessions[transfer_code]
                    if transfer_code in self.connections:
                        del self.connections[transfer_code]
            try:
                client_socket.close()
            except:
                pass
            logger.info(f"客户端 {address} 已断开连接")
    
    def _forward_data(self, sender, receiver, transfer_code):
        """转发发送方到接收方的数据"""
        try:
            while self.is_running and transfer_code in self.active_sessions:
                # 从发送方接收数据并转发给接收方
                data = self._receive_data(sender)
                if data:
                    self._send_data(receiver, data)
        except Exception as e:
            logger.error(f"转发数据时出错: {e}")
    
    def _send_data(self, sock, data):
        """发送数据到socket"""
        try:
            json_data = json.dumps(data, ensure_ascii=False)
            # 发送数据长度作为前缀
            length = len(json_data.encode('utf-8'))
            sock.sendall(length.to_bytes(4, byteorder='big'))
            sock.sendall(json_data.encode('utf-8'))
        except Exception as e:
            logger.error(f"发送数据时出错: {e}")
            raise
    
    def _receive_data(self, sock):
        """从socket接收数据"""
        try:
            # 接收数据长度
            length_bytes = sock.recv(4)
            if not length_bytes:
                return None
            length = int.from_bytes(length_bytes, byteorder='big')
            
            # 接收实际数据
            data = b''
            while len(data) < length:
                packet = sock.recv(min(4096, length - len(data)))
                if not packet:
                    return None
                data += packet
            
            return json.loads(data.decode('utf-8'))
        except Exception as e:
            logger.error(f"接收数据时出错: {e}")
            raise

# 测试代码
if __name__ == "__main__":
    server = FastTransferServer()
    try:
        server.start()
        print("快传服务器已启动，按Ctrl+C停止")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("停止服务器...")
    finally:
        server.stop()